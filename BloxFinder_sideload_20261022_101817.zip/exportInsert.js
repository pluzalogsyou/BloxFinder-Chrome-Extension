(function () {
  const RU = 'https://roexport.io/redirect';
  const CP = /\/(Shirt|Pants|Tshirt)\//;
  const CA = new Set([2, 11, 12]);

  const eSvg = `<svg fill="#ffffff" width="13px" height="13px" viewBox="0 0 36 36" xmlns="http://www.w3.org/2000/svg"><path d="M17,22a1,1,0,0,1,1-1h8V6a2,2,0,0,0-2-2H10.87L4,10.86V30a2,2,0,0,0,2,2H24a2,2,0,0,0,2-2V23H18A1,1,0,0,1,17,22ZM12,12H6v-.32L11.69,6H12Z"/><path d="M29.32,16.35a1,1,0,0,0-1.41,1.41L31.16,21H26v2h5.19l-3.28,3.28a1,1,0,1,0,1.41,1.41L35,22Z"/></svg>`;
  const rSvg = `<svg fill="#ffffff" width="13px" height="13px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 15.75C12.4142 15.75 12.75 15.4142 12.75 15V4.02744L14.4306 5.98809C14.7001 6.30259 15.1736 6.33901 15.4881 6.06944C15.8026 5.79988 15.839 5.3264 15.5694 5.01191L12.5694 1.51191C12.427 1.34567 12.2189 1.25 12 1.25C11.7811 1.25 11.573 1.34567 11.4306 1.51191L8.43056 5.01191C8.16099 5.3264 8.19741 5.79988 8.51191 6.06944C8.8264 6.33901 9.29988 6.30259 9.56944 5.98809L11.25 4.02744L11.25 15C11.25 15.4142 11.5858 15.75 12 15.75Z"/><path d="M16 9C15.2978 9 14.9467 9 14.6945 9.16851C14.5853 9.24148 14.4915 9.33525 14.4186 9.44446C14.25 9.69667 14.25 10.0478 14.25 10.75L14.25 15C14.25 16.2426 13.2427 17.25 12 17.25C10.7574 17.25 9.75004 16.2426 9.75004 15L9.75004 10.75C9.75004 10.0478 9.75004 9.69664 9.58149 9.4444C9.50854 9.33523 9.41481 9.2415 9.30564 9.16855C9.05341 9 8.70227 9 8 9C5.17157 9 3.75736 9 2.87868 9.87868C2 10.7574 2 12.1714 2 14.9998V15.9998C2 18.8282 2 20.2424 2.87868 21.1211C3.75736 21.9998 5.17157 21.9998 8 21.9998H16C18.8284 21.9998 20.2426 21.9998 21.1213 21.1211C22 20.2424 22 18.8282 22 15.9998V14.9998C22 12.1714 22 10.7574 21.1213 9.87868C20.2426 9 18.8284 9 16 9Z"/></svg>`;

  const eLg = eSvg.replace(/width="13px" height="13px"/, 'width="14px" height="14px"');
  const rLg = rSvg.replace(/width="13px" height="13px"/, 'width="14px" height="14px"');

  function injectStyles() {
    if (document.querySelector('#__xroe_styles__')) return;
    const s = document.createElement('style');
    s.id = '__xroe_styles__';
    s.textContent = `
      .__xroe_ib__ { width:30px; height:30px; border:none; border-radius:4px; display:flex; align-items:center; justify-content:center; cursor:pointer; padding:0; transition:filter 0.15s; flex-shrink:0; }
      .__xroe_ib__:hover { filter:brightness(1.15); }
      .__xroe_ib__.__xroe_e__ { background-color:#393b3d; }
      .__xroe_ib__.__xroe_r__ { background-color:#2d8a4e; }
      #__xroe_tip__ { position:fixed; z-index:999999; pointer-events:none; background:#1a1a1a; border:1px solid #333; border-radius:5px; padding:5px 9px; font-size:11px; font-weight:600; color:#888; white-space:nowrap; box-shadow:0 4px 14px rgba(0,0,0,0.5); transform:translate(12px,-110%); opacity:0; transition:opacity 0.1s; font-family:inherit; letter-spacing:0.03em; }
      #__xroe_tip__.visible { opacity:1; }
      #__xroe_sec__ .__xroe_bw__ { position:relative; flex:1; display:flex; zoom:1.4; }
      #__xroe_sec__ .__xroe_bw__ button { flex:1; }
      #__xroe_sec__ .__xroe_rb__ { background-color:#2d8a4e; }
      #__xroe_sec__ .__xroe_rb__:hover { filter:brightness(1.1); }
    `;
    document.head.appendChild(s);
  }

  function ensureTooltip() {
    if (document.querySelector('#__xroe_tip__')) return;
    const t = document.createElement('div');
    t.id = '__xroe_tip__';
    document.body.appendChild(t);
    document.addEventListener('mousemove', e => { t.style.left = e.clientX + 'px'; t.style.top = e.clientY + 'px'; });
  }

  const tip = txt => { const t = document.querySelector('#__xroe_tip__'); if (t) { t.textContent = txt; t.classList.add('visible'); } };
  const hideTip = () => document.querySelector('#__xroe_tip__')?.classList.remove('visible');
  const redirect = e => { e.preventDefault(); e.stopPropagation(); window.open(RU, '_blank'); };
  const isCatIdx = () => /^\/catalog\/?$/.test(window.location.pathname);
  const isCatItem = () => /\/catalog\/\d+/.test(window.location.pathname);

  function injectCardButtons(card) {
    if (card.querySelector('.__xroe__')) return;
    const img = card.querySelector('.thumbnail-2d-container img');
    if (!img || !CP.test(img.src)) return;
    const a = card.querySelector('a.item-card-link[href]');
    if (!a || !a.href.match(/\/catalog\/(\d+)/)) return;

    if (isCatIdx()) {
      const caption = card.querySelector('.item-card-caption');
      if (!caption) return;
      const w = document.createElement('div');
      w.className = '__xroe__';
      w.style.cssText = 'display:flex;flex-direction:column;gap:6px;width:100%;padding:3px 0;margin-top:3px;box-sizing:border-box;';
      const base = 'color:#fff;border:none;border-radius:4px;padding:6px 10px;font-size:13px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:7px;width:100%;font-family:inherit;transition:filter 0.15s;';
      const br = document.createElement('button');
      br.style.cssText = base + 'background-color:#2d8a4e;';
      br.innerHTML = `${rLg}<span>Re-Upload</span>`;
      br.addEventListener('mouseenter', () => br.style.filter = 'brightness(1.15)');
      br.addEventListener('mouseleave', () => br.style.filter = '');
      br.addEventListener('click', redirect);
      const be = document.createElement('button');
      be.style.cssText = base + 'background-color:#393b3d;';
      be.innerHTML = `${eLg}<span>Save Template</span>`;
      be.addEventListener('mouseenter', () => be.style.filter = 'brightness(1.15)');
      be.addEventListener('mouseleave', () => be.style.filter = '');
      be.addEventListener('click', redirect);
      w.appendChild(br);
      w.appendChild(be);
      w.addEventListener('mouseenter', () => { a._h = a.href; a.removeAttribute('href'); });
      w.addEventListener('mouseleave', () => { if (a._h) a.href = a._h; });
      a.insertBefore(w, caption);
      return;
    }

    const tc = card.querySelector('.item-card-thumb-container');
    if (!tc) return;
    tc.style.position = 'relative';
    const w = document.createElement('div');
    w.className = '__xroe__';
    w.style.cssText = 'position:absolute;bottom:6px;left:6px;display:flex;gap:4px;z-index:100;';
    w.addEventListener('mouseenter', () => { a._h = a.href; a.removeAttribute('href'); });
    w.addEventListener('mouseleave', () => { if (a._h) a.href = a._h; hideTip(); });
    const be = document.createElement('button');
    be.className = '__xroe_ib__ __xroe_e__';
    be.innerHTML = eSvg;
    be.addEventListener('mouseenter', () => tip('Save Template'));
    be.addEventListener('mouseleave', hideTip);
    be.addEventListener('click', redirect);
    const br = document.createElement('button');
    br.className = '__xroe_ib__ __xroe_r__';
    br.innerHTML = rSvg;
    br.addEventListener('mouseenter', () => tip('Re-Upload'));
    br.addEventListener('mouseleave', hideTip);
    br.addEventListener('click', redirect);
    w.appendChild(be);
    w.appendChild(br);
    tc.appendChild(w);
  }

  function injectCatalogSection() {
    if (document.querySelector('#__xroe_sec__')) return;
    const det = document.querySelector('.item-details-section');
    if (!det) return;
    const m = window.location.pathname.match(/\/catalog\/(\d+)/);
    if (!m) return;
    fetch(`https://catalog.roblox.com/v1/catalog/items/${m[1]}/details?itemType=asset`, { credentials: 'include' })
      .then(r => r.json())
      .then(d => {
        if (!d || !CA.has(d.assetType)) return;
        if (document.querySelector('#__xroe_sec__')) return;
        const det2 = document.querySelector('.item-details-section');
        if (!det2) return;
        const base = 'color:#fff;border:none;border-radius:4px;padding:6px 10px;font-size:13px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:7px;';
        const sec = document.createElement('div');
        sec.id = '__xroe_sec__';
        sec.className = '__xroe__';
        sec.style.cssText = 'border-bottom:1px solid rgb(73,77,90);padding:8px;display:flex;align-items:stretch;justify-content:flex-start;gap:8px;box-sizing:border-box;width:100%;';
        const br = document.createElement('button');
        br.className = '__xroe_rb__';
        br.style.cssText = base;
        br.innerHTML = `${rLg}<span>Re-Upload</span>`;
        br.addEventListener('click', redirect);
        const bw = document.createElement('div');
        bw.className = '__xroe_bw__';
        bw.appendChild(br);
        const be = document.createElement('button');
        be.style.cssText = base + 'background-color:#393b3d;';
        be.innerHTML = `${eLg}<span>Save Template</span>`;
        be.addEventListener('mouseenter', () => be.style.backgroundColor = '#4a4c4e');
        be.addEventListener('mouseleave', () => be.style.backgroundColor = '#393b3d');
        be.addEventListener('click', redirect);
        const ew = document.createElement('div');
        ew.className = '__xroe_bw__';
        ew.appendChild(be);
        sec.appendChild(bw);
        sec.appendChild(ew);
        det2.style.paddingTop = '8px';
        const prev = det2.previousElementSibling;
        if (prev) prev.style.marginBottom = '0px';
        det2.parentNode.insertBefore(sec, det2);
      })
      .catch(() => {});
  }

  function onNav() {
    document.querySelector('#__xroe_sec__')?.remove();
    let n = 0;
    const p = setInterval(() => { if (isCatItem()) injectCatalogSection(); if (document.querySelector('#__xroe_sec__') || ++n > 100) clearInterval(p); }, 100);
  }

  const _push = history.pushState.bind(history);
  const _rep = history.replaceState.bind(history);
  history.pushState = function (...a) { _push(...a); onNav(); };
  history.replaceState = function (...a) { _rep(...a); onNav(); };
  window.addEventListener('popstate', onNav);

  function init() {
    injectStyles();
    ensureTooltip();
    const obs = new MutationObserver(() => {
      document.querySelectorAll('.item-card-container').forEach(injectCardButtons);
      if (isCatItem()) injectCatalogSection();
    });
    obs.observe(document.body, { childList: true, subtree: true });
    document.querySelectorAll('.item-card-container').forEach(injectCardButtons);
    if (isCatItem()) {
      let n = 0;
      const p = setInterval(() => { injectCatalogSection(); if (document.querySelector('#__xroe_sec__') || ++n > 100) clearInterval(p); }, 100);
    }
  }

  if (document.body) init();
  else document.addEventListener('DOMContentLoaded', init);

})();