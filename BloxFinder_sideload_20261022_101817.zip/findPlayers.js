async function initiate() {
	async function initiate_confetti() {
		'use strict';
		var random = Math.random,
			cos = Math.cos,
			sin = Math.sin,
			PI = Math.PI,
			PI2 = PI * 2,
			timer = undefined,
			frame = undefined,
			confetti = [];
		var particles = 10,
			spread = 40,
			sizeMin = 3,
			sizeMax = 12 - sizeMin,
			eccentricity = 10,
			deviation = 100,
			dxThetaMin = -.1,
			dxThetaMax = -dxThetaMin - dxThetaMin,
			dyMin = .13,
			dyMax = .18,
			dThetaMin = .4,
			dThetaMax = .7 - dThetaMin;
		var colorThemes = [
			function() {
				return color(200 * random() | 0, 200 * random() | 0, 200 * random() | 0);
			},
			function() {
				var black = 200 * random() | 0;
				return color(200, black, black);
			},
			function() {
				var black = 200 * random() | 0;
				return color(black, 200, black);
			},
			function() {
				var black = 200 * random() | 0;
				return color(black, black, 200);
			},
			function() {
				return color(200, 100, 200 * random() | 0);
			},
			function() {
				return color(200 * random() | 0, 200, 200);
			},
			function() {
				var black = 256 * random() | 0;
				return color(black, black, black);
			},
			function() {
				return colorThemes[random() < .5 ? 1 : 2]();
			},
			function() {
				return colorThemes[random() < .5 ? 3 : 5]();
			},
			function() {
				return colorThemes[random() < .5 ? 2 : 4]();
			}
		];

		function color(r, g, b) {
			return 'rgb(' + r + ',' + g + ',' + b + ')';
		}

		function interpolation(a, b, t) {
			return (1 - cos(PI * t)) / 2 * (b - a) + a;
		}
		var radius = 1 / eccentricity,
			radius2 = radius + radius;

		function createPoisson() {
			var domain = [radius, 1 - radius],
				measure = 1 - radius2,
				spline = [0, 1];
			while (measure) {
				var dart = measure * random(),
					i, l, interval, a, b, c, d;
				for (i = 0, l = domain.length, measure = 0; i < l; i += 2) {
					a = domain[i], b = domain[i + 1], interval = b - a;
					if (dart < measure + interval) {
						spline.push(dart += a - measure);
						break;
					}
					measure += interval;
				}
				c = dart - radius, d = dart + radius;
				for (i = domain.length - 1; i > 0; i -= 2) {
					l = i - 1, a = domain[l], b = domain[i];
					if (a >= c && a < d)
						if (b > d) domain[l] = d;
						else domain.splice(l, 2);
					else if (a < c && b > c)
						if (b <= d) domain[i] = c;
						else domain.splice(i, 0, c, d);
				}
				for (i = 0, l = domain.length, measure = 0; i < l; i += 2) measure += domain[i + 1] - domain[i];
			}
			return spline.sort();
		}
		var container = document.createElement('div');
		container.style.position = 'fixed';
		container.id = 'confetti'
		container.style.top = '0';
		container.style.left = '0';
		container.style.width = '100%';
		container.style.height = '0';
		container.style.overflow = 'visible';
		container.style.zIndex = '9999';

		function Confetto(theme) {
			this.frame = 0;
			this.outer = document.createElement('div');
			this.inner = document.createElement('div');
			this.outer.appendChild(this.inner);
			var outerStyle = this.outer.style,
				innerStyle = this.inner.style;
			outerStyle.position = 'absolute';
			outerStyle.width = (sizeMin + sizeMax * random()) + 'px';
			outerStyle.height = (sizeMin + sizeMax * random()) + 'px';
			innerStyle.width = '100%';
			innerStyle.height = '100%';
			innerStyle.backgroundColor = theme();
			outerStyle.perspective = '50px';
			outerStyle.transform = 'rotate(' + (360 * random()) + 'deg)';
			this.axis = 'rotate3D(' + cos(360 * random()) + ',' + cos(360 * random()) + ',0,';
			this.theta = 360 * random();
			this.dTheta = dThetaMin + dThetaMax * random();
			innerStyle.transform = this.axis + this.theta + 'deg)';
			this.x = window.innerWidth * random();
			this.y = -deviation;
			this.dx = sin(dxThetaMin + dxThetaMax * random());
			this.dy = dyMin + dyMax * random();
			outerStyle.left = this.x + 'px';
			outerStyle.top = this.y + 'px';
			this.splineX = createPoisson();
			this.splineY = [];
			for (var i = 1, l = this.splineX.length - 1; i < l; ++i) this.splineY[i] = deviation * random();
			this.splineY[0] = this.splineY[l] = deviation * random();
			this.update = function(height, delta) {
				this.frame += delta;
				this.x += this.dx * delta;
				this.y += this.dy * delta;
				this.theta += this.dTheta * delta;
				var phi = this.frame % 7777 / 7777,
					i = 0,
					j = 1;
				while (phi >= this.splineX[j]) i = j++;
				var rho = interpolation(this.splineY[i], this.splineY[j],
					(phi - this.splineX[i]) / (this.splineX[j] - this.splineX[i]));
				phi *= PI2;
				outerStyle.left = this.x + rho * cos(phi) + 'px';
				outerStyle.top = this.y + rho * sin(phi) + 'px';
				innerStyle.transform = this.axis + this.theta + 'deg)';
				return this.y > height + deviation;
			};
		}

		function poof() {
			if (!frame) {
				document.body.appendChild(container);
				var theme = colorThemes[0],
					count = 0;
				(function addConfetto() {
					var confetto = new Confetto(theme);
					confetti.push(confetto);
					container.appendChild(confetto.outer);
					timer = setTimeout(addConfetto, spread * random());
				})(0);
				var prev = undefined;
				requestAnimationFrame(function loop(timestamp) {
					var delta = prev ? timestamp - prev : 0;
					prev = timestamp;
					var height = window.innerHeight;
					for (var i = confetti.length - 1; i >= 0; --i) {
						if (confetti[i].update(height, delta)) {
							container.removeChild(confetti[i].outer);
							confetti.splice(i, 1);
						}
					}
					if (timer || confetti.length) return frame = requestAnimationFrame(loop);
					document.body.removeChild(container);
					frame = undefined;
				});
			}
		}
		poof();
	}
	try {
		var languageCode = (await (await fetch('https://locale.roblox.com/v1/locales/user-localization-locus-supported-locales', {
			credentials: 'include'
		})).json())['generalExperience']['locale']
	} catch {
		var languageCode = 'en_us'
	}
	try {
		var colorTheme = (await (await fetch('https://apis.roblox.com/user-settings-api/v1/user-settings', {
			credentials: 'include'
		})).json())['themeType']
		if (colorTheme == 'Dark') {
			var loadingImage = chrome.runtime.getURL('images/loadingDark.png')
			var boldFontColor = 'color: #FFFFFF;'
			var descFontColor = "#FFFFFF"
		} else {
			var loadingImage = chrome.runtime.getURL('images/loadingLight.png')
			var boldFontColor = 'color: #000000;'
			var descFontColor = "#000000"
		}
	} catch {
		var loadingImage = chrome.runtime.getURL('images/loadingLight.png')
		var boldFontColor = 'color: #000000;'
		var descFontColor = "#000000"
	}
	if (languageCode == 'en_us') {
		var shareButton_Translated = 'Share'
		var shareBloxFinder_Translated = 'Share BloxFinder'
		var copyButtonText_Translated = 'Copy'
		var copiedText_Translated = 'Copied!'
	}
	if (languageCode == 'id_id') {
		var shareButton_Translated = 'Bagikan'
		var shareBloxFinder_Translated = 'Bagikan BloxFinder'
		var copyButtonText_Translated = 'Salin'
		var copiedText_Translated = 'Tersalin!'
	}
	if (languageCode == 'de_de') {
		var shareButton_Translated = 'Teilen'
		var shareBloxFinder_Translated = 'BloxFinder teilen'
		var copyButtonText_Translated = 'Kopieren'
		var copiedText_Translated = 'Kopiert!'
	}
	if (languageCode == 'es_es') {
		var shareButton_Translated = 'Compartir'
		var shareBloxFinder_Translated = 'Compartir BloxFinder'
		var copyButtonText_Translated = 'Copiar'
		var copiedText_Translated = 'Copiado!'
	}
	if (languageCode == 'fr_fr') {
		var shareButton_Translated = 'Partager'
		var shareBloxFinder_Translated = 'Partager BloxFinder'
		var copyButtonText_Translated = 'Copier'
		var copiedText_Translated = 'Copié!'
	}
	if (languageCode == 'it_it') {
		var shareButton_Translated = 'Condividi'
		var shareBloxFinder_Translated = 'Condividi BloxFinder'
		var copyButtonText_Translated = 'Copia'
		var copiedText_Translated = 'Copiato!'
	}
	if (languageCode == 'pl_pl') {
		var shareButton_Translated = 'Udostępnij'
		var shareBloxFinder_Translated = 'Udostępnij BloxFinder'
		var copyButtonText_Translated = 'Kopiuj'
		var copiedText_Translated = 'Skopiowano!'
	}
	if (languageCode == 'pt_br') {
		var shareButton_Translated = 'Compartilhar'
		var shareBloxFinder_Translated = 'Compartilhar BloxFinder'
		var copyButtonText_Translated = 'Copiar'
		var copiedText_Translated = 'Copiado!'
	}
	if (languageCode == 'vi_vn') {
		var shareButton_Translated = 'Chia sẻ'
		var shareBloxFinder_Translated = 'Chia sẻ BloxFinder'
		var copyButtonText_Translated = 'Sao chép'
		var copiedText_Translated = 'Đã sao chép!'
	}
	if (languageCode == 'tr_tr') {
		var shareButton_Translated = 'Paylaş'
		var shareBloxFinder_Translated = 'BloxFinder Paylaş'
		var copyButtonText_Translated = 'Kopyala'
		var copiedText_Translated = 'Kopyalandı!'
	}
	if (languageCode == 'th_th') {
		var shareButton_Translated = 'แบ่งปัน'
		var shareBloxFinder_Translated = 'แบ่งปัน BloxFinder'
		var copyButtonText_Translated = 'คัดลอก'
		var copiedText_Translated = 'คัดลอกแล้ว!'
	}
	if (languageCode == 'zh_cn') {
		var shareButton_Translated = '分享'
		var shareBloxFinder_Translated = '分享 BloxFinder'
		var copyButtonText_Translated = '复制'
		var copiedText_Translated = '已复制!'
	}
	if (languageCode == 'zh_tw') {
		var shareButton_Translated = '分享'
		var shareBloxFinder_Translated = '分享 BloxFinder'
		var copyButtonText_Translated = '複製'
		var copiedText_Translated = '已複製!'
	}
	if (languageCode == 'ja_jp') {
		var shareButton_Translated = '共有'
		var shareBloxFinder_Translated = 'BloxFinder を共有'
		var copyButtonText_Translated = 'コピー'
		var copiedText_Translated = 'コピーしました!'
	}
	if (languageCode == 'ko_kr') {
		var shareButton_Translated = '공유'
		var shareBloxFinder_Translated = 'BloxFinder 공유'
		var copyButtonText_Translated = '복사'
		var copiedText_Translated = '복사됨!'
	}
	if (languageCode == 'ar_001') {
		var shareButton_Translated = 'شارك'
		var shareBloxFinder_Translated = 'شارك BloxFinder'
		var copyButtonText_Translated = 'نسخ'
		var copiedText_Translated = 'تم النسخ!'
	}
	if (languageCode == 'en_us') {
		var invalidUserId_Translated = "Invalid User ID"
		var attemptsTotal_Translated = "Attempts: 666";
		var repeatSearch_Translated = "Repeat Search Until Found"
		var howRepeatWorks_Translated = 'How "Repeat Search Until Found" Works'
		var whatItDoes_Translated = "What it does:"
		var whatItDoesDesc_Translated = "When enabled, the extension will automatically keep searching for the player if they're not found in the first attempt."
		var note_Translated = "Note:"
		var noteDesc_Translated = "You can always cancel the search by clicking the X button."
		var information_Translated = `<strong>Want to continuously search for your player until they are found?<br><br>Enable the "<span style="font-weight: bold; ${boldFontColor}">Repeat Search Until Found</span>" checkbox before searching!</strong>`;
		var enterUsername_Translated = 'Enter Username'
		var enterUserID_Translated = 'Enter User ID'
		var lowServerSizeTitle_Translated = 'Low Server Size'
		var lowServerSizeSummary_Translated = 'This game has a maximum server size of 1 player.'
		var successChanceTooltip_Translated = 'Roblox shows 5 players on each server, so we calculate 5 out of the Server Size as a percentage to determine the chance of success!'
		var successChanceText_Translated = 'You have a 666% chance of success'
		var showTotalServersChecked_Translated = 'Show total servers checked'
		var playMusic_Translated = 'Play music when user has been found'
		var confettiParticles_Translated = 'Confetti particles when user has been found'
		var serversCheckedTotal_Translated = 'Servers Checked: 666'
		var whoDoYouWantToFind_Translated = `Who do you want to find?`
		var username_Translated = `Username`
		var userId_Translated = `User ID`
		var find_Translated = `Find`
		var invalidUsername_Translated = `Invalid Username`
		var largePlayerCount_Translated = `⚠️ Due to the large number of players in this game, it will take longer to locate the user!`
		var cancelSearching_Translated = `Do you want to cancel searching? (Click OK to cancel)`
		var searching_Translated = `Searching`
		var tryAgain_Translated = `Try Again`
		var notFound_Translated = `User not found ❌`
		var weFoundThem_Translated = `We found them!`
		var joinButton_Translated = `Join`
		var giveUsAReview_Translated = `Did this help? Give us a review!`
	}
	if (languageCode == 'id_id') {
		var invalidUserId_Translated = "ID Pengguna Tidak Valid"
		var attemptsTotal_Translated = "Jumlah percobaan: 666"
		var repeatSearch_Translated = "Ulangi Pencarian Hingga Ditemukan"
		var howRepeatWorks_Translated = 'Cara Kerja "Ulangi Pencarian Hingga Ditemukan"'
		var whatItDoes_Translated = "Apa fungsinya:"
		var whatItDoesDesc_Translated = "Saat diaktifkan, ekstensi akan secara otomatis terus mencari pemain jika mereka tidak ditemukan pada percobaan pertama."
		var note_Translated = "Catatan:"
		var noteDesc_Translated = "Anda selalu dapat membatalkan pencarian dengan mengeklik tombol X."
		var enterUsername_Translated = 'Masukkan Nama Pengguna'
		var enterUserID_Translated = 'Masukkan ID Pengguna'
		var information_Translated = `<strong>Ingin terus mencari pemain Anda sampai mereka ditemukan?<br><br>Aktifkan kotak centang "<span style="font-weight: bold; ${boldFontColor}">Ulangi Pencarian Hingga Ditemukan</span>" sebelum mencari!</strong>`;
		var lowServerSizeTitle_Translated = 'Ukuran Server Rendah'
		var lowServerSizeSummary_Translated = 'Game ini memiliki ukuran server maksimal 1 pemain.'
		var successChanceTooltip_Translated = 'Roblox menampilkan 5 pemain di setiap server, jadi kami menghitung 5 dari Ukuran Server sebagai persentase untuk menentukan peluang keberhasilan!'
		var successChanceText_Translated = 'Anda memiliki peluang sukses 666%'
		var showTotalServersChecked_Translated = 'Tampilkan total server yang dicentang'
		var playMusic_Translated = 'Putar musik saat pengguna telah ditemukan'
		var confettiParticles_Translated = 'Partikel confetti ketika pengguna telah ditemukan'
		var serversCheckedTotal_Translated = 'Server Diperiksa: 666'
		var whoDoYouWantToFind_Translated = `Siapa yang ingin Anda temukan?`
		var username_Translated = `Nama pengguna`
		var find_Translated = `Temukan`
		var userId_Translated = `ID`
		var invalidUsername_Translated = `Nama pengguna tidak valid`
		var largePlayerCount_Translated = `⚠️ Karena banyaknya pemain dalam permainan ini, akan butuh waktu lebih lama untuk menemukan pengguna!`
		var cancelSearching_Translated = `Apakah Anda ingin membatalkan pencarian? (Klik OK untuk membatalkan)`
		var searching_Translated = `Pencarian`
		var tryAgain_Translated = `Coba lagi`
		var notFound_Translated = `Pengguna tidak ditemukan ❌`
		var weFoundThem_Translated = `Kami menemukan mereka!`
		var joinButton_Translated = `Bergabung`
		var giveUsAReview_Translated = `Apakah ini membantu? Beri kami ulasan!`
	}
	if (languageCode == 'de_de') {
		var invalidUserId_Translated = "Ungültige Benutzer-ID"
		var attemptsTotal_Translated = "Versuche: 666"
		var repeatSearch_Translated = "Suche wiederholen bis gefunden"
		var howRepeatWorks_Translated = 'So funktioniert „Suche wiederholen, bis gefunden“'
		var whatItDoes_Translated = "Was es bewirkt:"
		var whatItDoesDesc_Translated = "When enabled, the extension will automatically keep searching for the player if they're not found in the first attempt."
		var note_Translated = "Notiz:"
		var noteDesc_Translated = "Sie können die Suche jederzeit abbrechen, indem Sie auf die Schaltfläche X klicken."
		var enterUsername_Translated = 'Benutzernamen eingeben'
		var enterUserID_Translated = 'Benutzer-ID eingeben'
		var information_Translated = `<strong>Möchten Sie kontinuierlich nach Ihrem Spieler suchen, bis er gefunden wird?<br><br>Aktivieren Sie das Kontrollkästchen "<span style="font-weight: bold; ${boldFontColor}">Suche wiederholen bis gefunden</span>" bevor Sie die Suche starten!</strong>`;
		var lowServerSizeTitle_Translated = 'Geringe Servergröße'
		var lowServerSizeSummary_Translated = 'Dieses Spiel hat eine maximale Servergröße von 1 Spieler.'
		var successChanceTooltip_Translated = 'Roblox zeigt 5 Spieler auf jedem Server an, daher berechnen wir 5 aus der Servergröße als Prozentsatz, um die Erfolgschance zu bestimmen!'
		var successChanceText_Translated = 'Sie haben eine Erfolgschance von 666%'
		var showTotalServersChecked_Translated = 'Gesamtzahl der überprüften Server anzeigen'
		var playMusic_Translated = 'Musik abspielen, wenn der Benutzer gefunden wurde'
		var confettiParticles_Translated = 'Konfettipartikel, wenn der Benutzer gefunden wurde'
		var serversCheckedTotal_Translated = 'Überprüfte Server: 666'
		var whoDoYouWantToFind_Translated = `Wen möchtest du finden?`
		var username_Translated = `Benutzername:`
		var find_Translated = `Suchen`
		var userId_Translated = `ID`
		var invalidUsername_Translated = `Ungültiger Benutzername`
		var largePlayerCount_Translated = `⚠️ Aufgrund der großen Anzahl an Spielern in diesem Spiel dauert es länger, den Benutzer zu finden!`
		var cancelSearching_Translated = `Möchtest du die Suche abbrechen? (Klicke auf „OK“, um abzubrechen)`
		var searching_Translated = `Suche läuft`
		var tryAgain_Translated = `Erneut versuchen`
		var notFound_Translated = `Benutzer nicht gefunden ❌`
		var weFoundThem_Translated = `Wir haben ihn gefunden!`
		var joinButton_Translated = `Beitreten`
		var giveUsAReview_Translated = `Gib uns eine Bewertung!`
	}
	if (languageCode == 'es_es') {
		var invalidUserId_Translated = "ID de usuario no válido"
		var attemptsTotal_Translated = "Intentos: 666"
		var repeatSearch_Translated = "Repetir búsqueda hasta encontrar"
		var howRepeatWorks_Translated = 'Cómo funciona "Repetir búsqueda hasta encontrar"'
		var whatItDoes_Translated = "Qué hace la función:"
		var whatItDoesDesc_Translated = "Cuando está habilitada, la extensión seguirá buscando automáticamente al reproductor si no lo encuentra en el primer intento."
		var note_Translated = "Nota:"
		var noteDesc_Translated = "Siempre puedes cancelar la búsqueda haciendo clic en el botón X."
		var enterUsername_Translated = 'Introduce nombre de usuario'
		var enterUserID_Translated = 'Introduce ID de usuario'
		var lowServerSizeTitle_Translated = 'Bajo tamaño del servidor'
		var information_Translated = `<strong>¿Quieres buscar continuamente a tu jugador hasta que sea encontrado?<br><br>¡Activa la casilla "<span style="font-weight: bold; ${boldFontColor}">Repetir búsqueda hasta encontrar</span>" antes de buscar!</strong>`;
		var lowServerSizeSummary_Translated = 'Este juego tiene un tamaño máximo de servidor de 1 jugador.'
		var successChanceTooltip_Translated = 'Roblox muestra 5 jugadores en cada servidor, por lo que calculamos 5 del tamaño del servidor como un porcentaje para determinar las posibilidades de éxito.'
		var successChanceText_Translated = 'Tienes un 666% de posibilidades de éxito'
		var showTotalServersChecked_Translated = 'Mostrar el total de servidores comprobados'
		var playMusic_Translated = 'Reproducir música cuando se ha encontrado al usuario'
		var confettiParticles_Translated = 'Partículas de confeti cuando se ha encontrado al usuario'
		var serversCheckedTotal_Translated = 'Servidores comprobados: 666'
		var whoDoYouWantToFind_Translated = `¿A quién quieres encontrar?`
		var username_Translated = `Usuario:`
		var find_Translated = `Buscar`
		var userId_Translated = `ID`
		var invalidUsername_Translated = `Nombre de usuario no válido`
		var largePlayerCount_Translated = `⚠️ Debido a la gran cantidad de jugadores en este juego, ¡tomará más tiempo localizar al usuario!`
		var cancelSearching_Translated = `¿Quieres cancelar la búsqueda? (Haz clic en Aceptar para cancelar)`
		var searching_Translated = `Buscando`
		var tryAgain_Translated = `Intenta de nuevo`
		var notFound_Translated = `No se encontró el usuario ❌`
		var weFoundThem_Translated = `¡Lo encontramos!`
		var joinButton_Translated = `Únete`
		var giveUsAReview_Translated = `¿Te resultó útil? ¡Danos una reseña!`
	}
	if (languageCode == 'fr_fr') {
		var invalidUserId_Translated = "ID utilisateur invalide"
		var attemptsTotal_Translated = "Tentatives : 666"
		var repeatSearch_Translated = "Répéter la recherche jusqu'à ce qu'il soit trouvé"
		var howRepeatWorks_Translated = "Comment fonctionne « Répéter la recherche jusqu'à ce qu'elle soit trouvée »"
		var whatItDoes_Translated = "Fonctionnement:"
		var whatItDoesDesc_Translated = "Lorsqu'elle est activée, l'extension recherche automatiquement le lecteur si elle ne le trouve pas du premier coup."
		var note_Translated = "Remarque:"
		var noteDesc_Translated = "Vous pouvez annuler la recherche à tout moment en cliquant sur le bouton X."
		var enterUsername_Translated = "Entrez nom d'utilisateur"
		var enterUserID_Translated = "Entrez ID utilisateur"
		var information_Translated = `<strong>Voulez-vous rechercher continuellement votre joueur jusqu'à ce qu'il soit trouvé ?<br><br>Activez la case à cocher "<span style="font-weight: bold; ${boldFontColor}">Répéter la recherche jusqu'à ce qu'il soit trouvé</span>" avant de lancer la recherche !</strong>`;
		var lowServerSizeTitle_Translated = 'Faible taille du serveur'
		var lowServerSizeSummary_Translated = 'Ce jeu a une taille de serveur maximale de 1 joueur.'
		var successChanceTooltip_Translated = 'Roblox affiche 5 joueurs sur chaque serveur, nous calculons donc 5 sur la taille du serveur en pourcentage pour déterminer les chances de succès !'
		var successChanceText_Translated = 'Vous avez 666% de chances de succès'
		var showTotalServersChecked_Translated = 'Afficher le nombre total de serveurs vérifiés'
		var playMusic_Translated = 'Jouer de la musique lorsque l’utilisateur a été trouvé'
		var confettiParticles_Translated = 'Particules de confettis lorsque l’utilisateur a été trouvé'
		var serversCheckedTotal_Translated = 'Serveurs vérifiés : 666'
		var whoDoYouWantToFind_Translated = `Qui voulez-vous trouver ?`
		var userId_Translated = `ID`
		var username_Translated = `Nom d'utilisateur:`
		var find_Translated = `Rechercher`
		var invalidUsername_Translated = `Nom d'utilisateur non valide`
		var largePlayerCount_Translated = `⚠️ En raison du grand nombre de joueurs dans ce jeu, il faudra plus de temps pour localiser l'utilisateur !`
		var cancelSearching_Translated = `Voulez-vous annuler la recherche ? (Cliquez sur OK pour annuler)`
		var searching_Translated = `Recherche`
		var tryAgain_Translated = `Réessayer`
		var notFound_Translated = `Utilisateur non trouvé ❌`
		var weFoundThem_Translated = `Nous l'avons trouvé !`
		var joinButton_Translated = `Rejoignez-nous`
		var giveUsAReview_Translated = `Donnez-nous votre avis !`
	}
	if (languageCode == 'it_it') {
		var invalidUserId_Translated = "ID utente non valido"
		var attemptsTotal_Translated = "Tentativi: 666"
		var repeatSearch_Translated = "Ripeti ricerca fino al ritrovamento"
		var howRepeatWorks_Translated = 'Come funziona "Ripeti ricerca finché non viene trovato"'
		var whatItDoes_Translated = "A cosa serve:"
		var whatItDoesDesc_Translated = "Se abilitata, l'estensione continuerà automaticamente a cercare il player se non viene trovato al primo tentativo."
		var note_Translated = "Nota:"
		var noteDesc_Translated = "Puoi sempre annullare la ricerca cliccando sul pulsante X."
		var enterUsername_Translated = "Inserisci nome utente"
		var enterUserID_Translated = "Inserisci ID utente"
		var lowServerSizeTitle_Translated = 'Dimensioni ridotte del server'
		var information_Translated = `<strong>Vuoi cercare continuamente il tuo giocatore finché non viene trovato?<br><br>Attiva la casella "<span style="font-weight: bold; ${boldFontColor}">Ripeti ricerca fino al ritrovamento</span>" prima di iniziare la ricerca!</strong>`;
		var lowServerSizeSummary_Translated = 'Questo gioco ha una dimensione massima del server di 1 giocatore.'
		var successChanceTooltip_Translated = 'Roblox mostra 5 giocatori su ogni server, quindi calcoliamo 5 delle dimensioni del server in percentuale per determinare le possibilità di successo!'
		var successChanceText_Translated = 'Hai una probabilità di successo del 666%'
		var showTotalServersChecked_Translated = 'Mostra il totale dei server controllati'
		var playMusic_Translated = "Riproduci musica quando l'utente è stato trovato"
		var confettiParticles_Translated = "Particelle di coriandoli quando l'utente è stato trovato"
		var serversCheckedTotal_Translated = 'Server controllati: 666'
		var whoDoYouWantToFind_Translated = `Chi vuoi trovare?`
		var userId_Translated = `ID`
		var username_Translated = `Nome utente:`
		var find_Translated = `Trova`
		var invalidUsername_Translated = `Nome utente non valido`
		var largePlayerCount_Translated = `⚠️ A causa del gran numero di giocatori in questo gioco, ci vorrà più tempo per trovare l'utente!`
		var cancelSearching_Translated = `Vuoi annullare la ricerca? (Clicca su OK per annullare)`
		var searching_Translated = `Ricerca in corso`
		var tryAgain_Translated = `Riprova`
		var notFound_Translated = `Utente non trovato ❌`
		var weFoundThem_Translated = `Li abbiamo trovati!`
		var joinButton_Translated = `Unisciti`
		var giveUsAReview_Translated = `Ti è stato utile? Lasciaci una recensione!`
	}
	if (languageCode == 'pl_pl') {
		var invalidUserId_Translated = "Nieprawidłowy ID"
		var attemptsTotal_Translated = "Próby: 666"
		var repeatSearch_Translated = "Powtarzaj wyszukiwanie aż do znalezienia"
		var howRepeatWorks_Translated = 'Jak działa „Powtarzaj wyszukiwanie, aż zostanie znalezione”'
		var whatItDoes_Translated = "Co robi:"
		var whatItDoesDesc_Translated = "Po włączeniu rozszerzenie będzie automatycznie kontynuować wyszukiwanie odtwarzacza, jeśli nie zostanie on znaleziony za pierwszym razem."
		var note_Translated = "Uwaga:"
		var noteDesc_Translated = "Zawsze możesz anulować wyszukiwanie, klikając przycisk X."
		var enterUsername_Translated = "Wprowadź nazwę użytkownika"
		var enterUserID_Translated = "Wprowadź ID użytkownika"
		var lowServerSizeTitle_Translated = 'Mały rozmiar serwera'
		var information_Translated = `<strong>Chcesz nieprzerwanie szukać swojego gracza, dopóki nie zostanie znaleziony?<br><br>Zaznacz pole "<span style="font-weight: bold; ${boldFontColor}">Powtarzaj wyszukiwanie aż do znalezienia</span>" przed rozpoczęciem wyszukiwania!</strong>`;
		var lowServerSizeSummary_Translated = 'Maksymalny rozmiar serwera w tej grze to 1 gracz.'
		var successChanceTooltip_Translated = 'Roblox pokazuje 5 graczy na każdym serwerze, więc obliczamy 5 z rozmiaru serwera w procentach, aby określić szansę na sukces!'
		var successChanceText_Translated = 'Masz 666% szans na sukces'
		var showTotalServersChecked_Translated = 'Pokaż łączną liczbę sprawdzonych serwerów'
		var playMusic_Translated = 'Odtwarzaj muzykę, gdy użytkownik zostanie znaleziony'
		var confettiParticles_Translated = 'Cząsteczki konfetti, gdy użytkownik zostanie znaleziony'
		var serversCheckedTotal_Translated = 'Sprawdzone serwery: 666'
		var whoDoYouWantToFind_Translated = `Kogo chcesz znaleźć?`
		var userId_Translated = `ID`
		var username_Translated = `Użytkownik:`
		var find_Translated = `Znajdź`
		var invalidUsername_Translated = `Nieprawidłowa nazwa użytkownika`
		var largePlayerCount_Translated = `⚠️ Ze względu na dużą liczbę graczy w tej grze, znalezienie użytkownika zajmie więcej czasu!`
		var cancelSearching_Translated = `Czy chcesz anulować wyszukiwanie? (Kliknij OK, aby anulować)`
		var searching_Translated = `Wyszukiwanie`
		var tryAgain_Translated = `Spróbuj ponownie`
		var notFound_Translated = `Użytkownik nie został znaleziony ❌`
		var weFoundThem_Translated = `Znaleźliśmy go!`
		var joinButton_Translated = `Dołącz`
		var giveUsAReview_Translated = `Czy to pomogło? Oceń nas!`
	}
	if (languageCode == 'pt_br') {
		var invalidUserId_Translated = "ID de usuário inválido"
		var attemptsTotal_Translated = "Tentativas: 666"
		var repeatSearch_Translated = "Repetir Busca Até Encontrar"
		var howRepeatWorks_Translated = 'Como funciona a função "Repetir Busca Até Encontrar"'
		var whatItDoes_Translated = "O que faz:"
		var whatItDoesDesc_Translated = "Quando ativada, a extensão continuará buscando o player automaticamente caso ele não seja encontrado na primeira tentativa."
		var note_Translated = "Observação:"
		var noteDesc_Translated = "Você pode cancelar a busca a qualquer momento clicando no botão X."
		var enterUsername_Translated = "Digite o nome de usuário"
		var enterUserID_Translated = "Digite o ID do usuário"
		var lowServerSizeTitle_Translated = 'Tamanho baixo do servidor'
		var information_Translated = `<strong>Quer buscar continuamente seu jogador até que seja encontrado?<br><br>Ative a caixa de seleção "<span style="font-weight: bold; ${boldFontColor}">Repetir busca até encontrar</span>" antes de pesquisar!</strong>`;
		var lowServerSizeSummary_Translated = 'Este jogo tem um tamanho máximo de servidor de 1 jogador.'
		var successChanceTooltip_Translated = 'Roblox mostra 5 jogadores em cada servidor, então calculamos 5 do tamanho do servidor como uma porcentagem para determinar a chance de sucesso!'
		var successChanceText_Translated = 'Você tem 666% de chance de sucesso'
		var showTotalServersChecked_Translated = 'Mostrar total de servidores verificados'
		var playMusic_Translated = 'Reproduzir música quando o usuário for encontrado'
		var confettiParticles_Translated = 'Partículas de confete quando o usuário foi encontrado'
		var serversCheckedTotal_Translated = 'Servidores verificados: 666'
		var userId_Translated = `ID`
		var whoDoYouWantToFind_Translated = `Quem você quer encontrar?`
		var username_Translated = `Usuário:`
		var find_Translated = `Encontrar`
		var invalidUsername_Translated = `Nome de usuário inválido`
		var largePlayerCount_Translated = `⚠️ Devido ao grande número de jogadores neste jogo, levará mais tempo para localizar o usuário!`
		var cancelSearching_Translated = `Você quer cancelar a busca? (Clique em OK para cancelar)`
		var searching_Translated = `Buscando`
		var tryAgain_Translated = `Tentar novamente`
		var notFound_Translated = `Usuário não encontrado ❌`
		var weFoundThem_Translated = `Nós os encontramos!`
		var joinButton_Translated = `Participar`
		var giveUsAReview_Translated = `Isso ajudou? Dê-nos uma avaliação!`
	}
	if (languageCode == 'vi_vn') {
		var invalidUserId_Translated = "ID không hợp lệ"
		var attemptsTotal_Translated = "Số lần thử: 666"
		var repeatSearch_Translated = "Lặp lại tìm kiếm cho đến khi tìm thấy"
		var howRepeatWorks_Translated = 'Cách thức hoạt động của "Lặp lại tìm kiếm cho đến khi tìm thấy"'
		var whatItDoes_Translated = "Công dụng:"
		var whatItDoesDesc_Translated = "Khi được bật, tiện ích mở rộng sẽ tự động tiếp tục tìm kiếm người chơi nếu không tìm thấy họ trong lần thử đầu tiên."
		var note_Translated = "Lưu ý:"
		var noteDesc_Translated = "Bạn luôn có thể hủy tìm kiếm bằng cách nhấp vào nút X."
		var enterUsername_Translated = "Nhập tên người dùng"
		var enterUserID_Translated = "Nhập ID người dùng"
		var lowServerSizeTitle_Translated = 'Kích thước máy chủ thấp'
		var information_Translated = `<strong>Bạn muốn tiếp tục tìm kiếm người chơi của mình cho đến khi tìm thấy?<br><br>Hãy bật hộp kiểm "<span style="font-weight: bold; ${boldFontColor}">Lặp lại tìm kiếm cho đến khi tìm thấy</span>" trước khi tìm kiếm!</strong>`;
		var lowServerSizeSummary_Translated = 'Trò chơi này có kích thước máy chủ tối đa là 1 người chơi.'
		var successChanceTooltip_Translated = 'Roblox hiển thị 5 người chơi trên mỗi máy chủ, vì vậy chúng tôi tính toán 5 trên Kích thước máy chủ theo tỷ lệ phần trăm để xác định cơ hội thành công!'
		var successChanceText_Translated = 'Bạn có 666% cơ hội thành công'
		var showTotalServersChecked_Translated = 'Hiển thị tổng số máy chủ đã kiểm tra'
		var playMusic_Translated = 'Phát nhạc khi tìm thấy người dùng'
		var confettiParticles_Translated = 'Hạt hoa giấy khi đã tìm thấy người dùng'
		var serversCheckedTotal_Translated = 'Máy chủ đã kiểm tra: 666'
		var whoDoYouWantToFind_Translated = `Bạn muốn tìm ai?`
		var userId_Translated = `ID`
		var username_Translated = `Tên người dùng:`
		var find_Translated = `Tìm`
		var invalidUsername_Translated = `Tên người dùng không hợp lệ`
		var largePlayerCount_Translated = `⚠️ Do số lượng người chơi trong trò chơi này quá lớn nên sẽ mất nhiều thời gian hơn để tìm thấy người dùng!`
		var cancelSearching_Translated = `Bạn có muốn hủy tìm kiếm không? (Nhấp vào OK để hủy)`
		var searching_Translated = `Đang tìm kiếm`
		var tryAgain_Translated = `Thử lại`
		var notFound_Translated = `Không tìm thấy người dùng ❌`
		var weFoundThem_Translated = `Chúng tôi đã tìm thấy họ!`
		var joinButton_Translated = `Tham gia`
		var giveUsAReview_Translated = `Hãy cho chúng tôi một đánh giá!`
	}
	if (languageCode == 'tr_tr') {
		var invalidUserId_Translated = "Geçersiz kimlik"
		var attemptsTotal_Translated = "Denemeler: 666"
		var repeatSearch_Translated = "Bulunana Kadar Aramayı Tekrarla"
		var howRepeatWorks_Translated = '"Bulunana Kadar Aramayı Tekrarla" Nasıl Çalışır'
		var whatItDoes_Translated = "Ne işe yarar:"
		var whatItDoesDesc_Translated = "Etkinleştirildiğinde, uzantı ilk denemede bulunamazsa otomatik olarak oyuncuyu aramaya devam eder."
		var note_Translated = "Not:"
		var noteDesc_Translated = "X düğmesine tıklayarak aramayı her zaman iptal edebilirsiniz."
		var enterUsername_Translated = "Kullanıcı adı girin"
		var enterUserID_Translated = "Kullanıcı ID girin"
		var information_Translated = `<strong>Oyuncunuz bulunana kadar sürekli aramak istiyor musunuz?<br><br>Aramaya başlamadan önce "<span style="font-weight: bold; ${boldFontColor}">Bulunana Kadar Aramayı Tekrarla</span>" onay kutusunu etkinleştirin!</strong>`;
		var lowServerSizeTitle_Translated = 'Düşük Sunucu Boyutu'
		var lowServerSizeSummary_Translated = 'Bu oyunun maksimum sunucu boyutu 1 oyuncudur.'
		var successChanceTooltip_Translated = "Roblox her sunucuda 5 oyuncu gösterir, bu nedenle başarı şansını belirlemek için Sunucu Boyutundan 5'i yüzde olarak hesaplıyoruz!"
		var successChanceText_Translated = '%666 başarı şansınız var'
		var showTotalServersChecked_Translated = 'Kontrol edilen toplam sunucuları göster'
		var playMusic_Translated = 'Kullanıcı bulunduğunda müzik çalın'
		var confettiParticles_Translated = 'Kullanıcı bulunduğunda konfeti parçacıkları'
		var serversCheckedTotal_Translated = 'Kontrol edilen sunucular: 666'
		var whoDoYouWantToFind_Translated = `Kimi bulmak istiyorsun?`
		var username_Translated = `Kullanıcı adı:`
		var find_Translated = `Bul`
		var userId_Translated = `ID`
		var invalidUsername_Translated = `Geçersiz Kullanıcı Adı`
		var largePlayerCount_Translated = `⚠️ Bu oyunda çok sayıda oyuncu olması nedeniyle, kullanıcıyı bulmak daha uzun sürecek!`
		var cancelSearching_Translated = `Aramayı iptal etmek istiyor musun? (İptal etmek için Tamam'a tıkla)`
		var searching_Translated = `Aranıyor`
		var tryAgain_Translated = `Tekrar Dene`
		var notFound_Translated = `Kullanıcı bulunamadı ❌`
		var weFoundThem_Translated = `Onları bulduk!`
		var joinButton_Translated = `Katıl`
		var giveUsAReview_Translated = `Bu yardımcı oldu mu? Bize bir yorum yap!`
	}
	if (languageCode == 'th_th') {
		var invalidUserId_Translated = "รหัสผู้ใช้ไม่ถูกต้อง"
		var attemptsTotal_Translated = "จำนวนครั้งในการพยายาม: 666"
		var repeatSearch_Translated = "ค้นหาซ้ำจนกว่าจะพบ"
		var howRepeatWorks_Translated = 'วิธีการทำงานของ "ค้นหาซ้ำจนกว่าจะพบ"'
		var whatItDoes_Translated = "การทำงาน:"
		var whatItDoesDesc_Translated = "เมื่อเปิดใช้งาน ส่วนขยายจะทำการค้นหาโปรแกรมเล่นต่อโดยอัตโนมัติหากไม่พบโปรแกรมเล่นในครั้งแรก"
		var note_Translated = "หมายเหตุ:"
		var noteDesc_Translated = "คุณสามารถยกเลิกการค้นหาได้ตลอดเวลาโดยคลิกปุ่ม X"
		var enterUsername_Translated = "กรอกชื่อผู้ใช้"
		var enterUserID_Translated = "กรอก ID ผู้ใช้"
		var lowServerSizeTitle_Translated = 'ขนาดเซิร์ฟเวอร์ต่ํา'
		var information_Translated = `<strong>ต้องการค้นหาผู้เล่นของคุณอย่างต่อเนื่องจนกว่าจะพบหรือไม่?<br><br>เปิดใช้งานช่องทำเครื่องหมาย "<span style="font-weight: bold; ${boldFontColor}">ค้นหาซ้ำจนกว่าจะพบ</span>" ก่อนที่จะค้นหา!</strong>`;
		var lowServerSizeSummary_Translated = 'เกมนี้มีขนาดเซิร์ฟเวอร์สูงสุด 1 ผู้เล่น'
		var successChanceTooltip_Translated = 'Roblox แสดงผู้เล่น 5 คนในแต่ละเซิร์ฟเวอร์ ดังนั้นเราจึงคํานวณ 5 จากขนาดเซิร์ฟเวอร์เป็นเปอร์เซ็นต์เพื่อกําหนดโอกาสในการประสบความสําเร็จ!'
		var successChanceText_Translated = 'คุณมีโอกาสประสบความสําเร็จ 666%'
		var showTotalServersChecked_Translated = 'แสดงเซิร์ฟเวอร์ทั้งหมดที่ตรวจสอบแล้ว'
		var playMusic_Translated = 'เล่นเพลงเมื่อพบผู้ใช้'
		var userId_Translated = `รหัสผู้ใช้`
		var confettiParticles_Translated = 'อนุภาคลูกปาเมื่อพบผู้ใช้'
		var serversCheckedTotal_Translated = 'ตรวจสอบเซิร์ฟเวอร์: 666'
		var whoDoYouWantToFind_Translated = `คุณต้องการค้นหาใคร`
		var username_Translated = `ชื่อผู้ใช้:`
		var find_Translated = `ค้นหา`
		var invalidUsername_Translated = `ชื่อผู้ใช้ไม่ถูกต้อง`
		var largePlayerCount_Translated = `⚠️ เนื่องจากมีผู้เล่นจำนวนมากในเกมนี้ การค้นหาผู้ใช้จะใช้เวลานานกว่าปกติ!`
		var cancelSearching_Translated = `คุณต้องการยกเลิกการค้นหาหรือไม่ (คลิกตกลงเพื่อยกเลิก)`
		var searching_Translated = `กำลังค้นหา`
		var tryAgain_Translated = `ลองอีกครั้ง`
		var notFound_Translated = `ไม่พบผู้ใช้ ❌`
		var weFoundThem_Translated = `เราพบพวกเขาแล้ว!`
		var joinButton_Translated = `เข้าร่วม`
		var giveUsAReview_Translated = `สิ่งนี้มีประโยชน์หรือไม่ แสดงความคิดเห็นกับเรา!`
	}
	if (languageCode == 'zh_cn') {
		var invalidUserId_Translated = "无效的用户 ID"
		var attemptsTotal_Translated = "尝试次数：666"
		var repeatSearch_Translated = "重复搜索直到找到"
		var howRepeatWorks_Translated = '“重复搜索直至找到”功能的工作原理'
		var whatItDoes_Translated = "功能："
		var whatItDoesDesc_Translated = "启用后，如果第一次尝试未找到玩家，扩展程序将自动继续搜索。"
		var note_Translated = "注意："
		var noteDesc_Translated = "您可以随时点击 X 按钮取消搜索。"
		var enterUsername_Translated = "输入用户名"
		var enterUserID_Translated = "输入用户ID"
		var information_Translated = `<strong>想要持续搜索您的玩家直到找到为止吗？<br><br>搜索前请启用"<span style="font-weight: bold; ${boldFontColor}">重复搜索直到找到</span>"复选框！</strong>`;
		var lowServerSizeTitle_Translated = '服务器大小小'
		var lowServerSizeSummary_Translated = '此游戏的最大服务器大小为 1 名玩家。'
		var successChanceTooltip_Translated = 'Roblox 在每个服务器上显示 5 名玩家，因此我们计算服务器大小的百分比中的 5 名来确定成功的机会！'
		var successChanceText_Translated = '您有 666% 的成功机会'
		var showTotalServersChecked_Translated = '显示已检查的服务器总数'
		var playMusic_Translated = '找到用户时播放音乐'
		var confettiParticles_Translated = '找到用户时的五彩纸屑颗粒'
		var serversCheckedTotal_Translated = '检查的服务器数： 666'
		var whoDoYouWantToFind_Translated = `你想找谁？`
		var userId_Translated = `用户ID`
		var username_Translated = `用户名：`
		var find_Translated = `查找`
		var invalidUsername_Translated = `用户名无效`
		var largePlayerCount_Translated = `⚠️ 由于此游戏中玩家数量众多，定位用户需要更长时间！`
		var cancelSearching_Translated = `你想取消搜索吗？（点击确定取消）`
		var searching_Translated = `正在搜索`
		var tryAgain_Translated = `重试`
		var notFound_Translated = `未找到用户 ❌`
		var weFoundThem_Translated = `我们找到了他们！`
		var joinButton_Translated = `加入`
		var giveUsAReview_Translated = `这有帮助吗？给我们评论！`
	}
	if (languageCode == 'zh_tw') {
		var invalidUserId_Translated = "無效的使用者 ID"
		var attemptsTotal_Translated = "嘗試次數：666"
		var repeatSearch_Translated = "重複搜尋直到找到"
		var howRepeatWorks_Translated = '「重複搜尋直到找到」如何運作'
		var whatItDoes_Translated = "它的作用："
		var whatItDoesDesc_Translated = "啟用後，如果第一次嘗試未找到播放器，擴充功能將自動繼續搜尋播放器。"
		var note_Translated = "筆記："
		var noteDesc_Translated = "您可以隨時透過點擊 X 按鈕取消搜尋。"
		var enterUsername_Translated = "輸入用戶名稱"
		var enterUserID_Translated = "輸入用戶ID"
		var information_Translated = `<strong>想要持續搜尋您的玩家直到找到為止嗎？<br><br>搜尋前請啟用"<span style="font-weight: bold; ${boldFontColor}">重複搜尋直到找到</span>"核取方塊！</strong>`;
		var lowServerSizeTitle_Translated = '伺服器大小小'
		var lowServerSizeSummary_Translated = '這個遊戲的最大伺服器大小為1名玩家。'
		var successChanceTooltip_Translated = 'Roblox 在每個伺服器上顯示 5 名玩家，因此我們計算伺服器大小的百分比中的 5 名來確定成功的機會！'
		var successChanceText_Translated = '您有 666% 的成功機會'
		var showTotalServersChecked_Translated = '顯示已檢查的伺服器總數'
		var playMusic_Translated = '找到使用者時播放音樂'
		var userId_Translated = `用戶ID`
		var confettiParticles_Translated = '找到用戶時的五彩紙屑顆粒'
		var serversCheckedTotal_Translated = '檢查的伺服器數： 666'
		var whoDoYouWantToFind_Translated = `你想找誰？`
		var username_Translated = `使用者名稱:`
		var find_Translated = `尋找`
		var invalidUsername_Translated = `使用者名稱無效`
		var largePlayerCount_Translated = `⚠️由於該遊戲玩家數量較多，定位使用者的時間會較長！`
		var cancelSearching_Translated = `您想取消搜尋嗎？ （點選確定取消）`
		var searching_Translated = `搜尋中`
		var tryAgain_Translated = `再試一次`
		var notFound_Translated = `未找到用戶 ❌`
		var weFoundThem_Translated = `我們找到他們了！`
		var joinButton_Translated = `加入`
		var giveUsAReview_Translated = `這樣有幫助嗎？給我們一個評論！`
	}
	if (languageCode == 'ja_jp') {
		var invalidUserId_Translated = "無効なユーザーID"
		var attemptsTotal_Translated = "試行回数: 666"
		var repeatSearch_Translated = "見つかるまで検索を繰り返す"
		var howRepeatWorks_Translated = '「見つかるまで検索を繰り返す」の仕組み'
		var whatItDoes_Translated = "機能："
		var whatItDoesDesc_Translated = "有効にすると、最初の試行でプレイヤーが見つからなかった場合、拡張機能は自動的に検索を続行します。"
		var note_Translated = "注："
		var noteDesc_Translated = "Xボタンをクリックすることで、いつでも検索をキャンセルできます。"
		var enterUsername_Translated = "ユーザー名を入力"
		var enterUserID_Translated = "ユーザーIDを入力"
		var lowServerSizeTitle_Translated = 'サーバーサイズが小さい'
		var information_Translated = `<strong>見つかるまでプレイヤーを継続的に検索したいですか？<br><br>検索を開始する前に"<span style="font-weight: bold; ${boldFontColor}">見つかるまで検索を繰り返す</span>"チェックボックスを有効にしてください！</strong>`;
		var lowServerSizeSummary_Translated = 'このゲームの最大サーバーサイズは1人です。'
		var successChanceTooltip_Translated = 'Robloxは各サーバーに5人のプレーヤーを表示するため、サーバーサイズのうち5人をパーセンテージとして計算して、成功の可能性を決定します。'
		var successChanceText_Translated = '成功の確率は666%です'
		var showTotalServersChecked_Translated = 'チェックされたサーバーの合計数を表示'
		var playMusic_Translated = 'ユーザーが見つかったときに音楽を再生する'
		var userId_Translated = `ID`
		var confettiParticles_Translated = 'ユーザーが見つかったときの紙吹雪の粒子'
		var serversCheckedTotal_Translated = 'チェックされたサーバー:666'
		var whoDoYouWantToFind_Translated = `誰を探したいですか?`
		var username_Translated = `ユーザー名:`
		var find_Translated = `検索`
		var invalidUsername_Translated = `無効なユーザー名`
		var largePlayerCount_Translated = `⚠️ このゲームには多数のプレイヤーがいるので、ユーザーを見つけるのに時間がかかります!`
		var cancelSearching_Translated = `検索をキャンセルしますか? (キャンセルするには [OK] をクリックしてください)`
		var searching_Translated = `検索中`
		var tryAgain_Translated = `もう一度試す`
		var notFound_Translated = `ユーザーが見つかりません ❌`
		var weFoundThem_Translated = `見つかりました!`
		var joinButton_Translated = `参加`
		var giveUsAReview_Translated = `役に立ちましたか? レビューを投稿してください!`
	}
	if (languageCode == 'ko_kr') {
		var invalidUserId_Translated = "잘못된 사용자 ID입니다"
		var attemptsTotal_Translated = "시도 횟수: 666회"
		var repeatSearch_Translated = "체크박스를 활성화하세요!"
		var howRepeatWorks_Translated = '"찾을 때까지 반복 검색" 작동 방식'
		var whatItDoes_Translated = "기능:"
		var whatItDoesDesc_Translated = "활성화하면 확장 프로그램이 첫 번째 시도에서 플레이어를 찾지 못할 경우 자동으로 플레이어를 계속 검색합니다."
		var note_Translated = "참고:"
		var noteDesc_Translated = "X 버튼을 클릭하면 언제든지 검색을 취소할 수 있습니다."
		var enterUsername_Translated = "사용자 이름 입력"
		var enterUserID_Translated = "사용자 ID 입력"
		var lowServerSizeTitle_Translated = '낮은 서버 크기'
		var information_Translated = `<strong>플레이어를 찾을 때까지 지속적으로 검색하시겠습니까?<br><br>검색하기 전에 "<span style="font-weight: bold; ${boldFontColor}">찾을 때까지 검색 반복</span>"체크박스를 활성화하세요!</strong>`;
		var lowServerSizeSummary_Translated = '이 게임의 최대 서버 크기는 1명입니다.'
		var successChanceTooltip_Translated = 'Roblox는 각 서버에 5명의 플레이어를 표시하므로 성공 가능성을 결정하기 위해 서버 크기 중 5명을 백분율로 계산합니다!'
		var successChanceText_Translated = '성공할 확률은 666%입니다.'
		var showTotalServersChecked_Translated = '선택된 총 서버 표시'
		var playMusic_Translated = '사용자를 찾았을 때 음악 재생'
		var userId_Translated = `사용자 ID`
		var confettiParticles_Translated = '사용자가 발견되었을 때의 색종이 입자'
		var serversCheckedTotal_Translated = '점검된 서버 수: 666'
		var whoDoYouWantToFind_Translated = `누구를 찾으시겠습니까?`
		var username_Translated = `사용자 이름:`
		var find_Translated = `찾기`
		var invalidUsername_Translated = `잘못된 사용자 이름`
		var largePlayerCount_Translated = `⚠️ 이 게임에서는 플레이어가 많기 때문에 사용자를 찾는 데 시간이 더 오래 걸립니다!`
		var cancelSearching_Translated = `검색을 취소하시겠습니까? (취소하려면 확인을 클릭하세요)`
		var searching_Translated = `검색 중`
		var tryAgain_Translated = `다시 시도`
		var notFound_Translated = `사용자를 찾을 수 없음 ❌`
		var weFoundThem_Translated = `찾았습니다!`
		var joinButton_Translated = `가입`
		var giveUsAReview_Translated = `도움이 되었나요? 리뷰를 남겨주세요!`
	}
	if (languageCode == 'ar_001') {
		var invalidUserId_Translated = "معرف المستخدم غير صالح"
		var attemptsTotal_Translated = "المحاولات: 666"
		var repeatSearch_Translated = "تكرار البحث حتى العثور"
		var howRepeatWorks_Translated = 'كيفية عمل ميزة "تكرار البحث حتى العثور عليه"'
		var whatItDoes_Translated = "الوظيفة:"
		var whatItDoesDesc_Translated = "عند تفعيلها، ستواصل الإضافة البحث تلقائيًا عن اللاعب إذا لم يتم العثور عليه من المحاولة الأولى."
		var note_Translated = "ملاحظة:"
		var noteDesc_Translated = "يمكنك دائمًا إلغاء البحث بالنقر على زر X."
		var enterUsername_Translated = "أدخل اسم المستخدم"
		var enterUserID_Translated = "أدخل معرف المستخدم"
		var lowServerSizeTitle_Translated = 'حجم خادم صغير'
		var information_Translated = `<strong>هل تريد البحث المستمر عن لاعبك حتى يتم العثور عليه؟<br><br>قم بتفعيل مربع الاختيار "<span style="font-weight: bold; ${boldFontColor}">تكرار البحث حتى العثور</span>" قبل البدء بالبحث!</strong>`;
		var lowServerSizeSummary_Translated = 'هذه اللعبة محدودة بلاعب واحد كحد أقصى.'
		var successChanceTooltip_Translated = 'يعرض موقع روبلوكس 5 لاعبين على كل خادم، لذا نحسب نسبة 5 من حجم الخادم لتحديد احتمالية النجاح!'
		var successChanceText_Translated = 'احتمالية نجاحك 666%'
		var showTotalServersChecked_Translated = 'عرض إجمالي الخوادم التي تم فحصها'
		var playMusic_Translated = 'تشغيل الموسيقى عند العثور على المستخدم'
		var userId_Translated = `معرّف`
		var confettiParticles_Translated = 'جزيئات قصاصات ورقية عند العثور على المستخدم'
		var serversCheckedTotal_Translated = 'عدد الخوادم التي تم فحصها: 666'
		var whoDoYouWantToFind_Translated = 'من تريد العثور عليه؟'
		var username_Translated = 'اسم المستخدم:'
		var find_Translated = 'العثور على'
		var invalidUsername_Translated = 'اسم مستخدم غير صالح'
		var largePlayerCount_Translated = '⚠️ نظرًا لكثرة اللاعبين في هذه اللعبة، سيستغرق العثور على المستخدم وقتًا أطول!'
		var cancelSearching_Translated = 'هل تريد إلغاء البحث؟ (انقر فوق "موافق" للإلغاء)'
		var searching_Translated = 'جاري البحث'
		var tryAgain_Translated = 'حاول مرة أخرى'
		var notFound_Translated = 'لم يتم العثور على المستخدم ❌'
		var weFoundThem_Translated = 'لقد وجدناهم!'
		var joinButton_Translated = 'انضم'
		var giveUsAReview_Translated = 'هل كان هذا مفيدًا؟ شاركنا رأيك!'
	}
	const post = async (url, body) => {
		try {
			const request = await fetch(`https://${url}`, {
				method: 'POST',
				body,
				headers: {
					'Content-Type': 'application/json',
				},
			});
			if (!request.ok) throw new Error('Request failed');
			return await request.json();
		} catch (error) {
			await sleep(0.2);
			return await post(url, body);
		}
	};
	const get = async (url, includeCreds = true) => {
		try {
			creds = 'omit';
			if (includeCreds) creds = 'include';
			const request = await fetch(`https://${url}`, {
				headers: {
					'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
				},
				credentials: "include"
			});
			if (!request.ok) throw new Error('Request failed');
			return await request.json();
		} catch (error) {
			const delay = Math.random() * 1000 + 2300;
			await new Promise(resolve => setTimeout(resolve, delay));
			return await get(url, includeCreds);
		}
	};
	async function checkUserIdValidity(userId) {
		try {
			const response = await fetch(`https://users.roblox.com/v1/users/${userId}`, {
				headers: {
					'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
				}
			});
			if (!response.ok) {
				return false;
			}
			const userData = await response.json();
			if (userData && userData.name) {
				return [userData.name, userId];
			}
			return false;
		} catch (error) {
			return false;
		}
	}
	async function fetchUserAvatar(userId) {
		try {
			const response = await get(`thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=150x150&format=Png&isCircular=true`, false);
			if (response && response.data && response.data.length > 0) {
				return response.data[0].imageUrl;
			}
			return null;
		} catch (error) {
			return null;
		}
	}
	async function show_warning() {
		search_frame(whoDoYouWantToFind_Translated, '')
	}
	async function low_server_size() {
		document.body.insertAdjacentHTML('beforeend', `<div id="lowServerSize"><div class="modal-backdrop in" role="dialog"></div><div id="purchase-private-server-modal" class="in modal" role="dialog" tabindex="-1" style="display: block;"><div class="modal-window modal-sm modal-dialog"><div class="modal-content" role="document"><div class="modal-header"><button class="close" type="button" title="close"><span id="closeWarning" class="icon-close"></span></button><span><span id="warningLabel" class="text-label"></span></span><h4 class="modal-title">${lowServerSizeTitle_Translated}</h4></div><div class="modal-body"><div class="private-server-purchase"><span>${lowServerSizeSummary_Translated}</span><div class="modal-list-item"></div><div class="modal-image-container" style="display: none;"><span class="thumbnail-2d-container modal-thumb" style="background-color: transparent;"><img class="unselectable" src="" alt="" title=""></span></div></div></div></div></div></div></div>`);
		document.getElementById('closeWarning').addEventListener('click', function() {
			document.getElementById('lowServerSize').remove()
		})
	}
	async function scan_username(input) {
		let data = {
			"usernames": [
				input
			],
			"excludeBannedUsers": true
		};
		try {
			const response = await post('users.roblox.com/v1/usernames/users', JSON.stringify(data));
			if (response.data.length === 0) {
				return false;
			} else {
				let userData = response.data[0];
				let username = userData.name;
				let user_id = userData.id;
				return [username, user_id];
			}
		} catch (error) {
			return false;
		}
	}
	async function get_user_by_id(userId) {
		try {
			const response = await get(`users.roblox.com/v1/users/${userId}`);
			if (response && response.name) {
				return [response.name, userId];
			} else {
				return false;
			}
		} catch (error) {
			return false;
		}
	}
	async function rotateAnimation(element, isActive) {
		if (isActive) {
			element.style.animation = "rotate 1s linear infinite";
		} else {
			element.style.animation = "";
		}
	}
	async function search_frame(title, field_input) {
		let repeatSearchEnabled = false;
		let searchAttempts = 0;
		const closeIcon = document.createElement('span');
		
		const modalHeader = document.createElement('div');
		const modalBackdrop = document.createElement('div');
		const modalContainer = document.createElement('div');
		const modalContent = document.createElement('div');
		const modalWindow = document.createElement('div');
		closedAlready.length = 0
		modalBackdrop.className = 'modal-backdrop in';
		modalBackdrop.setAttribute('role', 'dialog');
		modalContainer.id = 'purchase-private-server-modal';
		modalContainer.className = 'in modal';
		modalContainer.style.display = 'block';
		modalContainer.setAttribute('role', 'dialog');
		modalContainer.setAttribute('tabindex', '-1');
		modalWindow.className = 'modal-window modal-sm modal-dialog';
		modalContent.className = 'modal-content';
		modalContent.setAttribute('role', 'document');
		modalHeader.className = 'modal-header';
		modalHeader.style.borderBottom = 'none';
		const closeButton = document.createElement('button');
		closeButton.innerHTML = '×';
		closeButton.className = 'close';
		closeButton.setAttribute('type', 'button');
		closeButton.style.cssText = `
		position: absolute;
		top: 16px;
		right: 20px;
		background: none;
		border: none;
		font-size: 40px;
		color: ${colorTheme === 'Light' ? '#202227' : '#F7F7F8'};
		cursor: pointer;
		line-height: 1;
		padding: 0px;
		width: 32px;
		height: 32px;
		display: flex;
		align-items: center;
		justify-content: center;
		border-radius: 50%;
		transition: background 0.2s ease;
		`;

		function close_prompt() {
			clearInterval(type_animation_interval);
			totalServersChecked.length = 0;
			closedAlready.push('closed');
			nullg = [];
			search_type = 'static';
			searchAttempts = 0;
			player_found = false;
			foundAllServers = true;
			targetServerIds = [];
			serverIds.clear();
			friendServers.clear();
			allThumbnails.clear();
			allPlayers = [];
			successAudio.pause();
			successAudio.currentTime = 0;
			modalContainer.remove();
			modalBackdrop.remove();
			try {
				document.getElementById('confetti').remove();
			} catch {}
		}
		closeButton.addEventListener('click', function() {
			try {
				if (findButton.innerHTML.includes('.') == true) {
					var x = window.confirm(cancelSearching_Translated);
					if (x == true) {
						close_prompt();
					}
				} else {
					close_prompt();
				}
			} catch {}
		})
		const modalTitle = document.createElement('h4');
		const warningLabel = document.createElement('span')
		var serverSize = document.getElementsByClassName('game-stat')[7].children[1].innerText
		modalTitle.className = 'modal-title';
		modalTitle.textContent = title;
		modalTitle.textContent = title;
		modalTitle.style.cssText = `
		font-size: 22px;
		font-weight: 700;
		color: ${colorTheme === 'Light' ? '#1a1a1a' : '#ffffff'}
		`;
		warningLabel.innerHTML = '<span id="warningLabel" class="text-label"></span><h5 id="serversCheckedCount"></h5>'
		const percentage = (num1, num2) => {
			return num1 / num2 * 100
		}
		var successChancePercentage = percentage(5, serverSize).toFixed(1)
		if (successChancePercentage > 100) {
			var successChancePercentage = 100
		}
		var successChanceText = successChanceText_Translated.replace('666', successChancePercentage)
		const successChance = document.createElement('p')
		successChance.innerHTML = `<div class="container-header"><h2 id="successChance" style="font-size: 15px;font-weight: normal" title="${successChanceTooltip_Translated}">${successChanceText}<p></p></h2><span id="successChanceToolTip" class="tooltip-container" style="cursor:pointer;font-size: 15px;" title="${successChanceTooltip_Translated}"><span class="icon-moreinfo"></span></span></div>`
		modalHeader.appendChild(closeButton);
		modalHeader.appendChild(warningLabel)
		modalHeader.appendChild(modalTitle);
		const modalBody = document.createElement('div');
		const privateServerPurchase = document.createElement('div');
		const modalListItem = document.createElement('div');
		const avatarStyle = document.createElement('style');
		avatarStyle.textContent = `
		.avatar-preview-container {
			display: flex;
			align-items: center;
			justify-content: space-between;
			margin-bottom: 15px;
			position: relative;
		}
		
		.avatar-circle {
			width: 36px;
			height: 36px;
			border-radius: 50%;
			overflow: hidden;
			border: 2px solid #e2231a;
			position: absolute;
			right: -46px;
			top: 0;
			background-color: #f2f2f2;
			display: none; /* Hidden by default */
			transition: all 0.3s ease;
		}
		
		.avatar-circle img {
			width: 100%;
			height: 100%;
			object-fit: cover;
		}
		
		.toggle-container-wrapper {
			display: flex;
			align-items: center;
			position: relative;
			margin-right: 46px; /* Space for the avatar */
		}
	`;
		document.head.appendChild(avatarStyle);
		const toggleContainerWrapper = document.createElement('div');
		toggleContainerWrapper.className = 'toggle-container-wrapper';
		const avatarCircle = document.createElement('div');
		avatarCircle.className = 'avatar-circle';
		avatarCircle.id = 'user-avatar-preview';
		const avatarImg = document.createElement('img');
		avatarImg.className = 'avatar-image';
		avatarImg.src = '';
		avatarImg.alt = 'User Avatar';
		avatarCircle.appendChild(avatarImg);
		const toggleContainer = document.createElement('div');
		toggleContainer.className = 'avatar-preview-container';
		toggleContainer.id = 'search-toggle-container';
		const toggleStyle = document.createElement('style');
		toggleStyle.textContent = `
    .toggle-switch {
        position: relative;
        display: inline-block;
        width: auto; /* Auto width based on content */
        height: 36px;
        margin: 0 auto;
    }
    
    .toggle-switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-switch-bg {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        border-radius: 34px;
        background-color: #e4e4e4;
        transition: .4s;
        cursor: pointer;
        overflow: hidden;
        display: flex;
    }
    
    .toggle-option {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
        color: #666;
        font-weight: bold;
        font-size: 14px;
        transition: .4s;
        z-index: 1;
        padding: 0 16px;
        white-space: nowrap;
        flex: 1;
    }
    
    .toggle-switch-slider {
        position: absolute;
        height: calc(100% - 6px); /* Consistent 3px padding on top and bottom */
        top: 3px;
        background-color: #e2231a;
        border-radius: 30px;
        transition: .4s;
        z-index: 0;
    }
    
    .toggle-switch input:checked + .toggle-switch-bg .toggle-option-left {
        color: #666;
    }
    
    .toggle-switch input:checked + .toggle-switch-bg .toggle-option-right {
        color: white;
    }
    
    .toggle-switch input:not(:checked) + .toggle-switch-bg .toggle-option-left {
        color: white; 
    }
    
    .toggle-switch input:not(:checked) + .toggle-switch-bg .toggle-option-right {
        color: #666;
    }
`;
		document.head.appendChild(toggleStyle);
		const toggleSwitch = document.createElement('label');
		toggleSwitch.className = 'toggle-switch';
		const toggleInput = document.createElement('input');
		toggleInput.type = 'checkbox';
		toggleInput.id = 'searchTypeToggle';
		const toggleBg = document.createElement('div');
		toggleBg.className = 'toggle-switch-bg';
		const toggleSlider = document.createElement('div');
		toggleSlider.className = 'toggle-switch-slider';
		toggleSlider.id = 'toggle-slider';
		const usernameOption = document.createElement('div');
		usernameOption.className = 'toggle-option toggle-option-left';
		usernameOption.textContent = username_Translated.replace(':', '');
		usernameOption.id = 'username-option';
		const userIdOption = document.createElement('div');
		userIdOption.className = 'toggle-option toggle-option-right';
		userIdOption.textContent = userId_Translated.replace(':', '');
		userIdOption.id = 'userid-option';
		toggleBg.appendChild(usernameOption);
		toggleBg.appendChild(userIdOption);
		toggleBg.appendChild(toggleSlider);
		toggleSwitch.appendChild(toggleInput);
		toggleSwitch.appendChild(toggleBg);
		toggleContainerWrapper.appendChild(toggleSwitch);
		toggleContainerWrapper.appendChild(avatarCircle);
		toggleContainer.appendChild(toggleContainerWrapper)
		const shareButton = document.createElement('button');
		shareButton.style.cssText = `
			height: 36px;
			border: none;
			border-radius: 6px;
			cursor: pointer;
			padding: 8px 12px;
			transition: transform 0.2s;
			background: #e2231a;
			display: flex;
			align-items: center;
			justify-content: center;
			gap: 8px;
			order: 9999;
			margin-left: auto;
			white-space: nowrap;
			min-width: fit-content;
			transform: scale(1);
		`;

		shareButton.style.transition = 'transform 0.2s ease';
		shareButton.addEventListener('mouseenter', function() {
			shareButton.style.transform = 'translateY(-1px)';
		});

		shareButton.addEventListener('mouseleave', function() {
			shareButton.style.transform = 'translateY(0px)';
		});

		const shareImg = document.createElement('img');
		shareImg.src = chrome.runtime.getURL('/images/share.png');
		shareImg.style.cssText = `
			width: 20px;
			height: 20px;
			flex-shrink: 0;
		`;

		const shareText = document.createElement('span');
		shareText.textContent = shareButton_Translated;
		shareText.style.cssText = `
			color: white;
			font-size: 16px;
			font-weight: 500;
			font-family: "Builder Sans", "Helvetica Neue", Helvetica, Arial, "Lucida Grande", sans-serif;
		`;

		shareButton.appendChild(shareImg);
		shareButton.appendChild(shareText);

		toggleContainer.appendChild(shareButton);

		function shareBloxFinder() {
			const existingModal = document.getElementById('bf-share-modal');
			if (existingModal) existingModal.remove();

			const shareURL = 'https://chromewebstore.google.com/detail/bloxfinder/bnpkdbbfehooennlcojneoimfjgekdgn/';
			
			const overlay = document.createElement('div');
			overlay.id = 'bf-share-modal';
			overlay.style.cssText = `
				position: fixed;
				top: 50%;
				left: 50%;
				transform: translate(-50%, -50%);
				z-index: 9999;
				opacity: 1;
			`;

			const modal = document.createElement('div');
			modal.style.cssText = `
				background: ${colorTheme === 'Light' ? '#F7F7F8' : '#272930'};
				border-radius: 0px;
				padding: 32px;
				width: 400px;
				height: 303.77px;
				position: relative;
				transform: scale(1);
			`;

			const closeButton = document.createElement('button');
			closeButton.innerHTML = '&times;';
			closeButton.style.cssText = `
				position: absolute;
				top: 16px;
				right: 20px;
				background: none;
				border: none;
				font-size: 40px;
				color: ${colorTheme === 'Light' ? '#202227' : '#F7F7F8'};
				cursor: pointer;
				line-height: 1;
				padding: 0;
				width: 32px;
				height: 32px;
				display: flex;
				align-items: center;
				justify-content: center;
				border-radius: 50%;
				transition: background 0.2s ease;
			`;
			
			closeButton.onmouseenter = () => {
				closeButton.style.background = colorTheme === 'Light' ? '#f0f0f0' : '#3a3a3a';
			};
			closeButton.onmouseleave = () => {
				closeButton.style.background = 'none';
			};

			const title = document.createElement('h3');
			title.textContent = shareBloxFinder_Translated;
			title.style.cssText = `
				margin: 0 0 28px 0;
				font-size: 22px;
				font-weight: 700;
				color: ${colorTheme === 'Light' ? '#1a1a1a' : '#ffffff'};
				text-align: center;
			`;

			const platformsGrid = document.createElement('div');
			platformsGrid.style.cssText = `
				display: grid;
				grid-template-columns: repeat(4, 1fr);
				gap: 16px;
				margin-bottom: 24px;
			`;

			const platforms = [
				{
					name: 'Reddit',
					url: 'https://reddit.com/submit?url=' + encodeURIComponent(shareURL),
					svg: `<svg width="50" height="50" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg" focusable="false" aria-hidden="true" style="pointer-events: none; display: inherit; width: 100%; height: 100%;"><g clip-path="url(#clip0_1646_12789_yt468)"><mask id="mask0_1646_12789_yt468" style="mask-type: alpha;" maskUnits="userSpaceOnUse" x="0" y="0" width="256" height="256"><circle cx="128" cy="128" r="128" fill="white"></circle></mask><g mask="url(#mask0_1646_12789_yt468)"><path d="M256 0H0V256H256V0Z" fill="#FF4500"></path><path d="M173.758 146.781C184.109 146.781 192.5 138.39 192.5 128.039C192.5 117.687 184.109 109.296 173.758 109.296C163.407 109.296 155.016 117.687 155.016 128.039C155.016 138.39 163.407 146.781 173.758 146.781Z" fill="url(#paint0_radial_1646_12789_yt468)"></path><path d="M82.7422 146.781C93.0932 146.781 101.484 138.39 101.484 128.039C101.484 117.687 93.0932 109.296 82.7422 109.296C72.3912 109.296 64 117.687 64 128.039C64 138.39 72.3912 146.781 82.7422 146.781Z" fill="url(#paint1_radial_1646_12789_yt468)"></path><path d="M128.313 184.202C157.843 184.202 181.781 166.241 181.781 144.085C181.781 121.929 157.843 103.968 128.313 103.968C98.7829 103.968 74.8442 121.929 74.8442 144.085C74.8442 166.241 98.7829 184.202 128.313 184.202Z" fill="url(#paint2_radial_1646_12789_yt468)"></path><path d="M112.454 140.199C112.14 146.969 107.627 149.476 102.362 149.476C97.0966 149.476 93.0849 145.966 93.3983 139.196C93.7117 132.426 98.2249 127.913 103.49 127.913C108.756 127.913 112.767 133.429 112.454 140.199Z" fill="#842123"></path><path d="M163.102 139.196C163.415 145.966 159.403 149.476 154.138 149.476C148.873 149.476 144.359 147.031 144.046 140.199C143.733 133.429 147.744 127.913 153.01 127.913C158.275 127.913 162.788 132.364 163.102 139.196Z" fill="#842123"></path><path d="M144.109 140.826C144.422 147.157 148.622 149.476 153.511 149.476C158.401 149.476 162.161 146.029 161.911 139.635C161.597 133.304 157.398 129.104 152.508 129.104C147.619 129.104 143.795 134.432 144.109 140.826Z" fill="url(#paint3_radial_1646_12789_yt468)"></path><path d="M112.454 140.826C112.141 147.157 107.941 149.476 103.052 149.476C98.1623 149.476 94.4014 146.029 94.7148 139.635C95.0282 133.304 99.228 129.104 104.117 129.104C109.006 129.104 112.767 134.432 112.454 140.826Z" fill="url(#paint4_radial_1646_12789_yt468)"></path><path d="M128.313 153.989C121.668 153.989 115.337 154.303 109.445 154.867C108.442 154.992 107.815 155.995 108.191 156.873C111.451 164.583 119.224 170.036 128.313 170.036C137.402 170.036 145.112 164.645 148.434 156.873C148.81 155.932 148.183 154.929 147.18 154.867C141.288 154.303 134.957 153.989 128.313 153.989Z" fill="#BBCFDA"></path><path d="M128.313 155.494C121.668 155.494 115.337 155.807 109.508 156.434C108.505 156.559 107.878 157.562 108.254 158.502C111.514 166.338 119.286 171.854 128.313 171.854C137.339 171.854 145.112 166.338 148.371 158.502C148.747 157.562 148.12 156.559 147.118 156.434C141.225 155.807 134.894 155.494 128.313 155.494Z" fill="white"></path><path d="M128.313 154.679C121.794 154.679 115.588 154.992 109.821 155.556C108.818 155.682 108.191 156.685 108.568 157.562C111.827 165.272 119.412 170.726 128.313 170.726C137.214 170.726 144.798 165.335 148.058 157.562C148.434 156.622 147.807 155.619 146.804 155.556C141.037 155.055 134.832 154.679 128.313 154.679Z" fill="url(#paint5_radial_1646_12789_yt468)"></path><path d="M157.586 98.5776C164.925 98.5776 170.874 92.628 170.874 85.2888C170.874 77.9496 164.925 72 157.586 72C150.246 72 144.297 77.9496 144.297 85.2888C144.297 92.628 150.246 98.5776 157.586 98.5776Z" fill="url(#paint6_radial_1646_12789_yt468)"></path><path d="M128.125 105.661C126.558 105.661 125.241 104.971 125.241 103.968C125.241 92.0585 134.894 82.4054 146.804 82.4054C148.371 82.4054 149.688 83.7217 149.688 85.2888C149.688 86.8559 148.371 88.1722 146.804 88.1722C138.091 88.1722 131.008 95.2554 131.008 103.968C131.008 105.034 129.692 105.661 128.125 105.661Z" fill="url(#paint7_radial_1646_12789_yt468)"></path><path d="M109.006 143.96C109.006 146.405 106.374 147.533 103.177 147.533C99.9799 147.533 97.3472 146.405 97.3472 143.96C97.3472 141.515 99.9799 139.51 103.177 139.51C106.374 139.51 109.006 141.453 109.006 143.96Z" fill="#FF6101"></path><path d="M159.278 143.96C159.278 146.405 156.645 147.533 153.448 147.533C150.252 147.533 147.619 146.405 147.619 143.96C147.619 141.515 150.252 139.51 153.448 139.51C156.645 139.51 159.278 141.453 159.278 143.96Z" fill="#FF6101"></path><path d="M107.189 137.253C108.331 137.253 109.257 136.243 109.257 134.996C109.257 133.75 108.331 132.74 107.189 132.74C106.046 132.74 105.12 133.75 105.12 134.996C105.12 136.243 106.046 137.253 107.189 137.253Z" fill="#FFC49C"></path><path d="M156.645 137.253C157.788 137.253 158.714 136.243 158.714 134.996C158.714 133.75 157.788 132.74 156.645 132.74C155.503 132.74 154.577 133.75 154.577 134.996C154.577 136.243 155.503 137.253 156.645 137.253Z" fill="#FFC49C"></path></g></g><defs><radialGradient id="paint0_radial_1646_12789_yt468" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(172.951 117.92) scale(37.548 32.7547)"><stop stop-color="#FEFFFF"></stop><stop offset="0.4" stop-color="#FEFFFF"></stop><stop offset="0.51" stop-color="#F9FCFC"></stop><stop offset="0.62" stop-color="#EDF3F5"></stop><stop offset="0.7" stop-color="#DEE9EC"></stop><stop offset="0.72" stop-color="#D8E4E8"></stop><stop offset="0.76" stop-color="#CCD8DF"></stop><stop offset="0.8" stop-color="#C8D5DD"></stop><stop offset="0.83" stop-color="#CCD6DE"></stop><stop offset="0.85" stop-color="#D8DBE2"></stop><stop offset="0.88" stop-color="#EDE3E9"></stop><stop offset="0.9" stop-color="#FFEBEF"></stop></radialGradient><radialGradient id="paint1_radial_1646_12789_yt468" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(81.9856 117.92) scale(37.548 32.7547)"><stop stop-color="#FEFFFF"></stop><stop offset="0.4" stop-color="#FEFFFF"></stop><stop offset="0.51" stop-color="#F9FCFC"></stop><stop offset="0.62" stop-color="#EDF3F5"></stop><stop offset="0.7" stop-color="#DEE9EC"></stop><stop offset="0.72" stop-color="#D8E4E8"></stop><stop offset="0.76" stop-color="#CCD8DF"></stop><stop offset="0.8" stop-color="#C8D5DD"></stop><stop offset="0.83" stop-color="#CCD6DE"></stop><stop offset="0.85" stop-color="#D8DBE2"></stop><stop offset="0.88" stop-color="#EDE3E9"></stop><stop offset="0.9" stop-color="#FFEBEF"></stop></radialGradient><radialGradient id="paint2_radial_1646_12789_yt468" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(128.657 112.666) scale(113.26 79.5228)"><stop stop-color="#FEFFFF"></stop><stop offset="0.4" stop-color="#FEFFFF"></stop><stop offset="0.51" stop-color="#F9FCFC"></stop><stop offset="0.62" stop-color="#EDF3F5"></stop><stop offset="0.7" stop-color="#DEE9EC"></stop><stop offset="0.72" stop-color="#D8E4E8"></stop><stop offset="0.76" stop-color="#CCD8DF"></stop><stop offset="0.8" stop-color="#C8D5DD"></stop><stop offset="0.83" stop-color="#CCD6DE"></stop><stop offset="0.85" stop-color="#D8DBE2"></stop><stop offset="0.88" stop-color="#EDE3E9"></stop><stop offset="0.9" stop-color="#FFEBEF"></stop></radialGradient><radialGradient id="paint3_radial_1646_12789_yt468" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(152.686 145.133) rotate(180) scale(9.46286 13.8923)"><stop stop-color="#FF6600"></stop><stop offset="0.5" stop-color="#FF4500"></stop><stop offset="0.7" stop-color="#FC4301"></stop><stop offset="0.82" stop-color="#F43F07"></stop><stop offset="0.92" stop-color="#E53812"></stop><stop offset="1" stop-color="#D4301F"></stop></radialGradient><radialGradient id="paint4_radial_1646_12789_yt468" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(103.482 145.133) scale(9.46287 13.8923)"><stop stop-color="#FF6600"></stop><stop offset="0.5" stop-color="#FF4500"></stop><stop offset="0.7" stop-color="#FC4301"></stop><stop offset="0.82" stop-color="#F43F07"></stop><stop offset="0.92" stop-color="#E53812"></stop><stop offset="1" stop-color="#D4301F"></stop></radialGradient><radialGradient id="paint5_radial_1646_12789_yt468" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(127.413 172.674) scale(33.3675 22.0084)"><stop stop-color="#172E35"></stop><stop offset="0.29" stop-color="#0E1C21"></stop><stop offset="0.73" stop-color="#030708"></stop><stop offset="1"></stop></radialGradient><radialGradient id="paint6_radial_1646_12789_yt468" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(156.842 71.8785) scale(29.2901 29.2901)"><stop stop-color="#FEFFFF"></stop><stop offset="0.4" stop-color="#FEFFFF"></stop><stop offset="0.51" stop-color="#F9FCFC"></stop><stop offset="0.62" stop-color="#EDF3F5"></stop><stop offset="0.7" stop-color="#DEE9EC"></stop><stop offset="0.72" stop-color="#D8E4E8"></stop><stop offset="0.76" stop-color="#CCD8DF"></stop><stop offset="0.8" stop-color="#C8D5DD"></stop><stop offset="0.83" stop-color="#CCD6DE"></stop><stop offset="0.85" stop-color="#D8DBE2"></stop><stop offset="0.88" stop-color="#EDE3E9"></stop><stop offset="0.9" stop-color="#FFEBEF"></stop></radialGradient><radialGradient id="paint7_radial_1646_12789_yt468" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(144.633 103.809) scale(24.0077)"><stop offset="0.48" stop-color="#7A9299"></stop><stop offset="0.67" stop-color="#172E35"></stop><stop offset="0.75"></stop><stop offset="0.82" stop-color="#172E35"></stop></radialGradient><clipPath id="clip0_1646_12789_yt468"><rect width="256" height="256" fill="white"></rect></clipPath></defs></svg>`
				},
				{
					name: 'X',
					url: 'https://twitter.com/intent/tweet?url=' + encodeURIComponent(shareURL),
					svg: `<svg width="50" height="50" viewBox="0 0 192 192" fill="none" xmlns="http://www.w3.org/2000/svg"><rect width="192" height="192" rx="96" fill="black"></rect><path fill-rule="evenodd" clip-rule="evenodd" d="M42 47H76L100 78.5L127 47H144L107.5 88.5L150 145H117L91 111L61 145H44L83 100.5L42 47ZM62 57H71.5L130.5 135H121.5L62 57Z" fill="white"></path></svg>`
				},
				{
					name: 'Facebook',
					url: 'https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(shareURL),
					svg: `<svg width="50" height="50" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><path d="M28.4863253 59.9692983c-6.6364044-.569063-11.5630204-2.3269561-16.3219736-5.8239327C4.44376366 48.4721168 3e-7 39.6467924 3e-7 29.9869344c0-14.8753747 10.506778-27.18854591 25.2744118-29.61975392 6.0281072-.9924119 12.7038532.04926445 18.2879399 2.85362966C57.1386273 10.0389054 63.3436516 25.7618627 58.2050229 40.3239688 54.677067 50.3216743 45.4153135 57.9417536 34.81395 59.5689067c-2.0856252.3201125-5.0651487.5086456-6.3276247.4003916z" fill="#3B5998" fill-rule="nonzero"></path><path d="M25.7305108 45h5.4583577V30.0073333h4.0947673l.8098295-4.6846666h-4.9045968V21.928c0-1.0943333.7076019-2.2433333 1.7188899-2.2433333h2.7874519V15h-3.4161354v.021c-5.3451414.194-6.4433395 3.2896667-6.5385744 6.5413333h-.0099897v3.7603334H23v4.6846666h2.7305108V45z" fill="#FFF"></path></g></svg>`
				},
				{
					name: 'WhatsApp',
					url: 'https://wa.me/?text=' + encodeURIComponent(shareURL),
					svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60" focusable="false" aria-hidden="true" style="pointer-events: none; display: inherit; width: 100%; height: 100%;"><g fill="none" fill-rule="evenodd"><circle cx="30" cy="30" r="30" fill="#25D366"></circle><path d="M39.7746 19.3513C37.0512 16.5467 33.42 15 29.5578 15C21.6022 15 15.1155 21.6629 15.1155 29.8725C15.1155 32.4901 15.7758 35.0567 17.0467 37.3003L15 45L22.6585 42.9263C24.7712 44.1161 27.148 44.728 29.5578 44.728C37.5134 44.728 44 38.0652 44 29.8555C44 25.8952 42.498 22.1558 39.7746 19.3513ZM29.5578 42.2295C27.3956 42.2295 25.2829 41.6346 23.4508 40.5127L23.0051 40.2408L18.4661 41.4646L19.671 36.9093L19.3904 36.4334C18.1855 34.4618 17.5583 32.1841 17.5583 29.8555C17.5583 23.0397 22.9556 17.4986 29.5743 17.4986C32.7763 17.4986 35.7968 18.7904 38.0581 21.119C40.3193 23.4476 41.5737 26.5581 41.5737 29.8555C41.5572 36.6884 36.1764 42.2295 29.5578 42.2295ZM36.1434 32.966C35.7803 32.779 34.0142 31.8782 33.6841 31.7592C33.354 31.6402 33.1064 31.5722 32.8754 31.9462C32.6278 32.3201 31.9511 33.153 31.7365 33.4079C31.5219 33.6629 31.3238 33.6799 30.9607 33.4929C30.5976 33.306 29.4422 32.915 28.0558 31.6572C26.9829 30.6714 26.2567 29.4476 26.0421 29.0907C25.8275 28.7167 26.0256 28.5127 26.2072 28.3258C26.3722 28.1558 26.5703 27.8839 26.7518 27.6799C26.9334 27.4589 26.9994 27.3059 27.115 27.068C27.2305 26.813 27.181 26.6091 27.082 26.4221C26.9994 26.2351 26.2732 24.3994 25.9761 23.6686C25.679 22.9377 25.3819 23.0397 25.1673 23.0227C24.9528 23.0057 24.7217 23.0057 24.4741 23.0057C24.2265 23.0057 23.8469 23.0907 23.5168 23.4646C23.1867 23.8385 22.2459 24.7394 22.2459 26.5581C22.2459 28.3938 23.5333 30.1445 23.7149 30.3994C23.8964 30.6544 26.2567 34.3938 29.8714 36.0085C30.7297 36.3994 31.4064 36.6204 31.9345 36.7904C32.7928 37.0793 33.5851 37.0283 34.2123 36.9433C34.9055 36.8414 36.3415 36.0425 36.6551 35.1756C36.9522 34.3088 36.9522 33.5609 36.8697 33.4079C36.7541 33.255 36.5065 33.153 36.1434 32.966Z" fill="white"></path></g></svg>`
				}
			];

			platforms.forEach(platform => {
				const platformButton = document.createElement('div');
				platformButton.style.cssText = `
					display: flex;
					flex-direction: column;
					align-items: center;
					gap: 8px;
					cursor: pointer;
					outline: none;
				`;

				const iconContainer = document.createElement('div');
				iconContainer.style.cssText = `
					width: 56px;
					height: 56px;
					border-radius: 50%;
					
					display: flex;
					outline: none;
					align-items: center;
					justify-content: center;
					transition: all 0.2s ease;
					border: 2px solid transparent;
				`;

				iconContainer.innerHTML = platform.svg;

				const label = document.createElement('span');
				label.textContent = platform.name;
				label.style.cssText = `
					font-size: 12px;
					color: ${colorTheme === 'Light' ? '#666' : '#ccc'};
					font-weight: 500;
					text-align: center;
				`;

				platformButton.appendChild(iconContainer);
				platformButton.appendChild(label);

				platformButton.addEventListener('mouseenter', () => {
					iconContainer.style.transform = 'scale(1.08)';
					iconContainer.style.borderColor = colorTheme === 'Light' ? '#ddd' : '#555';
					iconContainer.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
				});

				platformButton.addEventListener('mouseleave', () => {
					iconContainer.style.transform = 'scale(1)';
					iconContainer.style.borderColor = 'transparent';
					iconContainer.style.boxShadow = 'none';
				});

				platformButton.addEventListener('click', () => {
					window.open(platform.url, '_blank');
				});

				platformsGrid.appendChild(platformButton);
			});

			const linkSection = document.createElement('div');
			linkSection.style.cssText = `
				background: ${colorTheme === 'Light' ? '#f5f5f5' : '#1e1e1e'};
				border-radius: 12px;
				padding: 16px;
				display: flex;
				align-items: center;
				gap: 12px;
			`;

			const urlField = document.createElement('input');
			urlField.value = shareURL;
			urlField.readOnly = true;
			urlField.style.cssText = `
				flex: 1;
				background: transparent;
				border: none;
				color: ${colorTheme === 'Light' ? '#333' : '#ddd'};
				font-size: 14px;
				outline: none;
				font-family: inherit;
			`;

			const copyButton = document.createElement('button');
			copyButton.textContent = copyButtonText_Translated;
			copyButton.style.cssText = `
				background: #007bff;
				color: white;
				border: none;
				padding: 10px 18px;
				border-radius: 8px;
			font-size: 13px;
			font-weight: 600;
			cursor: pointer;
			transition: all 0.2s ease;
			white-space: nowrap;
		`;

		copyButton.addEventListener('mouseenter', () => {
			copyButton.style.transform = 'translateY(-1px)';
		});

		copyButton.addEventListener('mouseleave', () => {
			copyButton.style.transform = 'translateY(0)';
		});

		copyButton.addEventListener('click', async () => {
			try {
				await navigator.clipboard.writeText(shareURL);
				const originalText = copyButton.textContent;
				copyButton.textContent = copiedText_Translated;
				copyButton.style.background = '#28a745';
				
				setTimeout(() => {
					copyButton.textContent = originalText;
					copyButton.style.background = '#007bff';
				}, 2000);
			} catch (err) {
				urlField.select();
				document.execCommand('copy');
				copyButton.textContent = copiedText_Translated;
				copyButton.style.background = '#28a745';
				
				setTimeout(() => {
					copyButton.textContent = copyButtonText_Translated;
					copyButton.style.background = '#007bff';
				}, 2000);
			}
		});

		linkSection.appendChild(urlField);
		linkSection.appendChild(copyButton);

		const closeModal = () => {
			overlay.remove();
		};

		closeButton.addEventListener('click', closeModal);
		overlay.addEventListener('click', (e) => {
			if (e.target === overlay) closeModal();
		});

		document.addEventListener('keydown', (e) => {
			if (e.key === 'Escape' && document.getElementById('bf-share-modal')) {
				closeModal();
			}
		});

		modal.appendChild(closeButton);
		modal.appendChild(title);
		modal.appendChild(platformsGrid);
		modal.appendChild(linkSection);
		overlay.appendChild(modal);

		document.body.appendChild(overlay);
		}


		shareButton.addEventListener('click', () => shareBloxFinder());

		function updateToggleSlider() {
			const usernameWidth = usernameOption.getBoundingClientRect().width;
			const userIdWidth = userIdOption.getBoundingClientRect().width;
			toggleSwitch.style.width = (usernameWidth + userIdWidth) + 'px';
			const oldStyles = document.getElementById('dynamic-toggle-styles');
			if (oldStyles) oldStyles.remove();
			const dynamicStyles = document.createElement('style');
			dynamicStyles.id = 'dynamic-toggle-styles';
			dynamicStyles.textContent = `
        .toggle-switch input:not(:checked) + .toggle-switch-bg .toggle-switch-slider {
            left: 3px; /* Consistent 3px left padding */
            width: ${usernameWidth - 6}px; /* 3px padding on each side */
        }
        
        .toggle-switch input:checked + .toggle-switch-bg .toggle-switch-slider {
            left: ${usernameWidth + 3}px; /* Position after username + left padding */
            width: ${userIdWidth - 6}px; /* 3px padding on each side */
        }
    `;
			document.head.appendChild(dynamicStyles);
		}
		if (document.readyState === 'loading') {
			document.addEventListener('DOMContentLoaded', () => setTimeout(updateToggleSlider, 10));
		} else {
			setTimeout(updateToggleSlider, 10);
		}
		window.addEventListener('resize', updateToggleSlider);
		let searchByUserId = false;
		toggleInput.addEventListener('change', function() {
			searchByUserId = this.checked;
			if (searchByUserId) {
				inputField.value = '';
				inputField.placeholder = enterUserID_Translated;
			} else {
				inputField.value = '';
				inputField.placeholder = enterUsername_Translated;
			}
			findButton.className = 'modal-button disabled btn-primary-md btn-min-width';
			findButton.innerText = find_Translated;
			avatarCircle.style.display = 'none';
			setTimeout(updateToggleSlider, 50);
		});
		const privateServerNameInput = document.createElement('div');
		const formGroup = document.createElement('div');
		const inputField = document.createElement('input');
		inputField.id = 'search-input-field';
		const modalImageContainer = document.createElement('div');
		const thumbnailContainer = document.createElement('span');
		const originalImage = document.createElement('img');
		const findButton = document.createElement('button');
		findButton.style.transition = 'transform 0.2s ease';

		findButton.addEventListener('mouseenter', function() {
			findButton.style.transform = 'translateY(-1px)';
		});

		findButton.addEventListener('mouseleave', function() {
			findButton.style.transform = 'translateY(0px)';
		});
		const findLink = document.createElement('a');
		let type_animation_interval;
		modalBody.className = 'modal-body';
		privateServerPurchase.className = 'private-server-purchase';
		modalListItem.className = 'modal-list-item';
		privateServerNameInput.className = 'modal-list-item private-server-name-input';
		privateServerNameInput.id = 'search-input-container';
		formGroup.className = 'form-group form-has-feedback';
		inputField.autocomplete = "off"
		inputField.type = 'text';
		inputField.maxLength = 50;
		inputField.className = 'form-control input-field private-server-name';
		inputField.id = 'private-server-name-text-box';
		inputField.value = field_input;
		inputField.setAttribute('autocomplete', 'off')
		inputField.setAttribute('autocorrect', 'off')
		inputField.setAttribute('autocapitalize', 'off')
		inputField.setAttribute('spellcheck', 'false')
		inputField.placeholder = enterUsername_Translated;
		modalImageContainer.className = 'modal-image-container';
		modalImageContainer.style.display = 'none';
		thumbnailContainer.className = 'thumbnail-2d-container modal-thumb';
		thumbnailContainer.style.backgroundColor = 'transparent';
		originalImage.className = 'unselectable';
		originalImage.src = '';
		originalImage.alt = '';
		originalImage.title = '';
		thumbnailContainer.appendChild(originalImage);
		modalImageContainer.appendChild(thumbnailContainer);
		findButton.type = 'button';
		findButton.textContent = find_Translated;
		findButton.className = 'modal-button disabled btn-primary-md btn-min-width';
		findLink.style.display = 'none';
		findLink.innerHTML = ``
		const textLabel = document.createElement('label');
		textLabel.className = 'form-label';
		textLabel.htmlFor = 'private-server-name-text-box';
		textLabel.textContent = searchByUserId ? userId_Translated : username_Translated;
		textLabel.style.display = 'none';
		formGroup.appendChild(textLabel);
		formGroup.appendChild(inputField);
		privateServerNameInput.appendChild(formGroup);
		let avatarLoadTimeout = null;
		let lastValidatedValue = '';
		let isValidating = false;
		async function updateAvatarPreview(userId) {
			if (!userId) {
				avatarCircle.style.display = 'none';
				return;
			}
			if (avatarLoadTimeout) {
				clearTimeout(avatarLoadTimeout);
			}
			avatarLoadTimeout = setTimeout(async () => {
				const avatarUrl = await fetchUserAvatar(userId);
				if (avatarUrl) {
					avatarImg.src = avatarUrl;
					avatarCircle.style.display = 'block';
				} else {
					avatarCircle.style.display = 'none';
				}
			}, 1);
		}
		async function validateInput(value) {
			if (value === lastValidatedValue || isValidating) return;
			isValidating = true;
			lastValidatedValue = value;
			if (value.trim() === '') {
				findButton.className = 'modal-button disabled btn-primary-md btn-min-width';
				findButton.innerText = find_Translated;
				avatarCircle.style.display = 'none';
				isValidating = false;
				return;
			}
			if (searchByUserId) {
				if (/^\d+$/.test(value)) {
					const userDetails = await checkUserIdValidity(value);
					if (userDetails !== false) {
						user_details = userDetails;
						findButton.className = 'modal-button btn-primary-md btn-min-width';
						findButton.innerText = find_Translated;
						updateAvatarPreview(value);
					} else {
						findButton.className = 'modal-button disabled btn-primary-md btn-min-width';
						findButton.innerText = invalidUserId_Translated;
						avatarCircle.style.display = 'none';
					}
				} else {
					findButton.className = 'modal-button disabled btn-primary-md btn-min-width';
					findButton.innerText = invalidUserId_Translated;
					avatarCircle.style.display = 'none';
				}
			} else {
				const userDetails = await scan_username(value);
				if (userDetails !== false) {
					user_details = userDetails;
					findButton.className = 'modal-button btn-primary-md btn-min-width';
					findButton.innerText = find_Translated;
					updateAvatarPreview(user_details[1]);
				} else {
					findButton.className = 'modal-button disabled btn-primary-md btn-min-width';
					findButton.innerText = invalidUsername_Translated;
					avatarCircle.style.display = 'none';
				}
			}
			isValidating = false;
		}
		let validationTimeout = null;
		inputField.addEventListener('input', function() {
			const currentValue = this.value.trim();
			if (searchByUserId) {
				if (validationTimeout) {
					clearTimeout(validationTimeout);
				}
				if (currentValue === '') {
					findButton.className = 'modal-button disabled btn-primary-md btn-min-width';
					findButton.innerText = find_Translated;
					avatarCircle.style.display = 'none';
				} else if (!/^\d+$/.test(currentValue)) {
					findButton.className = 'modal-button disabled btn-primary-md btn-min-width';
					findButton.innerText = invalidUserId_Translated;
					avatarCircle.style.display = 'none';
				} else {
					validateInput(currentValue);
				}
			} else {
				if (validationTimeout) {
					clearTimeout(validationTimeout);
				}
				validationTimeout = setTimeout(() => {
					validateInput(currentValue);
				}, 500);
			}
		});

		function stopSearch() {
			clearInterval(type_animation_interval);
			findButton.innerHTML = find_Translated;
			findButton.disabled = false;
		}

		function startSearch() {
			let dots = 0;
			findButton.disabled = true;
			findButton.innerHTML = `${searching_Translated}.`;
			modalTitle.textContent = `${searching_Translated}.`;
			document.getElementById('search-toggle-container').style.display = 'none';
			document.getElementById('search-input-container').style.display = 'none';
			try {
				const checkbox = document.getElementById('repeat-search-checkbox');
				if (checkbox) {
					repeatSearchEnabled = checkbox.checked;
				}
			} catch (e) {}
			const repeatContainer = document.getElementById('repeat-search-container');
			if (repeatContainer) {
				repeatContainer.remove();
			}
			if (repeatSearchEnabled) {
				let attemptsCounterContainer = document.getElementById('attempts-counter-container');
				if (!attemptsCounterContainer) {
					attemptsCounterContainer = document.createElement('div');
					attemptsCounterContainer.id = 'attempts-counter-container';
					attemptsCounterContainer.style.marginTop = '10px';
					attemptsCounterContainer.style.marginBottom = '5px';
					const attemptsCount = document.createElement('div');
					attemptsCount.id = 'attemptsCount';
					attemptsCount.innerText = attemptsTotal_Translated.replace('666', searchAttempts);
					attemptsCounterContainer.appendChild(attemptsCount);
					const warningLabel = document.getElementById('warningLabel');
					if (warningLabel && warningLabel.parentNode) {
						warningLabel.parentNode.insertBefore(attemptsCounterContainer, warningLabel.nextSibling);
					}
				} else {
					const attemptsCount = document.getElementById('attemptsCount');
					if (attemptsCount) {
						attemptsCount.innerText = attemptsTotal_Translated.replace('666', searchAttempts);
					}
				}
			}
			type_animation_interval = setInterval(() => {
				dots = (dots + 1) % 3;
				findButton.innerHTML = `${searching_Translated}.` + ".".repeat(dots);
				modalTitle.textContent = `${searching_Translated}.` + ".".repeat(dots);
			}, 500);
		}
		var nullg = []
		let user_details;
		async function failed_scan_apperance() {
			stopSearch();
			rotateAnimation(modalImageContainer, false);
			if (closedAlready.includes('closed')) {
				return;
			}
			if (repeatSearchEnabled) {
				searchAttempts++;
				try {
					if (document.getElementById('attemptsCount')) {
						document.getElementById('attemptsCount').innerText = attemptsTotal_Translated.replace('666', searchAttempts);
					}
				} catch {}
				totalServersChecked.length = 0;
				nullg = [];
				try {
					if (document.getElementById('serversCheckedCount')) {
						document.getElementById('serversCheckedCount').innerText = serversCheckedTotal_Translated.replace('666', '0');
					}
				} catch {}
				if (closedAlready.includes('closed')) {
					return;
				}
				startSearch();
				modalImageContainer.style.display = 'block';
				originalImage.src = loadingImage;
				rotateAnimation(modalImageContainer, true);
				chrome.storage.local.get(["totalSearches"], function(items) {
					var totalSearches = items['totalSearches'];
					var newTotalSearches = totalSearches + 1;
					chrome.storage.local.set({
						"totalSearches": newTotalSearches
					});
				});
				await searchServers();
				return;
			}
			searchAttempts = 0;
			modalTitle.textContent = notFound_Translated;
			try {
				document.getElementById('warningLabel').innerText = '';
				document.getElementById('successChance').remove();
				document.getElementById('successChanceToolTip').remove();
			} catch {}
			totalServersChecked.length = 0;
			modalImageContainer.style.display = 'none';
			originalImage.src = '';
			const repeatSearchTip = document.createElement('div');
			repeatSearchTip.id = 'repeat-search-tip';
			repeatSearchTip.style.textAlign = 'center';
			repeatSearchTip.style.margin = '15px 0';
			repeatSearchTip.style.padding = '0 10px';
			repeatSearchTip.innerHTML = information_Translated
			const modalBody = modalContent.querySelector('.modal-body');
			if (modalBody) {
				modalBody.appendChild(repeatSearchTip);
			}
			findButton.innerText = tryAgain_Translated;
			chrome.storage.local.get(["totalSearches"], function(items) {
				var totalSearches = items['totalSearches'];
				var newTotalSearches = totalSearches + 1;
				chrome.storage.local.set({
					"totalSearches": newTotalSearches
				});
			});
			search_type = 'retry';
			findButton.onclick = function() {
				totalServersChecked.length = 0;
				modalContainer.remove();
				modalBackdrop.remove();
				successAudio.pause();
				successAudio.currentTime = 0;
				search_type = 'static';
				search_frame(whoDoYouWantToFind_Translated, '');
			};
		}
		async function success_scan_apperance() {
			searchAttempts = 0;
			stopSearch();
			rotateAnimation(modalImageContainer, false);
			modalTitle.textContent = weFoundThem_Translated;
			try {
				document.getElementById('warningLabel').innerText = '';
				document.getElementById('successChance').remove();
				document.getElementById('successChanceToolTip').remove();
			} catch {}
			totalServersChecked.length = 0;
			originalImage.src = playerImageUrl;
			var displayName = user_details[0];
			try {
				document.getElementById('search-input-container').remove();
			} catch {}
			try {
				document.getElementById('search-toggle-container').remove();
			} catch {}
			try {
				document.getElementById('attempts-counter-container').remove();
			} catch {}
			findButton.innerText = `${joinButton_Translated} ${displayName}`;
			findButton.className = 'btn-common-play-game-lg btn-primary-md btn-full-width';
			findButton.onclick = () => chrome.runtime.sendMessage({
				message: {
					place: String(place_id),
					id: String(unique_jobid)
				}
			});
			findButton.addEventListener('click', function() {
				totalServersChecked.length = 0
			})
			if (document.getElementsByClassName('modal-window modal-sm modal-dialog')[0] != undefined) {
				chrome.storage.local.get(["showConfetti"], function(items) {
					if (items['showConfetti'] == 'Yes') {
						if (document.getElementById('confetti') == null) {
							initiate_confetti()
						}
					}
				})
				successAudio.play()
			}
			chrome.storage.local.get(["totalSearches"], function(items) {
				var totalSearches = items['totalSearches']
				var newTotalSearches = totalSearches + 1
				chrome.storage.local.get(["totalFinds"], function(items) {
					var totalFinds = items['totalFinds']
					var newTotalFinds = totalFinds + 1
					chrome.storage.local.set({
						"totalSearches": newTotalSearches
					})
					chrome.storage.local.set({
						"totalFinds": newTotalFinds
					})
				})
			})
			findLink.style.display = 'block';
			search_type = 'succeed';
		}
		inputField.addEventListener('input', async () => {
			let button_visible = false;
			if (inputField.value.trim() === '') {
				button_visible = false;
			} else if (searchByUserId) {
				if (/^\d+$/.test(inputField.value)) {
					button_visible = true;
				} else {
					button_visible = false;
				}
			} else {
				let username_arrays = await scan_username(inputField.value);
				if (username_arrays) {
					button_visible = true;
				} else {
					button_visible = false;
				}
			}
			if (button_visible) {
				findButton.className = 'modal-button enabled btn-primary-md btn-min-width';
				findButton.innerText = find_Translated;
			} else {
				findButton.className = 'modal-button disabled btn-primary-md btn-min-width';
				findButton.innerText = searchByUserId ? invalidUserId_Translated : invalidUsername_Translated;
			}
		});
		findButton.addEventListener('click', async function() {
			var playerActiveCount = document.getElementsByClassName('game-stat')[0].children[1].innerText.replace(',', '');
			if (search_type == 'retry') {
				try {
					document.getElementById('warningLabel').innerText = ''
				} catch {}
				search_type = 'static';
				findButton.innerHTML = find_Translated;
				inputField.disabled = false;
				modalTitle.textContent = whoDoYouWantToFind_Translated;
			} else if (search_type == 'static') {
				if (playerActiveCount > 50000) {
					try {
						document.getElementById('warningLabel').innerText = largePlayerCount_Translated
					} catch {}
				}
				let username_arrays;
				if (searchByUserId) {
					username_arrays = await get_user_by_id(inputField.value);
				} else {
					username_arrays = await scan_username(inputField.value);
				}
				if (!username_arrays) {
					findButton.className = 'modal-button disabled btn-primary-md btn-min-width';
					findButton.innerText = searchByUserId ? invalidUserId_Translated : invalidUsername_Translated;
					return;
				}
				startSearch()
				modalImageContainer.style.display = 'block';
				inputField.disabled = true;
				originalImage.src = loadingImage
				rotateAnimation(modalImageContainer, true);
				user_details = username_arrays;
				await updateUser(username_arrays);
				await searchServers();
			} else if (search_type == 'succeed') {
				findButton.className = 'modal-button enabled btn-primary-md btn-min-width';
				close_prompt();
			}
		});
		const modalFooter = document.createElement('div');
		const loadingDiv = document.createElement('div');
		const modalButtons = document.createElement('div');
		textLabel.className = 'form-label';
		textLabel.htmlFor = 'private-server-name-text-box';
		textLabel.textContent = searchByUserId ? userId_Translated : username_Translated;
		formGroup.appendChild(inputField);
		privateServerNameInput.appendChild(textLabel);
		privateServerNameInput.appendChild(formGroup);
		privateServerPurchase.appendChild(toggleContainer);
		privateServerPurchase.appendChild(privateServerNameInput);
		privateServerPurchase.appendChild(modalListItem);
		privateServerPurchase.appendChild(modalImageContainer);
		const repeatSearchContainer = document.createElement('div');
		repeatSearchContainer.className = 'repeat-search-container';
		repeatSearchContainer.id = 'repeat-search-container';
		repeatSearchContainer.style.textAlign = 'center';
		repeatSearchContainer.style.margin = '15px 0';
		const repeatSearchCheckbox = document.createElement('input');
		repeatSearchCheckbox.type = 'checkbox';
		repeatSearchCheckbox.id = 'repeat-search-checkbox';
		repeatSearchCheckbox.style.marginRight = '8px';
		repeatSearchCheckbox.style.cursor = 'pointer';
		repeatSearchCheckbox.style.accentColor = 'black';
		repeatSearchCheckbox.addEventListener('change', function() {
			repeatSearchEnabled = this.checked;
			if (this.checked) {
				chrome.storage.local.get(["hasSeenRepeatSearchTutorial"], function(items) {
					if (!items['hasSeenRepeatSearchTutorial']) {
						showRepeatSearchExplanation();
					}
				});
			}
		});
		const repeatSearchLabel = document.createElement('label');
		repeatSearchLabel.htmlFor = 'repeat-search-checkbox';
		repeatSearchLabel.textContent = repeatSearch_Translated;
		repeatSearchLabel.style.fontWeight = 'normal';
		repeatSearchLabel.style.cursor = 'pointer';
		repeatSearchContainer.appendChild(repeatSearchCheckbox);
		repeatSearchContainer.appendChild(repeatSearchLabel);
		privateServerPurchase.appendChild(repeatSearchContainer);

		function showRepeatSearchExplanation() {
			const currentModalContainer = document.getElementById('purchase-private-server-modal');
			const currentModalBackdrop = document.querySelector('.modal-backdrop');
			repeatSearchEnabled = true;
			if (currentModalContainer) currentModalContainer.style.display = 'none';
			if (currentModalBackdrop) currentModalBackdrop.style.display = 'none';
			const explanationBackdrop = document.createElement('div');
			const explanationContainer = document.createElement('div');
			const explanationWindow = document.createElement('div');
			const explanationContent = document.createElement('div');
			explanationBackdrop.className = 'modal-backdrop in';
			explanationBackdrop.style.zIndex = '1060';
			explanationBackdrop.setAttribute('role', 'dialog');
			explanationContainer.id = 'repeat-search-explanation-modal';
			explanationContainer.className = 'in modal';
			explanationContainer.style.display = 'block';
			explanationContainer.style.zIndex = '1061';
			explanationContainer.setAttribute('role', 'dialog');
			explanationContainer.setAttribute('tabindex', '-1');
			explanationWindow.className = 'modal-window modal-md modal-dialog';
			explanationContent.className = 'modal-content';
			explanationContent.setAttribute('role', 'document');
			const explanationHeader = document.createElement('div');
			explanationHeader.className = 'modal-header';
			const explanationTitle = document.createElement('h4');
			explanationTitle.className = 'modal-title';
			explanationTitle.textContent = howRepeatWorks_Translated;
			explanationHeader.appendChild(explanationTitle);
			const explanationBody = document.createElement('div');
			explanationBody.className = 'modal-body';
			const contentWrapper = document.createElement('div');
			const whatItDoesParagraph = document.createElement('p');
			whatItDoesParagraph.style.marginBottom = '15px';
			const whatItDoesLabel = document.createElement('span');
			whatItDoesLabel.style.fontWeight = 'bold';
			whatItDoesLabel.style.color = descFontColor;
			whatItDoesLabel.textContent = whatItDoes_Translated;
			whatItDoesParagraph.appendChild(whatItDoesLabel);
			whatItDoesParagraph.appendChild(document.createTextNode(` ${whatItDoesDesc_Translated}`));
			const noteParagraph = document.createElement('p');
			noteParagraph.style.marginBottom = '0';
			const noteLabel = document.createElement('span');
			noteLabel.style.fontWeight = 'bold';
			noteLabel.style.color = descFontColor
			noteLabel.textContent = note_Translated;
			noteParagraph.appendChild(noteLabel);
			noteParagraph.appendChild(document.createTextNode(` ${noteDesc_Translated}`));
			contentWrapper.appendChild(whatItDoesParagraph);
			contentWrapper.appendChild(noteParagraph);
			explanationBody.appendChild(contentWrapper);
			const explanationFooter = document.createElement('div');
			explanationFooter.className = 'modal-footer';
			const buttonContainer = document.createElement('div');
			buttonContainer.className = 'modal-buttons';
			buttonContainer.style.textAlign = 'center';
			const continueButton = document.createElement('button');
			continueButton.type = 'button';
			continueButton.className = 'modal-button btn-primary-md btn-min-width';
			continueButton.textContent = 'Continue';
			continueButton.addEventListener('click', function() {
				chrome.storage.local.set({
					"hasSeenRepeatSearchTutorial": true
				});
				explanationContainer.remove();
				explanationBackdrop.remove();
				if (currentModalContainer) currentModalContainer.style.display = 'block';
				if (currentModalBackdrop) currentModalBackdrop.style.display = 'block';
				repeatSearchCheckbox.checked = true;
			});
			buttonContainer.appendChild(continueButton);
			explanationFooter.appendChild(buttonContainer);
			explanationContent.appendChild(explanationHeader);
			explanationContent.appendChild(explanationBody);
			explanationContent.appendChild(explanationFooter);
			explanationWindow.appendChild(explanationContent);
			explanationContainer.appendChild(explanationWindow);
			document.body.appendChild(explanationBackdrop);
			document.body.appendChild(explanationContainer);
		}
		modalBody.appendChild(privateServerPurchase);
		modalBody.appendChild(privateServerPurchase);
		modalFooter.className = 'modal-footer';
		loadingDiv.className = 'loading';
		modalButtons.className = 'modal-buttons';
		modalButtons.appendChild(findButton);
		modalButtons.appendChild(findLink);
		modalFooter.appendChild(loadingDiv);
		modalFooter.appendChild(modalButtons);
		modalContent.appendChild(modalHeader);
		modalContent.appendChild(modalBody);
		modalContent.appendChild(modalFooter);
		modalWindow.appendChild(modalContent);
		modalContainer.appendChild(modalWindow);
		document.body.appendChild(modalBackdrop);
		document.body.appendChild(modalContainer);
		async function updateUser(user_details) {
			try {
				const user_id = user_details[1]
				const {
					data: [{
						imageUrl
					}]
				} = await get(`thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${user_id}&size=150x150&format=Png&isCircular=false`);
				if (imageUrl.includes('https://tr.rbxcdn.com')) {
					playerImageUrl = imageUrl;
					playerUrlReady = true;
				}
			} catch (error) {
				playerUrlReady = true;
			}
		}
		async function fetchServers(pass = 1, cursor = '', attempts = 0) {
			if (closedAlready.includes('closed')) {
				return;
			}
			if (nullg.length > 0) {
				return;
			} else {
				if (closedAlready.includes('closed')) {
					return;
				}
				const response = await get(`games.roblox.com/v1/games/${place_id}/servers/Public?limit=100&cursor=${cursor}`);
				if (closedAlready.includes('closed')) {
					return;
				}
				const {
					nextPageCursor,
					data
				} = response;
				if (attempts >= 1) return;
				if (!data || data.length === 0) {
					if (!nextPageCursor) return;
					if (nextPageCursor == null) return;
					return fetchServers(pass, cursor, attempts + 1);
				}
				data.forEach((server) => {
					totalServersChecked.push('server');
					if (!serverIds.has(server.id)) {
						server.playerTokens.forEach((playerToken) => {
							serverIds.add(server.id);
							playersCount += 1;
							allPlayers.push({
								token: playerToken,
								type: Avatar_Type,
								size: Avatar_Size,
								requestId: server.id,
							});
						});
					}
					maxPlayers = server.maxPlayers;
				});
				if (closedAlready.includes('closed')) {
					return;
				}
				chrome.storage.local.get(["totalServers"], function(items) {
					if (items['totalServers'] == 'Yes') {
						const serversCheckedElement = document.getElementById('serversCheckedCount');
						if (serversCheckedElement) {
							serversCheckedElement.innerText = serversCheckedTotal_Translated.replace('666', totalServersChecked.length);
						}
					}
				});
				if (nextPageCursor == null) {
					nullg.push('true');
					return;
				}
				if (!nextPageCursor) return;
				if (closedAlready.includes('closed')) {
					return;
				}
				return fetchServers(pass, nextPageCursor);
			}
		}
		async function findTarget() {
			while (true) {
				if (closedAlready.includes('closed')) {
					return;
				}
				const chosenPlayers = [];
				for (let i = 0; i < 100; i++) {
					const playerToken = allPlayers.shift();
					if (!playerToken) {
						break;
					}
					chosenPlayers.push(playerToken);
				}
				if (!chosenPlayers.length) {
					if (playersChecked === playersCount && foundAllServers) {
						break;
					}
					if (closedAlready.includes('closed')) {
						return;
					}
					await sleep(0.1);
					continue;
				}
				if (closedAlready.includes('closed')) {
					return;
				}
				post('thumbnails.roblox.com/v1/batch', JSON.stringify(chosenPlayers)).then(({
					data: thumbnailsData
				}) => {
					if (closedAlready.includes('closed')) {
						return;
					}
					thumbnailsData.forEach((thumbnailData) => {
						const thumbnails = allThumbnails.get(thumbnailData.requestId) || [];
						if (thumbnails.length == 0) {
							allThumbnails.set(thumbnailData.requestId, thumbnails);
						}
						playersChecked += 1;
						thumbnails.push(thumbnailData.imageUrl);
						let containsId = false;
						targetServerIds.forEach((targetServerId) => {
							if (targetServerId.serverId == thumbnailData.requestId) containsId = true;
						});
						if (!containsId) targetServerIds.push({
							serverId: thumbnailData.requestId
						});
					});
				});
			}
			if (closedAlready.includes('closed')) {
				return;
			}
			targetServerIds.forEach((targetServerId) => {
				targetServerId.serverSize = allThumbnails.get(targetServerId.serverId).length;
			});
			if (targetServerIds.length && !closedAlready.includes('closed')) {
				targetServerIds.forEach(targetServerId => {
					const thumbnails = allThumbnails.get(targetServerId.serverId);
					thumbnails.reverse();
				});
				preLoadServers();
			}
		}
		async function preLoadServers() {
			targetServerIds.sort((a, b) => {
				return b.serverSize - a.serverSize;
			});
			maxPages = 1;
			let serverCount = targetServerIds.length;
			while (serverCount > maxServersPerPage) {
				maxPages += 1;
				serverCount -= maxServersPerPage;
			}
			while (!playerUrlReady) {
				await sleep(.1);
			}
			for (let i = 0; i < targetServerIds.length; i++) {
				const thumbnails = allThumbnails.get(targetServerIds[i].serverId);
				for (let j = 0; j < thumbnails.length; j++) {
					if (thumbnails[j] === playerImageUrl ? thumbnails[j] : null) {
						player_found = true
						const server_id_generation = targetServerIds[i].serverId
						let serverCount = i + 1;
						while (serverCount > maxServersPerPage) {
							serverCount -= maxServersPerPage;
						}
						success_scan_apperance();
						unique_jobid = server_id_generation;
					}
				}
			}
			if (!player_found) {
				await failed_scan_apperance();
			}
		};
		async function searchServers() {
			targetServerIds = [];
			serverIds.clear();
			friendServers.clear();
			allThumbnails.clear();
			foundAllServers = false;
			allPlayers = [];
			playersCount = 0;
			playersChecked = 0;
			maxPlayers = 0;
			if (closedAlready.includes('closed')) {
				return;
			}
			var passes = 10;
			findTarget();
			for (var pass = 0; pass < passes; pass++) {
				if (closedAlready.includes('closed')) {
					return;
				}
				if (!foundAllServers) {
					await fetchServers(pass + 1);
				}
			}
			foundAllServers = true;
		}
	}
	var place_id = window.location.href.match(/games\/(\d+)\//);
	if (place_id) {
		place_id = place_id[1];
	}
	const closedAlready = []
	const main_Servers_panel = document.getElementById('running-game-instances-container');
	const private_server_btn = document.createElement('button');
	const settings_btn = document.createElement('a')
	const image_container = document.createElement('div');
	const settingsTab = document.createElement('div')
	const aForImageLabel = document.createElement('a')
	const spacingBetweenImage = document.createElement('label')
	const imageLabel = document.createElement('img');
	imageLabel.className = "unselectable"
	const unselectableStyle = document.createElement('style')
	unselectableStyle.innerHTML = `.unselectable {
    pointer-events: none;
    user-select: none;
}`
	document.head.append(unselectableStyle)
	var successAudio = new Audio();
	successAudio.src = chrome.runtime.getURL('storage/successAudio.mp3')
	private_server_btn.setAttribute('type', 'button');
	private_server_btn.classList.add('btn-more', 'btn', 'btn-secondary-md', 'btn-min-width');
	private_server_btn.innerText = 'BloxFinder';
	private_server_btn.id = 'bloxfinderOpenButton'
	private_server_btn.style.fontWeight = 'bold'
	private_server_btn.style.width = '145px'
	private_server_btn.style.height = '40px';
	private_server_btn.style.fontSize = '22px'
	private_server_btn.style.zIndex = '2';
	private_server_btn.style.padding = '0';
	private_server_btn.style.textAlign = 'center';
	private_server_btn.style.lineHeight = '20px';

	private_server_btn.style.transition = 'transform 0.2s ease';

	private_server_btn.addEventListener('mouseenter', function() {
		private_server_btn.style.transform = 'translateY(-1px)';
	});

	private_server_btn.addEventListener('mouseleave', function() {
		private_server_btn.style.transform = 'translateY(0px)';
	});
	settings_btn.id = 'settingsArea'
	settings_btn.innerHTML = '<label style="visibility:hidden;font-size:13px">d</label><button type="button" class="btn-more btn btn-secondary-md btn" style="font-weight: bold; width: 40px; height: 40px; font-size: 22px; z-index: 2; padding: 0px; text-align: center; line-height: 20px;"><span class="icon-nav-settings roblox-popover-close" id="nav-settings"></span></button>'

	const innerSettingsBtn = settings_btn.querySelector('button');
	innerSettingsBtn.style.transition = 'transform 0.2s ease';

	innerSettingsBtn.addEventListener('mouseenter', function() {
		innerSettingsBtn.style.transform = 'translateY(-1px)';
	});

	innerSettingsBtn.addEventListener('mouseleave', function() {
		innerSettingsBtn.style.transform = 'translateY(0px)';
	});

	settingsTab.id = 'settingsTab'
	settingsTab.innerHTML = `<input type="checkbox" style="cursor: pointer; accent-color: black;" id="showTotalServersElement"><label id="showTotalServersElement2"> ${showTotalServersChecked_Translated} </label><br><input style="cursor: pointer; accent-color: black;" type="checkbox" id="showConfettiElement"><label id="showConfettiElement2"> ${confettiParticles_Translated}</label><br><br><br>`
	settingsTab.style.display = 'none'
	image_container.style.display = 'inline-flex';
	image_container.style.alignItems = 'center';
	imageLabel.src = chrome.runtime.getURL('images/logo.png');
	imageLabel.style.marginLeft = '2px';
	imageLabel.style.height = '64px';
	imageLabel.style.width = 'auto';
	imageLabel.style.zIndex = '0';

	imageLabel.style.transition = 'transform 0.3s ease';
	imageLabel.style.cursor = 'pointer';
	imageLabel.style.pointerEvents = 'auto';

	imageLabel.addEventListener('mouseenter', function() {
		imageLabel.style.transform = 'rotate(4deg)';
	});

	imageLabel.addEventListener('mouseleave', function() {
		imageLabel.style.transform = 'rotate(0deg)';
	});
	spacingBetweenImage.innerHTML = '<label style="visibility:hidden;font-size:5px">d</label>'
	aForImageLabel.append(spacingBetweenImage)
	aForImageLabel.append(imageLabel)
	let Avatar_Type = 'AvatarHeadshot';
	let Avatar_Size = '150x150'
	let foundAllServers = false;
	let allPlayers = [];
	let playersCount = 0;
	let playersChecked = 0;
	let maxServersPerPage = 10;
	let maxPages = 1;
	let playerImageUrl;
	let playerUrlReady = false;
	let search_type = 'static';
	let player_found = false;
	let unique_jobid;
	let totalServersChecked = []
	const serverIds = new Set();
	const friendServers = new Map();
	const allThumbnails = new Map();
	const sleep = time => new Promise(res => setTimeout(res, time * 1000));
	const style = document.createElement('style');
	style.innerHTML = `
@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
`;
	document.head.appendChild(style);
	let targetServerIds = {
		serverId: "",
		serverSize: 0
	};
	if (main_Servers_panel) {
		image_container.appendChild(private_server_btn);
		image_container.appendChild(settings_btn)
		image_container.appendChild(aForImageLabel);
		main_Servers_panel.insertBefore(settingsTab, main_Servers_panel.firstChild);
		main_Servers_panel.insertBefore(image_container, main_Servers_panel.firstChild);
		private_server_btn.addEventListener('click', function() {
			try {
				var serverSize = document.getElementsByClassName('game-stat')[7].children[1].innerText
			} catch {
				var serverSize = 20
			}
			if (serverSize != 1) {
				show_warning()
			} else {
				low_server_size()
			}
		});
		settings_btn.addEventListener('click', function() {
			if (document.getElementById('settingsTab').style.display == 'none') {
				document.getElementById('settingsTab').style.display = 'block'
				chrome.storage.local.get(["totalServers"], function(items) {
					if (items['totalServers'] == 'Yes') {
						document.getElementById('showTotalServersElement').checked = true
					} else {
						document.getElementById('showTotalServersElement').checked = false
					}
				})
				chrome.storage.local.get(["showConfetti"], function(items) {
					if (items['showConfetti'] == 'Yes') {
						document.getElementById('showConfettiElement').checked = true
					} else {
						document.getElementById('showConfettiElement').checked = false
					}
				})
				document.getElementById('showTotalServersElement').addEventListener('click', function() {
					if (document.getElementById('showTotalServersElement').checked == true) {
						chrome.storage.local.set({
							"totalServers": "Yes"
						})
					} else {
						chrome.storage.local.set({
							"totalServers": "No"
						})
					}
				});

				document.getElementById('showConfettiElement').addEventListener('click', function() {
					if (document.getElementById('showConfettiElement').checked == true) {
						chrome.storage.local.set({
							"showConfetti": "Yes"
						})
					} else {
						chrome.storage.local.set({
							"showConfetti": "No"
						})
					}
				});
				document.getElementById('showTotalServersElement2').addEventListener('click', function() {
					if (document.getElementById('showTotalServersElement').checked == true) {
						chrome.storage.local.set({
							"totalServers": "No"
						})
						document.getElementById('showTotalServersElement').checked = false
					} else {
						chrome.storage.local.set({
							"totalServers": "Yes"
						})
						document.getElementById('showTotalServersElement').checked = true
					}
				});
	
				document.getElementById('showConfettiElement2').addEventListener('click', function() {
					if (document.getElementById('showConfettiElement').checked == true) {
						chrome.storage.local.set({
							"showConfetti": "No"
						})
						document.getElementById('showConfettiElement').checked = false
					} else {
						chrome.storage.local.set({
							"showConfetti": "Yes"
						})
						document.getElementById('showConfettiElement').checked = true
					}
				});
			} else {
				document.getElementById('settingsTab').style.display = 'none'
			}
		});
		aForImageLabel.addEventListener('click', function() {
			var serverSize = document.getElementsByClassName('game-stat')[7].children[1].innerText
			if (serverSize != 1) {
				if (serverSize > 5) {
					show_warning()
				} else {
					search_frame(whoDoYouWantToFind_Translated, '');
				}
			} else {
				low_server_size()
			}
		});
	}
}
initiate()

function showTutorialPopup() {
  chrome.runtime.sendMessage({ action: 'showTutorial' }, (response) => {
  });
}

if (window.location.href.includes('charts?tutorial')) {
  showTutorialPopup();
}