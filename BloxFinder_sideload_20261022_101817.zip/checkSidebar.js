(function () {
  if (window.location.hostname !== "roblox.com" && window.location.hostname !== "www.roblox.com") {
    return;
  }

  chrome.runtime.sendMessage({ type: 'REFRESH_LOCALE' });

  function removePromoButton() {
    const promoBtn = document.getElementById('nav-sidebutton');
    if (promoBtn) {
      const promoLi = promoBtn.closest('li');
      if (promoLi) promoLi.remove();
      else promoBtn.remove();
    }
  }

  function checkUrl() {
    if (window.location.pathname.includes("/roearn")) {
      localStorage.setItem("alreadyInstalled", "true");
      removePromoButton();
    }
  }

  checkUrl();

  const urlObserver = new MutationObserver(checkUrl);
  urlObserver.observe(document.documentElement, { childList: true, subtree: true });

  if (window.location.pathname.includes("/roearn")) return;

  const THREE_DAYS_MS = 3 * 24 * 60 * 60 * 1000;
  const EXTENSION_URL = 'https://chromewebstore.google.com/detail/fooenmopnfaejehogdbmegaleanpdcea?utm_campaign=sidebar';

  let cachedMessages = null;

  async function loadMessages() {
    let locale = 'en';
    try {
      const result = await chrome.storage.local.get(['userLocale']);
      locale = result.userLocale || 'en';
    } catch (e) {}

    loadMessages._locale = locale;

    try {
      const messagesUrl = chrome.runtime.getURL(`_locales/${locale}/messages.json`);
      const response = await fetch(messagesUrl);
      if (response.ok) {
        cachedMessages = await response.json();
        return cachedMessages;
      }
    } catch (e) {}

    try {
      const fallbackUrl = chrome.runtime.getURL('_locales/en/messages.json');
      const response = await fetch(fallbackUrl);
      cachedMessages = await response.json();
      return cachedMessages;
    } catch (e) {}

    cachedMessages = {};
    return cachedMessages;
  }

  function getMessage(key) {
    if (!cachedMessages || !cachedMessages[key]) return key;
    return cachedMessages[key].message;
  }

  function isNewUI() {
    return !!document.querySelector('div.left-nav ul.flex');
  }

  function isDarkModeNewUI() {
    const nav = document.querySelector('div.left-nav');
    if (!nav) return false;
    const bg = getComputedStyle(nav).backgroundColor;
    const match = bg.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
    if (match) {
      const brightness = (parseInt(match[1]) + parseInt(match[2]) + parseInt(match[3])) / 3;
      return brightness < 128;
    }
    return false;
  }

  function createNewUIButton() {
    if (document.getElementById('nav-roearn')) return;

    const locale = loadMessages._locale || 'en';
    const noBadgeLocales = ['es', 'fr', 'it'];

    const navList = document.querySelector('div.left-nav ul.flex');
    if (!navList) return;

    const profileAvatarEl = navList.querySelector('.radius-circle.clip.size-600');
    if (!profileAvatarEl) return;

    const profileLi = profileAvatarEl.closest('li');
    if (!profileLi) return;

    const existing = document.getElementById('nav-sidebutton');
    if (existing) {
      const existingLi = existing.closest('li');
      if (existingLi && existingLi.previousElementSibling !== profileLi) {
        existingLi.remove();
      } else {
        return;
      }
    }

    const isDark = isDarkModeNewUI();

    const roEarnLi = document.createElement('li');

    const roEarnLink = document.createElement('a');
    roEarnLink.href = EXTENSION_URL;
    roEarnLink.id = 'nav-sidebutton';
    roEarnLink.target = '_blank';
    roEarnLink.className = 'content-emphasis text-title-large flex items-center gap-small padding-left-xsmall padding-right-xxsmall radius-medium relative clip group/interactable focus-visible:outline-focus disabled:outline-none';

    const hoverDiv = document.createElement('div');
    hoverDiv.setAttribute('role', 'presentation');
    hoverDiv.className = 'absolute inset-[0] transition-colors group-hover/interactable:bg-[var(--color-state-hover)] group-active/interactable:bg-[var(--color-state-press)] group-disabled/interactable:bg-none';

    const iconWrapper = document.createElement('span');
    iconWrapper.className = 'size-1000 grow-0 shrink-0 basis-auto flex justify-center items-center';

    const iconImg = document.createElement('img');
    iconImg.src = isDark
      ? chrome.runtime.getURL('images/sidebar-icon-white.png')
      : chrome.runtime.getURL('images/sidebar-icon.png');
    iconImg.style.width = '24px';
    iconImg.style.height = '24px';
    iconImg.style.transition = 'filter 0.2s ease';
    iconImg.style.userSelect = 'none';
    iconImg.style.webkitUserSelect = 'none';
    iconImg.style.mozUserSelect = 'none';
    iconImg.style.msUserSelect = 'none';
    iconImg.style.pointerEvents = 'none';
    iconImg.draggable = false;

    const defaultFilter = isDark
      ? 'none'
      : 'brightness(0) saturate(100%) invert(30%) sepia(0%) saturate(0%) hue-rotate(0deg) brightness(60%) contrast(90%)';
    const hoverFilter = isDark
      ? 'none'
      : 'brightness(0) saturate(100%) invert(10%) sepia(0%) saturate(0%) hue-rotate(0deg) brightness(20%) contrast(90%)';

    iconImg.style.filter = defaultFilter;

    roEarnLink.addEventListener('mouseenter', function () { iconImg.style.filter = hoverFilter; });
    roEarnLink.addEventListener('mouseleave', function () { iconImg.style.filter = defaultFilter; });

    iconWrapper.appendChild(iconImg);

    const textSpan = document.createElement('span');
    textSpan.className = 'min-width-0 text-truncate-end text-no-wrap';
    textSpan.textContent = 'RoEarn';

    roEarnLink.appendChild(hoverDiv);
    roEarnLink.appendChild(iconWrapper);
    roEarnLink.appendChild(textSpan);

    if (!noBadgeLocales.includes(locale)) {
      const badgeWrapper = document.createElement('span');
      badgeWrapper.className = 'fill basis-auto padding-x-small flex justify-end items-center';

      const badge = document.createElement('div');
      badge.className = 'foundation-web-badge flex items-center radius-circle select-none height-600 gap-xsmall width-[fit-content] padding-x-small bg-system-contrast content-inverse-emphasis stroke-none';
      badge.style.borderColor = 'var(--light-mode-stroke-default)';

      const badgeText = document.createElement('span');
      badgeText.className = 'padding-y-xsmall text-no-wrap text-truncate-split text-label-small content-inverse-emphasis';
      badgeText.textContent = getMessage('sidebarBadgeNew');

      badge.appendChild(badgeText);
      badgeWrapper.appendChild(badge);
      roEarnLink.appendChild(badgeWrapper);
    }

    roEarnLi.appendChild(roEarnLink);
    profileLi.insertAdjacentElement('afterend', roEarnLi);
  }

  function injectHideCSS() {
    if (document.getElementById('roearn-nav-style')) return true;
    if (!document.head) return false;
    const style = document.createElement('style');
    style.id = 'roearn-nav-style';
    style.textContent = `
      #navigation .left-col-list { visibility: hidden !important; }
      #navigation .left-col-list.roearn-ready { visibility: visible !important; }
    `;
    document.head.appendChild(style);
    return true;
  }

  function createOldUIButton() {
    if (document.getElementById('nav-roearn')) return;
    if (document.getElementById('nav-sidebutton')) return;

    const navList = document.querySelector('#navigation .left-col-list');
    if (!navList) return;

    const rbxBody = document.getElementById('rbx-body');
    const isDarkTheme = rbxBody && rbxBody.classList.contains('dark-theme');

    const roEarnLi = document.createElement('li');

    const roEarnLink = document.createElement('a');
    roEarnLink.className = 'dynamic-overflow-container text-nav';
    roEarnLink.href = EXTENSION_URL;
    roEarnLink.id = 'nav-sidebutton';
    roEarnLink.target = '_blank';

    const iconDiv = document.createElement('div');
    const iconImg = document.createElement('img');
    iconImg.src = chrome.runtime.getURL('images/sidebar-icon.png');
    iconImg.style.width = '28px';
    iconImg.style.height = '28px';
    iconImg.style.transition = 'filter 0.2s ease';
    iconImg.style.userSelect = 'none';
    iconImg.style.webkitUserSelect = 'none';
    iconImg.style.mozUserSelect = 'none';
    iconImg.style.msUserSelect = 'none';
    iconImg.style.pointerEvents = 'none';
    iconImg.draggable = false;

    let defaultFilter, hoverFilter;

    if (isDarkTheme) {
      defaultFilter = 'brightness(0) saturate(100%) invert(76%) sepia(0%) saturate(262%) hue-rotate(155deg) brightness(92%) contrast(87%)';
      hoverFilter = 'brightness(0) invert(1)';
    } else {
      defaultFilter = 'brightness(0) saturate(100%) invert(50%) sepia(6%) saturate(378%) hue-rotate(155deg) brightness(93%) contrast(88%)';
      hoverFilter = 'brightness(0) saturate(100%) invert(22%) sepia(4%) saturate(686%) hue-rotate(155deg) brightness(95%) contrast(90%)';
    }

    iconImg.style.filter = defaultFilter;
    iconDiv.appendChild(iconImg);

    const textSpan = document.createElement('span');
    textSpan.className = 'font-header-2 dynamic-ellipsis-item';
    textSpan.title = 'RoEarn';
    textSpan.textContent = 'RoEarn';

    const badgeWrapper = document.createElement('div');
    badgeWrapper.className = 'dynamic-width-item align-right';

    const badge = document.createElement('span');
    badge.className = 'notification-blue notification';
    badge.textContent = getMessage('sidebarBadgeNew');

    badgeWrapper.appendChild(badge);

    roEarnLink.addEventListener('mouseenter', function () { iconImg.style.filter = hoverFilter; });
    roEarnLink.addEventListener('mouseleave', function () { iconImg.style.filter = defaultFilter; });

    roEarnLink.appendChild(iconDiv);
    roEarnLink.appendChild(textSpan);
    roEarnLink.appendChild(badgeWrapper);
    roEarnLi.appendChild(roEarnLink);
    navList.insertBefore(roEarnLi, navList.firstChild);
    navList.classList.add('roearn-ready');
  }

  function createRoEarnButton() {
    if (isNewUI()) {
      createNewUIButton();
    } else {
      if (!injectHideCSS()) {
        const headObserver = new MutationObserver(() => {
          if (injectHideCSS()) headObserver.disconnect();
        });
        headObserver.observe(document.documentElement, { childList: true, subtree: true });
      }
      createOldUIButton();
    }
  }

  async function processButtonLogic() {
    if (localStorage.getItem("alreadyInstalled") === "true") return;

    await loadMessages();

    const showSidebarButton = localStorage.getItem("showSidebarButton");

    if (showSidebarButton === "true") {
      createRoEarnButton();
      return;
    }

    const timeForButton = localStorage.getItem("timeForButton");

    if (timeForButton) {
      const timePassed = Date.now() - parseInt(timeForButton, 10);
      if (timePassed >= THREE_DAYS_MS) {
        localStorage.removeItem("timeForButton");
        localStorage.setItem("showSidebarButton", "true");
        createRoEarnButton();
      }
    } else {
      localStorage.setItem("timeForButton", Date.now().toString());
    }
  }

  let oldObserver = new MutationObserver(() => processButtonLogic());
  let newObserver = new MutationObserver(() => processButtonLogic());

  oldObserver.observe(document.documentElement, { childList: true, subtree: true });
  newObserver.observe(document.documentElement, { childList: true, subtree: true });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', processButtonLogic);
  } else {
    processButtonLogic();
  }
})();