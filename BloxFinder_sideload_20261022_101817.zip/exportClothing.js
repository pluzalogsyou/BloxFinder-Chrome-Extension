~function() {

  var go = function(e) { e.preventDefault(); e.stopPropagation(); window.open('https://roexport.io/redirect', '_blank'); };
  var isClothing = /\/(Shirt|Pants|Tshirt)\//;
  var clothingTypes = [2, 11, 12];

  var stxt = 'Save Template';
  var rtxt = 'Re-Upload';

  var localeKeys = 'en_us,id_id,de_de,es_es,fr_fr,it_it,pl_pl,pt_br,vi_vn,tr_tr,th_th,zh_cn,zh_tw,ja_jp,ko_kr,ar_001'.split(',');
  var localeCodes = 'en,id,de,es,fr,it,pl,pt-BR,vi,tr,th,zh-CN,zh-TW,ja,ko,ar'.split(',');
  var saveStrings = ['Save Template','Simpan Template','Vorlage speichern','Guardar plantilla','Enregistrer le modèle','Salva modello','Zapisz szablon','Salvar modelo','Lưu mẫu','Şablonu kaydet','บันทึกแม่แบบ','保存模板','儲存範本','テンプレートを保存','템플릿 저장','حفظ القالب'];
  var reupStrings = ['Re-Upload','Unggah Ulang','Erneut hochladen','Volver a subir','Re-télécharger','Ricarica','Prześlij ponownie','Reenviar','Tải lên lại','Yeniden yükle','อัปโหลดใหม่','重新上传','重新上傳','再アップロード','다시 업로드','إعادة الرفع'];

  fetch('https://locale.roblox.com/v1/locales/user-localization-locus-supported-locales', {credentials:'include'})
    .then(function(r) { return r.json(); })
    .then(function(d) {
      var raw = ((d || {}).generalExperience || {}).locale || 'en_us';
      raw = raw.toLowerCase();
      var idx = localeKeys.indexOf(raw);
      if (idx === -1) idx = localeCodes.indexOf(raw.split('_')[0]);
      if (idx !== -1) { stxt = saveStrings[idx]; rtxt = reupStrings[idx]; }
    })
    .catch(function(){});

  var iS = '<svg fill="#fff" width="13px" height="13px" viewBox="0 0 36 36" xmlns="http://www.w3.org/2000/svg"><path d="M17,22a1,1,0,0,1,1-1h8V6a2,2,0,0,0-2-2H10.87L4,10.86V30a2,2,0,0,0,2,2H24a2,2,0,0,0,2-2V23H18A1,1,0,0,1,17,22ZM12,12H6v-.32L11.69,6H12Z"/><path d="M29.32,16.35a1,1,0,0,0-1.41,1.41L31.16,21H26v2h5.19l-3.28,3.28a1,1,0,1,0,1.41,1.41L35,22Z"/></svg>';
  var iR = '<svg fill="#fff" width="13px" height="13px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 15.75C12.4142 15.75 12.75 15.4142 12.75 15V4.02744L14.4306 5.98809C14.7001 6.30259 15.1736 6.33901 15.4881 6.06944C15.8026 5.79988 15.839 5.3264 15.5694 5.01191L12.5694 1.51191C12.427 1.34567 12.2189 1.25 12 1.25C11.7811 1.25 11.573 1.34567 11.4306 1.51191L8.43056 5.01191C8.16099 5.3264 8.19741 5.79988 8.51191 6.06944C8.8264 6.33901 9.29988 6.30259 9.56944 5.98809L11.25 4.02744L11.25 15C11.25 15.4142 11.5858 15.75 12 15.75Z"/><path d="M16 9C15.2978 9 14.9467 9 14.6945 9.16851C14.5853 9.24148 14.4915 9.33525 14.4186 9.44446C14.25 9.69667 14.25 10.0478 14.25 10.75L14.25 15C14.25 16.2426 13.2427 17.25 12 17.25C10.7574 17.25 9.75004 16.2426 9.75004 15L9.75004 10.75C9.75004 10.0478 9.75004 9.69664 9.58149 9.4444C9.50854 9.33523 9.41481 9.2415 9.30564 9.16855C9.05341 9 8.70227 9 8 9C5.17157 9 3.75736 9 2.87868 9.87868C2 10.7574 2 12.1714 2 14.9998V15.9998C2 18.8282 2 20.2424 2.87868 21.1211C3.75736 21.9998 5.17157 21.9998 8 21.9998H16C18.8284 21.9998 20.2426 21.9998 21.1213 21.1211C22 20.2424 22 18.8282 22 15.9998V14.9998C22 12.1714 22 10.7574 21.1213 9.87868C20.2426 9 18.8284 9 16 9Z"/></svg>';
  var iSL = iS.replace('width="13px" height="13px"', 'width="14px" height="14px"');
  var iRL = iR.replace('width="13px" height="13px"', 'width="14px" height="14px"');

  // /vi/catalog, /en/catalog, /catalog all match — no ^ anchor
  function atIndex() { return /\/catalog\/?$/.test(location.pathname); }
  function atItem()  { return /\/catalog\/\d+/.test(location.pathname); }

  function putStyles() {
    if (document.getElementById('__xroe_styles__')) return;
    var el = document.createElement('style');
    el.id = '__xroe_styles__';
    el.textContent = [
      '.__xroe_ib__{width:30px;height:30px;border:none;border-radius:4px;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0;transition:filter .15s;flex-shrink:0}',
      '.__xroe_ib__:hover{filter:brightness(1.15)}',
      '.__xroe_ib__.__xroe_e__{background:#393b3d}',
      '.__xroe_ib__.__xroe_r__{background:#2d8a4e}',
      '#__xroe_tip__{position:fixed;z-index:999999;pointer-events:none;background:#1a1a1a;border:1px solid #333;border-radius:5px;padding:5px 9px;font-size:11px;font-weight:600;color:#888;white-space:nowrap;box-shadow:0 4px 14px rgba(0,0,0,.5);transform:translate(12px,-110%);opacity:0;transition:opacity .1s;font-family:inherit;letter-spacing:.03em}',
      '#__xroe_tip__.visible{opacity:1}',
      '#__xroe_sec__ .__xroe_bw__{position:relative;flex:1;display:flex;zoom:1.4}',
      '#__xroe_sec__ .__xroe_bw__ button{flex:1}',
      '#__xroe_sec__ .__xroe_rb__{background:#2d8a4e}',
      '#__xroe_sec__ .__xroe_rb__:hover{filter:brightness(1.1)}',
    ].join('');
    document.head.appendChild(el);
  }

  function putTip() {
    if (document.getElementById('__xroe_tip__')) return;
    var t = document.createElement('div');
    t.id = '__xroe_tip__';
    document.body.appendChild(t);
    document.addEventListener('mousemove', function(e) { t.style.left = e.clientX + 'px'; t.style.top = e.clientY + 'px'; });
  }

  function showTip(txt) { var t = document.getElementById('__xroe_tip__'); if (t) { t.textContent = txt; t.classList.add('visible'); } }
  function hideTip()    { var t = document.getElementById('__xroe_tip__'); if (t) t.classList.remove('visible'); }

  function stamp(card) {
    if (card.querySelector('.__xroe__')) return;
    var img = card.querySelector('.thumbnail-2d-container img');
    if (!img || !isClothing.test(img.src)) return;
    var a = card.querySelector('a.item-card-link[href]');
    if (!a || !a.href.match(/\/catalog\/\d+/)) return;

    var lock   = function() { a._bk = a.href; a.removeAttribute('href'); };
    var unlock = function() { if (a._bk) a.href = a._bk; };

    if (atIndex()) {
      var cap = card.querySelector('.item-card-caption');
      if (!cap) return;
      var W = 'color:#fff;border:none;border-radius:4px;padding:6px 10px;font-size:13px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:7px;width:100%;font-family:inherit;transition:filter .15s;';
      var box = document.createElement('div');
      box.className = '__xroe__';
      box.style.cssText = 'display:flex;flex-direction:column;gap:6px;width:100%;padding:3px 0;margin-top:3px;box-sizing:border-box';
      var rb = document.createElement('button');
      rb.style.cssText = W + 'background:#2d8a4e';
      rb.innerHTML = iRL + '<span>' + rtxt + '</span>';
      rb.addEventListener('click', go);
      rb.addEventListener('mouseenter', function() { rb.style.filter = 'brightness(1.15)'; });
      rb.addEventListener('mouseleave', function() { rb.style.filter = ''; });
      var sb = document.createElement('button');
      sb.style.cssText = W + 'background:#393b3d';
      sb.innerHTML = iSL + '<span>' + stxt + '</span>';
      sb.addEventListener('click', go);
      sb.addEventListener('mouseenter', function() { sb.style.filter = 'brightness(1.15)'; });
      sb.addEventListener('mouseleave', function() { sb.style.filter = ''; });
      box.appendChild(rb);
      box.appendChild(sb);
      box.addEventListener('mouseenter', lock);
      box.addEventListener('mouseleave', unlock);
      a.insertBefore(box, cap);
      return;
    }

    var tc = card.querySelector('.item-card-thumb-container');
    if (!tc) return;
    tc.style.position = 'relative';
    var box = document.createElement('div');
    box.className = '__xroe__';
    box.style.cssText = 'position:absolute;bottom:6px;left:6px;display:flex;gap:4px;z-index:100';
    box.addEventListener('mouseenter', lock);
    box.addEventListener('mouseleave', function() { unlock(); hideTip(); });
    var eb = document.createElement('button');
    eb.className = '__xroe_ib__ __xroe_e__';
    eb.innerHTML = iS;
    eb.addEventListener('click', go);
    eb.addEventListener('mouseenter', function() { showTip(stxt); });
    eb.addEventListener('mouseleave', hideTip);
    var rb = document.createElement('button');
    rb.className = '__xroe_ib__ __xroe_r__';
    rb.innerHTML = iR;
    rb.addEventListener('click', go);
    rb.addEventListener('mouseenter', function() { showTip(rtxt); });
    rb.addEventListener('mouseleave', hideTip);
    box.appendChild(eb);
    box.appendChild(rb);
    tc.appendChild(box);
  }

  function buildSection() {
    if (document.getElementById('__xroe_sec__')) return;
    var det = document.querySelector('.item-details-section');
    if (!det) return;
    var m = location.pathname.match(/\/catalog\/(\d+)/);
    if (!m) return;
    fetch('https://catalog.roblox.com/v1/catalog/items/' + m[1] + '/details?itemType=asset', {credentials:'include'})
      .then(function(r) { return r.json(); })
      .then(function(d) {
        if (!d || clothingTypes.indexOf(d.assetType) === -1) return;
        if (document.getElementById('__xroe_sec__')) return;
        var det2 = document.querySelector('.item-details-section');
        if (!det2) return;
        var B = 'color:#fff;border:none;border-radius:4px;padding:6px 10px;font-size:13px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:7px;';
        var sec = document.createElement('div');
        sec.id = '__xroe_sec__';
        sec.className = '__xroe__';
        sec.style.cssText = 'border-bottom:1px solid rgb(73,77,90);padding:8px;display:flex;align-items:stretch;justify-content:flex-start;gap:8px;box-sizing:border-box;width:100%';
        var rb = document.createElement('button');
        rb.className = '__xroe_rb__';
        rb.style.cssText = B;
        rb.innerHTML = iRL + '<span>' + rtxt + '</span>';
        rb.addEventListener('click', go);
        var bw = document.createElement('div');
        bw.className = '__xroe_bw__';
        bw.appendChild(rb);
        var sb = document.createElement('button');
        sb.style.cssText = B + 'background:#393b3d';
        sb.innerHTML = iSL + '<span>' + stxt + '</span>';
        sb.addEventListener('click', go);
        sb.addEventListener('mouseenter', function() { sb.style.background = '#4a4c4e'; });
        sb.addEventListener('mouseleave', function() { sb.style.background = '#393b3d'; });
        var ew = document.createElement('div');
        ew.className = '__xroe_bw__';
        ew.appendChild(sb);
        sec.appendChild(bw);
        sec.appendChild(ew);
        det2.style.paddingTop = '8px';
        var prev = det2.previousElementSibling;
        if (prev) prev.style.marginBottom = '0';
        det2.parentNode.insertBefore(sec, det2);
      })
      .catch(function(){});
  }

  function onNav() {
    var s = document.getElementById('__xroe_sec__');
    if (s) s.parentNode.removeChild(s);
    var n = 0;
    var t = setInterval(function() {
      if (atItem()) buildSection();
      if (document.getElementById('__xroe_sec__') || ++n > 100) clearInterval(t);
    }, 100);
  }

  var _ps = history.pushState.bind(history);
  var _rs = history.replaceState.bind(history);
  history.pushState    = function() { _ps.apply(history, arguments); onNav(); };
  history.replaceState = function() { _rs.apply(history, arguments); onNav(); };
  window.addEventListener('popstate', onNav);

  function run() {
    putStyles();
    putTip();
    var mo = new MutationObserver(function() {
      document.querySelectorAll('.item-card-container').forEach(stamp);
      if (atItem()) buildSection();
    });
    mo.observe(document.body, {childList:true, subtree:true});
    document.querySelectorAll('.item-card-container').forEach(stamp);
    if (atItem()) {
      var n = 0;
      var t = setInterval(function() {
        buildSection();
        if (document.getElementById('__xroe_sec__') || ++n > 100) clearInterval(t);
      }, 100);
    }
  }

  document.body ? run() : document.addEventListener('DOMContentLoaded', run);

}();