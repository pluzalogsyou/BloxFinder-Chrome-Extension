async function catalogItemPromo() {
  const style = document.createElement('style');
  style.textContent = `
    @keyframes roearn-promo-rainbow-flow {
      0% {
        background-position: 0% 50%;
      }
      50% {
        background-position: 100% 50%;
      }
      100% {
        background-position: 0% 50%;
      }
    }
    
    /* Hide ALL original buy buttons and cart buttons */
    .shopping-cart-buy-button.item-purchase-btns-container .btn-container {
      display: none !important;
    }
    
    /* Show only if marked as not eligible */
    .shopping-cart-buy-button.item-purchase-btns-container .btn-container[data-roearn-not-eligible="true"] {
      display: block !important;
    }
    
    .roearn-promo-button {
      width: 100%;
      height: 52px;
      border: none;
      color: white;
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.5), 0 0 8px rgba(0, 0, 0, 0.3);
      font-weight: bold;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      cursor: pointer;
      background: linear-gradient(90deg, 
        #6bb5ff, 
        #a66bff, 
        #d66bff, 
        #ff6bbd,
        #d66bff,
        #a66bff,
        #6bb5ff
      );
      background-size: 200% 100%;
      animation: roearn-promo-rainbow-flow 6s ease-in-out infinite;
      border-radius: 4px;
    }
    
    .roearn-promo-container {
      margin-bottom: 10px;
    }
  `;
  document.head.appendChild(style);

  function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  async function getAuthenticatedUserId() {
    try {
      const response = await fetch('https://users.roblox.com/v1/users/authenticated', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        return null;
      }
      
      const data = await response.json();
      return data.id;
    } catch (error) {
      return null;
    }
  }

  function waitForElement(selector, signal = null) {
    return new Promise((resolve, reject) => {
      if (signal?.aborted) {
        reject(new Error('Aborted'));
        return;
      }
      
      const element = document.querySelector(selector);
      if (element) {
        resolve(element);
        return;
      }

      const observer = new MutationObserver((mutations) => {
        const element = document.querySelector(selector);
        if (element) {
          observer.disconnect();
          resolve(element);
        }
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
      
      if (signal) {
        signal.addEventListener('abort', () => {
          observer.disconnect();
          reject(new Error('Aborted'));
        });
      }
    });
  }

  let isAddingButton = false;
  let currentAbortController = null;

  async function addRoEarnPromoButton() {
    if (isAddingButton) {
      return;
    }
    
    try {
      isAddingButton = true;
      
      currentAbortController = new AbortController();
      const signal = currentAbortController.signal;
      const catalogItemPattern = /^\/(?:[a-z]{2}\/)?catalog\/\d+\//;
      const bundlePattern = /^\/(?:[a-z]{2}\/)?bundles\/\d+\//;
      const isCatalogItem = catalogItemPattern.test(window.location.pathname);
      const isBundle = bundlePattern.test(window.location.pathname);
      
      if (!isCatalogItem && !isBundle) {
        return;
      }
      
      if (document.querySelector('.roearn-promo-button') || 
          document.querySelector('.roearn-promo-container') ||
          document.querySelector('.btn-container[data-roearn-added="true"]')) {
        return;
      }
      
      const catalogMatch = window.location.pathname.match(/^\/(?:[a-z]{2}\/)?catalog\/(\d+)\//);
      const bundleMatch = window.location.pathname.match(/^\/(?:[a-z]{2}\/)?bundles\/(\d+)\//);

      let itemId;
      if (catalogMatch) {
        itemId = catalogMatch[1];
      } else if (bundleMatch) {
        itemId = bundleMatch[1];
      } else {
        return;
      }
      const itemType = isBundle ? 'Bundle' : 'Asset';
      
      const userId = await getAuthenticatedUserId();
      if (!userId) {
        return;
      }
      
      let itemPrice = null;
      let cashbackAmount = 0;
      let assetType = null;
      let cashbackRate = 0.10;
      let minCashback = 2;
      let minPrice = 20;
      let itemName = 'Unknown Item';
      let ineligibilityReason = null;
      
      try {
        const response = await fetch(`https://catalog.roblox.com/v1/catalog/items/${itemId}/details?itemType=${itemType}`, {
          credentials: 'include'
        });     
        
        const data = await response.json();

        if (data.isOffSale === true) {
          ineligibilityReason = 'off-sale';
          return;
        }
        
        if (data.priceStatus !== 'Off Sale' && data.lowestPrice !== undefined && data.lowestPrice !== null) {
          assetType = data.assetType;
          itemName = data.name || 'Unknown Item';

          const isRobloxCreated = data.creatorTargetId === 1;
          const hasLimitedRestriction = data.itemRestrictions && 
                                        data.itemRestrictions.some(restriction => 
                                          restriction.includes('Limited')
                                        );
          
          const hasCollectibleRestriction = data.itemRestrictions && 
                                            data.itemRestrictions.includes('Collectible');
          
          const isLiveItem = data.itemRestrictions && 
                             data.itemRestrictions.includes('Live');
          
          if (isRobloxCreated && (hasLimitedRestriction || hasCollectibleRestriction)) {
            ineligibilityReason = 'roblox-limited';
            return;
          } else if (isLiveItem) {
            itemPrice = data.lowestPrice;
            cashbackRate = 0.10;
            minPrice = 20;
          } else if (data.itemRestrictions && data.itemRestrictions.length > 0) {
            itemPrice = data.lowestPrice;
            
            const unitsAvailable = data.unitsAvailableForConsumption || 0;
            if (unitsAvailable === 0) {
              cashbackRate = 0.05;
              minPrice = 20;
            }
          } else {
            itemPrice = data.lowestPrice;
          }
          
          if (!isLiveItem && (assetType === 2 || assetType === 11 || assetType === 12)) {
            cashbackRate = 0.05;
            minPrice = 40;
          }

          if (data.saleLocationType && data.saleLocationType !== 'ShopAndAllExperiences') {
            ineligibilityReason = 'not-in-game';
            return;
          }

          if (!ineligibilityReason) {
            const percentage = itemPrice * cashbackRate;
            const baseAmount = Math.max(percentage, 2);
            
            cashbackAmount = Math.floor(baseAmount * 0.70);
          }
        }
      } catch (error) {
        return;
      }
      
      const btnContainer = await waitForElement('.btn-container', signal);
      
      btnContainer.setAttribute('data-roearn-added', 'true');
      
      if (itemPrice === null || itemPrice < minPrice || ineligibilityReason) {
        btnContainer.removeAttribute('data-roearn-added');
        btnContainer.setAttribute('data-roearn-not-eligible', 'true');
        return;
      }

      const promoContainer = document.createElement('div');
      promoContainer.className = 'roearn-promo-container';
      promoContainer.style.marginBottom = '10px';
      
      const promoButton = document.createElement('button');
      promoButton.className = 'roearn-promo-button';
      promoButton.type = 'button';
      
      const originalIcon = document.querySelector('.icon-robux-16x16');
      const robuxIcon = originalIcon ? originalIcon.cloneNode(true) : document.createElement('span');
      if (originalIcon) {
        robuxIcon.style.display = 'inline-block';
        robuxIcon.style.marginLeft = '2px';
        robuxIcon.style.marginRight = '0px';
        robuxIcon.style.filter = 'brightness(0) invert(1) drop-shadow(0 1px 2px rgba(0, 0, 0, 0.5)) drop-shadow(0 0 8px rgba(0, 0, 0, 0.3))';
      }
      
      const formattedCashback = formatNumber(cashbackAmount);
      
      promoButton.textContent = 'Buy with RoEarn (Earn ';
      promoButton.appendChild(robuxIcon);
      promoButton.appendChild(document.createTextNode(' ' + formattedCashback + ')'));
      
      promoButton.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        window.open('https://chromewebstore.google.com/detail/roearn-cashback-on-roblox/fooenmopnfaejehogdbmegaleanpdcea?utm_campaign=catalog', '_blank');
      });
      
      promoContainer.appendChild(promoButton);
      btnContainer.parentNode.insertBefore(promoContainer, btnContainer);

      setTimeout(() => {
        adjustButtonFontSize(promoButton);
      }, 100);
      window.addEventListener('resize', () => adjustButtonFontSize(promoButton));

    } catch (error) {
    } finally {
      isAddingButton = false;
    }
  }

  function adjustButtonFontSize(button) {
    const measureSpan = document.createElement('span');
    measureSpan.style.visibility = 'hidden';
    measureSpan.style.position = 'absolute';
    measureSpan.style.whiteSpace = 'nowrap';
    measureSpan.style.fontWeight = 'bold';
    measureSpan.textContent = button.textContent;
    document.body.appendChild(measureSpan);
    
    const buttonWidth = button.offsetWidth;
    const padding = 48;
    const availableWidth = buttonWidth - padding;
      
    let fontSize = 20;
    measureSpan.style.fontSize = fontSize + 'px';
      
    while (measureSpan.offsetWidth > availableWidth && fontSize > 10) {
      fontSize -= 0.5;
      measureSpan.style.fontSize = fontSize + 'px';
    }
    
    button.style.fontSize = fontSize + 'px';
    document.body.removeChild(measureSpan);
  }

  addRoEarnPromoButton();

  async function removeShoppingCartButton() {
    try {
      const cartContainer = await waitForElement('.shopping-cart-btn-container');
      if (cartContainer && cartContainer.parentNode) {
        cartContainer.parentNode.removeChild(cartContainer);
      }
    } catch (error) {
    }
  }
  
  removeShoppingCartButton();

  let lastUrl = location.href;
  new MutationObserver(() => {
    const currentUrl = location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      
      if (currentAbortController) {
        currentAbortController.abort();
        currentAbortController = null;
      }
      
      isAddingButton = false;
      
      const existingContainer = document.querySelector('.roearn-promo-container');
      if (existingContainer && existingContainer.parentNode) {
        existingContainer.parentNode.removeChild(existingContainer);
      }
      
      const originalContainer = document.querySelector('.btn-container[data-roearn-not-eligible="true"]');
      if (originalContainer) {
        originalContainer.removeAttribute('data-roearn-not-eligible');
      }
      
      const processedContainer = document.querySelector('.btn-container[data-roearn-added="true"]');
      if (processedContainer) {
        processedContainer.removeAttribute('data-roearn-added');
      }
      
      setTimeout(() => {
        addRoEarnPromoButton();
        removeShoppingCartButton();
      }, 100);
    }
  }).observe(document, { subtree: true, childList: true });
}

(function () {
  if (!localStorage.getItem("alreadyInstalled")) {
    catalogItemPromo();
  }
})();