import json
import os

translations = {
    'en':    'New',
    'id':    'Baru',
    'de':    'Neu',
    'es':    'Nuevo',
    'fr':    'Nouveau',
    'it':    'Nuovo',
    'pl':    'Nowy',
    'pt_BR': 'Novo',
    'vi':    'Mới',
    'tr':    'Yeni',
    'th':    'ใหม่',
    'zh_CN': '新',
    'zh_TW': '新',
    'ja':    '新着',
    'ko':    '새로운',
    'ar':    'جديد'
}

for locale, text in translations.items():
    path = os.path.join(locale, 'messages.json')

    if not os.path.exists(path):
        print(f'SKIP: {path} not found')
        continue

    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    data['sidebarBadgeNew'] = { 'message': text }

    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print(f'OK: {path}')

print('Done.')