async function gamepassPromo() {
  if (!document.getElementById('roearn-gamepass-promo-animation')) {
    const gamepassStyle = document.createElement('style');
    gamepassStyle.id = 'roearn-gamepass-promo-animation';
    gamepassStyle.textContent = `
      @keyframes roearn-gamepass-promo-rainbow-flow {
        0% {
          background-position: 0% 50%;
        }
        50% {
          background-position: 100% 50%;
        }
        100% {
          background-position: 0% 50%;
        }
      }
      
      /* Hide original Roblox purchase buttons */
      .PurchaseButton.rbx-gear-passes-purchase {
        display: none !important;
      }
      
      /* Show original button only if marked as not eligible */
      .PurchaseButton.rbx-gear-passes-purchase[data-roearn-not-eligible="true"] {
        display: block !important;
      }
      
      .roearn-gamepass-promo-button {
        background: linear-gradient(90deg, 
          #6bb5ff, 
          #a66bff, 
          #d66bff, 
          #ff6bbd,
          #d66bff,
          #a66bff,
          #6bb5ff
        );
        background-size: 200% 100%;
        animation: roearn-gamepass-promo-rainbow-flow 6s ease-in-out infinite;
        height: 50px;
        border: none;
        border-radius: 8px;
        color: white;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.5), 0 0 8px rgba(0, 0, 0, 0.3);
        font-weight: bold;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        margin-bottom: 12px;
        cursor: pointer;
        flex-direction: column;
        gap: 2px;
      }
    `;
    document.head.appendChild(gamepassStyle);
  }

  async function getAuthenticatedUserId() {
    try {
      const response = await fetch('https://users.roblox.com/v1/users/authenticated', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        return null;
      }
      
      const data = await response.json();
      return data.id;
    } catch (error) {
      return null;
    }
  }

  function waitForElement(selector, signal = null) {
    return new Promise((resolve, reject) => {
      if (signal?.aborted) {
        reject(new Error('Aborted'));
        return;
      }
      
      const element = document.querySelector(selector);
      if (element) {
        resolve(element);
        return;
      }

      const observer = new MutationObserver((mutations) => {
        const element = document.querySelector(selector);
        if (element) {
          observer.disconnect();
          resolve(element);
        }
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
      
      if (signal) {
        signal.addEventListener('abort', () => {
          observer.disconnect();
          reject(new Error('Aborted'));
        });
      }
    });
  }

  let isAddingButtons = false;
  let currentAbortController = null;

  async function addGamePassPromoButtons() {
    if (isAddingButtons) {
      return;
    }
    
    try {
      isAddingButtons = true;
      
      currentAbortController = new AbortController();
      const signal = currentAbortController.signal;
      
      const gamePagePattern = /^\/(?:[a-z]{2}\/)?games\/\d+\//;
      if (!gamePagePattern.test(window.location.pathname)) {
        return;
      }
      
      const isOnStoreTab = window.location.hash.includes('store') || 
                           document.querySelector('#tab-store.active') !== null ||
                           document.querySelector('.tab-pane.store.active') !== null;
      if (!isOnStoreTab) {
        return;
      }
            
      const userId = await getAuthenticatedUserId();
      if (!userId) {
        return;
      }
      
      const passesContainer = await waitForElement('#rbx-passes-container .PurchaseButton', signal);

      const purchaseButtons = document.querySelectorAll('#rbx-passes-container .PurchaseButton');
      
      if (purchaseButtons.length === 0) {
        return;
      }
            
      purchaseButtons.forEach((originalButton) => {
        const footer = originalButton.closest('.store-card-footer');
        if (footer.querySelector('.roearn-gamepass-promo-button')) {
          return;
        }
        
        const storeCard = originalButton.closest('.store-card');
        const storeCardCaption = originalButton.closest('.store-card-caption');
        const listItem = originalButton.closest('.list-item');
        
        if (storeCard) {
          storeCard.style.overflow = 'visible';
          storeCard.style.height = 'auto';
          storeCard.style.minHeight = 'auto';
        }
        if (storeCardCaption) {
          storeCardCaption.style.overflow = 'visible';
          storeCardCaption.style.height = 'auto';
        }
        if (listItem) {
          listItem.style.overflow = 'visible';
          listItem.style.height = 'auto';
        }
        if (footer) {
          footer.style.overflow = 'visible';
          footer.style.height = 'auto';
        }
        
        const price = parseInt(originalButton.getAttribute('data-expected-price')) || 0;
        
        const cashbackRate = 0.05;
        const baseAmount = price * cashbackRate;
        const finalAmount = Math.floor(baseAmount * 0.70);
        
        const minPrice = 40;
        const isEligible = price >= minPrice && finalAmount >= 1;
        
        if (!isEligible) {
          originalButton.setAttribute('data-roearn-not-eligible', 'true');
          return;
        }
                
        const originalIcon = document.querySelector('.icon-robux-16x16');
        const robuxIcon = originalIcon ? originalIcon.cloneNode(true) : document.createElement('span');
        if (originalIcon) {
          robuxIcon.style.display = 'inline-block';
          robuxIcon.style.marginLeft = '2px';
          robuxIcon.style.marginRight = '0px';
          robuxIcon.style.filter = 'brightness(0) invert(1) drop-shadow(0 1px 2px rgba(0, 0, 0, 0.5)) drop-shadow(0 0 8px rgba(0, 0, 0, 0.3))';
        }
        
        const cashbackButton = document.createElement('button');
        cashbackButton.className = 'btn-buy-md btn-full-width roearn-gamepass-promo-button';
        cashbackButton.type = 'button';
        
        const buyText = document.createElement('div');
        buyText.textContent = 'Buy';
        buyText.style.width = '100%';
        buyText.style.textAlign = 'center';
        buyText.style.fontSize = '16.8px';
        buyText.style.fontWeight = 'bold';
        buyText.style.color = 'white';
        
        const earnText = document.createElement('div');
        earnText.style.display = 'flex';
        earnText.style.alignItems = 'center';
        earnText.style.justifyContent = 'center';
        earnText.style.width = '100%';
        earnText.style.fontSize = '14px';
        earnText.style.color = 'white';
        
        earnText.appendChild(document.createTextNode('(Earn '));
        earnText.appendChild(robuxIcon);
        earnText.appendChild(document.createTextNode(' ' + finalAmount + ')'));
        
        cashbackButton.appendChild(buyText);
        cashbackButton.appendChild(earnText);
        
        cashbackButton.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          window.open('https://chromewebstore.google.com/detail/roearn-cashback-on-roblox/fooenmopnfaejehogdbmegaleanpdcea?utm_campaign=gamepass', '_blank');
        });
        
        footer.insertBefore(cashbackButton, originalButton);
      });

    } catch (error) {
    } finally {
      isAddingButtons = false;
    }
  }

  function checkAndAddButtons() {
    const isOnStoreTab = window.location.hash.includes('store') || 
                         document.querySelector('#tab-store.active') !== null ||
                         document.querySelector('.tab-pane.store.active') !== null;
    if (isOnStoreTab) {
      addGamePassPromoButtons();
    }
  }

  checkAndAddButtons();
  
  setTimeout(checkAndAddButtons, 100);
  setTimeout(checkAndAddButtons, 300);

  window.addEventListener('hashchange', () => {
    if (currentAbortController) {
      currentAbortController.abort();
      currentAbortController = null;
    }
    
    isAddingButtons = false;
    
    const existingButtons = document.querySelectorAll('.roearn-gamepass-promo-button');
    existingButtons.forEach(btn => {
      if (btn.parentNode) {
        btn.parentNode.removeChild(btn);
      }
    });
    
    const originalButtons = document.querySelectorAll('.PurchaseButton.rbx-gear-passes-purchase[data-roearn-not-eligible="true"]');
    originalButtons.forEach(btn => {
      btn.removeAttribute('data-roearn-not-eligible');
    });
    
    checkAndAddButtons();
  });

  let lastHash = window.location.hash;
  new MutationObserver(() => {
    const currentHash = window.location.hash;
    if (currentHash !== lastHash) {
      lastHash = currentHash;
      
      if (currentAbortController) {
        currentAbortController.abort();
        currentAbortController = null;
      }
      
      isAddingButtons = false;
      
      const existingButtons = document.querySelectorAll('.roearn-gamepass-promo-button');
      existingButtons.forEach(btn => {
        if (btn.parentNode) {
          btn.parentNode.removeChild(btn);
        }
      });
      
      const originalButtons = document.querySelectorAll('.PurchaseButton.rbx-gear-passes-purchase[data-roearn-not-eligible="true"]');
      originalButtons.forEach(btn => {
        btn.removeAttribute('data-roearn-not-eligible');
      });
      
      checkAndAddButtons();
    }
  }).observe(document.body, { subtree: true, childList: true });
}

(function () {
  if (!localStorage.getItem("alreadyInstalled")) {
    gamepassPromo();
  }
})();